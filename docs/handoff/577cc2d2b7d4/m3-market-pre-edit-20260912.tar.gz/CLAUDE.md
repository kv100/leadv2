# M3 Market — Claude Code Rules

## Language

- **Documents:** English
- **Chat:** Russian

---

## Session hygiene — hard rules

Context cost grows 2-3× from turn 1 to turn 80. After 80 turns each turn costs as much as 3 early turns.

- **80 turns → run `/compact`** before continuing. No exceptions.
- **Bash calls in one session: max 60.** Batch multiple checks into one call.
- **Monitor calls in one session: max 5.** Batch grep patterns with `grep -E "A|B|C"`.
- **No text-only turns between tool calls** — every narration turn costs 100K+ tokens at long-context. # covered by leadv2-subagent-protocol skill (intermediate silence + self-monitoring cap)

---

@import rules/04-mempalace.md

---
# rules/00-orchestrator.md and rules/05-opus-triggers.md load on demand via /leadv2 skill — not preloaded every session

# /leadv2 router architecture (lead is router, not thinker): docs/specs/leadv2-router-architecture.md
# Lead default model: OPUS (LEADV2_MAIN_MODEL=opus, ref/leadv2-main-model.yaml main_model: opus; Fable retired 2026-07-07 (sunset), lead=Opus — FABLE-RETIRE-01 2026-07-06, supersedes FABLE-PLUGIN-UPGRADE-01 2026-06-09). LEADV2_FORCE_OPUS_LEAD=0 — gate only applies to opus. Lead = thin Opus brain that decides + dispatches WORKFLOWS; heavy work runs in ~/.claude/workflows/ on pinned cheap models + Codex. Heavy/safety subagent escalation: opus. Quota circuit-breaker: routing.yaml downgrade_chain opus→sonnet.
# Founder questions during active task: ALWAYS route via leadv2-founder-question-router skill — never answer judgment yourself.

---

## Diagnosis protocol — "X isn't happening" (m3-market; hard rule, 2026-06-25)

Ported from persona-engine (2026-06-25). A whole session was burned theorizing about
a root cause when the service log already said what broke. For ANY "feature not working /
0 results / wrong output" bug, in THIS order — do not skip ahead:

1. **Read the component's error log FIRST**, before any theory.
   - **Go backend:** Loki query `{app="pf3-backend", container="app"} |= "error"` on
     Grafana (`https://mti-grafana-prod01.mythical.work`, orgId=12) OR CircleCI test
     output for CI failures. For local dev: `make dev` stderr + docker logs.
   - **Frontend:** Vercel build/runtime logs (`vercel logs <url> --scope mythical`) OR
     browser DevTools network tab for 4xx/5xx. For local: Next.js terminal stdout.
   - **DB migrations:** `make pf3-local-migrate-up` stderr; watch for `no change` vs
     SQL errors. Parameterized-query errors appear in backend logs, not migration logs.
   - **TODO: confirm exact Loki label selectors with devops** (e.g. per-service labels
     for pf3-web-gtw, pf3-listing, etc. — the pattern above is for pf3-backend only).

2. **Walk the pipeline by boundary-counts to the FIRST zero.** e.g. for a listing flow:
   request→gateway→service→DB write→response: check count/status at each boundary
   (API response code, DB row count, gRPC status). The stage where it drops to 0 is the bug.
   Do not jump between theories.

3. **Distrust `2>/dev/null` / "nothing happened".** Silent failure is identical to silent
   success from the outside. Re-run with stderr visible; assume an error is hidden.
   For Go: check if the error is being swallowed (`if err != nil { return }` with no log).

4. **Reproduce the failing op in isolation FIRST, not last.** One `curl` against
   `https://market-api.pulse.xyz/api/<endpoint>` or `localhost:8080/api/<endpoint>` with
   the exact payload → instant error code. For DB: one raw parameterized query against
   local Postgres to confirm the row exists / constraint fires.

5. **Fix only after the mechanism is proven by runtime evidence, not code-reading.**
   Code-reading makes hypotheses; runtime error output confirms. Never ship a fix on a
   code-read hypothesis alone.

Memory: `feedback-diagnosis-read-error-first`.

## Developer pre-build checklist — inject into EVERY build mission (2026-06-25)

`.claude/ref/dev-prebuild-checklist.md` — distilled from a 106-session retrospective (87 recurring
critic findings; patterns apply equally to m3 Go+TS code). The LEAD must inject its contents
(or its path) into every developer mission prompt so the same dumb mistakes (jsonb-PATCH wipes,
missing NOT-NULL cols, `2>/dev/null` swallows, idempotency gaps, N+1, false-zero queries,
tautological tests) are avoided UPFRONT rather than re-caught at review.
A PreToolUse hook also surfaces it on developer Edit/Write.

---

## Project

**m3-market** — NFT marketplace (Mythical Games).
Monorepo workspace: `m3/` (Next.js frontend), `pf3-backend/` (Go API), `environment-platform/` (k8s infra).

- **FE:** `m3/apps/main/` | `m3/packages/` (features, ui, api, store, types, utils)
- **BE:** `pf3-backend/app/` | `pf3-backend/pkg/` | `pf3-backend/api/mp-contract/mp-api.yaml`
- **Infra:** `environment-platform/platform3/`

## Agents

Dispatch is **native**: orchestrator calls `Agent(subagent_type="<agent-name>")`
where `<agent-name>` matches the `name:` field in the agent's frontmatter.
Claude Code loads that agent's frontmatter — `tools:`, `model:`, `effort:`,
`skills:` — and spawns it in isolated context.

| Role | subagent_type | Model |
|------|---------------|-------|
| explorer | `11-explorer` (or built-in `Explore`) | haiku |
| debugger | `10-debugger` | sonnet |
| go-debugger | `12-go-debugger` | sonnet |
| react-developer | `02-react-developer` | sonnet |
| nextjs-pro | `09-nextjs-pro` | sonnet |
| go-developer | `04-go-developer` | sonnet |
| architect | `07-architect` | opus |
| be-architect | `17-be-architect` | opus |
| fe-architect | `18-fe-architect` | opus |
| qa-engineer | `08-qa-engineer` | sonnet |
| qa-backend | `16-qa-backend` | sonnet |
| reviewer | `03-reviewer` | sonnet |
| go-reviewer | `05-go-reviewer` | sonnet |
| infra-engineer | `06-infra-engineer` | sonnet |
| devops-agent | `15-devops-agent` | sonnet |
| incident-manager | `14-incident-manager` | opus |
| release-agent | `13-release-agent` | sonnet |

Baseline `skills:` in each agent's frontmatter **auto-preload** — orchestrator
does not need to list them in the prompt. Add skills explicitly only for
task-specific one-offs beyond baseline.

## Prompt Template

```
Agent({
  subagent_type: "<agent-name>",   // e.g. "04-go-developer", "07-architect"
  model: "<model>",                 // usually matches agent's frontmatter; override only when needed
  prompt: "## Context
[summarized explore results / what changed — keep under 500 words]

## Task
[description with file paths + verification commands]

## Extra skills (optional — baseline skills auto-load from frontmatter)
- .claude/skills/<task-specific-skill>/QUICKREF.md"
})
```

For Opus escalation criteria (T1–T9 triggers + anti-triggers), see
`rules/05-opus-triggers.md`.

## Skill Catalog

**FE:** **pulse-design-system** (MANDATORY for any UI work — the real `@marketplace/ui` as shipped, m3 PR #692; supersedes m3-nft-design), react-patterns, react-best-practices, nextjs-patterns, nextjs-app-router, tanstack-query, zustand-store, tailwind-patterns, radix-ui, ui-patterns, coding-standards, testing-patterns, monorepo-patterns, browser-automation, browser-qa, accessibility, frontend-design
**BE:** go-patterns, go-coding-standards, go-api-design, go-testing-bdd, go-database, go-kafka, go-blockchain, go-concurrency-patterns, kafka-patterns
**Infra:** kubernetes-architect, k8s-manifest-generator, gitops-workflow, linkerd-patterns
**Cross:** production-audit, error-detective, error-handling, systematic-debugging, architecture-decision-records, api-design

List 1-2 most relevant per task. Agent decides whether to read them.

## References

Architecture: `m3/ARCHITECTURE.md` | Constitution: `m3/.specify/memory/constitution.md`
Repo Map: `.claude/reference/repo-map.md` | Shared Packages: `.claude/reference/shared-packages.md`
Memory: check MEMORY.md for keywords before tasks | "запомни" → save to MEMORY.md
