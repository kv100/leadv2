#!/bin/bash
# UserPromptSubmit hook: concentrate-signal skill matcher.
# Reads the user prompt from stdin JSON, keyword-matches it against the hub skill
# catalog, and emits a short "relevant skills" line to context so the lead actually
# invokes them (auto-invocation from raw descriptions is weak — see m3-deploy-access).
# Stdout from a UserPromptSubmit hook is injected as additional context.

p="$(python3 -c 'import sys,json;print((json.load(sys.stdin).get("prompt") or "").lower())' 2>/dev/null)"
[ -z "$p" ] && exit 0

declare -a hits=()
m(){ echo "$p" | grep -iqE "$1" && hits+=("$2"); }

# perf / web vitals
m 'perf|lighthouse|cwv|core web vital|lcp|cls|tbt|inp|быстродейств|грузит|медленн|page.?speed|bundle|render' 'm3-perf-measure'
# reaching deployments
m 'preprod|prod\b|prod-|preview|deploy|vercel|401|не открыва|препрод|прод|деплой|alias|m3\.mythical|market\.pulse' 'm3-deploy-access'
# react / fe
m '\breact|component|\.tsx|hook|useeffect|usestate|zustand|tanstack|react-query' 'react-patterns, react-best-practices, tanstack-query, m3-stack-conventions'
# next / ssr
m 'next\.?js|app router|server component|\brsc\b|\bssr\b|middleware|generatemetadata' 'nextjs-patterns, nextjs-app-router'
# styling
m 'tailwind|\bcss\b|styl|\bclassname|responsive|breakpoint' 'tailwind-patterns, ui-patterns'
# design
m 'design|figma|visual|layout|ui\b|ux\b|polish' 'frontend-design, m3-nft-design'
# go backend
m '\bgo\b|golang|handler|chi/|oapi|sqlx|ginkgo|kafka|franz|seaport|privy.*jwt|migration' 'go-patterns, go-api-design, go-testing-bdd, go-database, go-kafka'
# infra
m 'k8s|kubernetes|kustomize|argocd|linkerd|helm|namespace|overlay|manifest' 'kubernetes-architect, k8s-manifest-generator, gitops-workflow, linkerd-patterns'
# debugging
m 'bug|error|crash|\b500\b|\b504\b|fail|broken|stack ?trace|почему не|root.?cause|debug' 'systematic-debugging, error-detective'
# testing
m 'test|vitest|coverage|ginkgo|e2e|playwright' 'testing-patterns, browser-qa, verification-before-completion'
# api contract
m 'api|endpoint|contract|openapi|mp-api|schema' 'api-design'

[ ${#hits[@]} -eq 0 ] && exit 0
# dedupe preserving order
uniq_hits=$(printf '%s\n' "${hits[@]}" | awk '!seen[$0]++' | paste -sd'; ' -)
echo "🎯 Relevant skills for this task (invoke via Skill tool if you act on it): ${uniq_hits}"
echo "(skill auto-invocation is weak — consider loading the matched skill before delegating.)"
exit 0
