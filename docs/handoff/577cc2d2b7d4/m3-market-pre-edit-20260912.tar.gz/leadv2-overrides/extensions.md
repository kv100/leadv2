# leadv2-overrides/extensions.md — m3-market specifics for leadv2
# CRITICAL INFO: preserved from .claude/reference/ and agent files — do not lose.

## Web Guidance — modern-web-guidance trigger policy

Shared `modern-web-guidance` skill (Google Chrome best-practices DB) is auto-loaded into
`02-react-developer`, `09-nextjs-pro`, `18-fe-architect`, `03-reviewer` via their `skills:`
frontmatter. Runs offline via `npx modern-web-guidance@latest search/retrieve`.

**MANDATORY trigger** — any PR touching `m3/apps/main/`, `m3/apps/dashboard/`, `m3/apps/admin/`:
the implementing agent (react-developer / nextjs-pro) MUST call `modern-web-guidance search "<task verb>"`
BEFORE writing code. Skip only if the diff is pure config (package.json bump, eslint rule).

**m3-specific high-value use cases** (always check guidance first):
- NFT thumbnail loading on `collectionsGrid` / detail pages → `optimize-image-priority`, `defer-rendering-heavy-content`
- Bidding/listing forms (price, currency, expiration) → `validate-input-after-interaction`, `form-fields-automatically-fit-contents`, `:user-invalid` styling
- Infinite scroll / pagination on browse pages → `improve-next-page-load-performance` (speculation-rules), scroll-driven animations
- RSC streaming on detail pages → check Suspense boundary patterns before adding new `"use client"` islands
- Custom select pickers (currency, network, sort order) → `customizable-select`, `select-menu-interaction`
- Toast/modal/popover (notification, confirm dialog) → native `<dialog>`, Popover API, anchor positioning
- CWV monitoring before Vercel deploy → `batch-analytics-events`, `full-session-analytics` via `fetchLater`

**03-reviewer** flags as **High** any FE diff that ignores guidance recommendations (e.g. JS auto-resize when
`field-sizing: content` would suffice, custom focus trap when Popover API is available, eager validation when
`:user-invalid` is the right pattern).

**DO NOT trigger** on: `pf3-backend/` (Go), `services/` (Go gRPC), Kubernetes manifests, ArgoCD config, CircleCI
YAML, golang-migrate SQL — the skill's self-guard handles this but be explicit in plan steps.

---

## Workflow tool — model per `agent()` + Codex routing (m3)

If the lead authors a `Workflow` tool script (fan-out orchestration), the shared
`leadv2-token-discipline` skill applies — every `agent()` MUST carry an explicit `model:`
or it inherits the main-loop model (Opus) and the whole fleet runs Opus. No global default exists.

**m3-specific — Codex is ON (standing founder approval):** `codex_enabled: true` since 2026-06-09,
reaffirmed 2026-06-22. Codex IS a first-class option for Phase 2 (plan review) and Phase 5
(diff review). See `codex-policy.yaml` and global `~/.claude/CLAUDE.md` section
"m3-market: Codex / GPT-5 — ON by standing founder approval".
Agents MUST NOT self-refuse Codex citing any legacy ban — that framing is fully superseded.

Workflow agent model routing: `model:'haiku'` (trace/read), `model:'sonnet'` (write/verify),
`model:'opus'` (single deep step, never the fleet). Codex routes through Phase 2/5 review hooks
only — not as a fan-out worker inside Workflow scripts (batch workers stay Claude tiers).
Before launching, compute `agents = items × stages (+synth)`; if that count on the inherited model isn't intended, the `model:` opts are missing.

---

## Bug Investigation — HARD OVERRIDE (all phases)

**Lead NEVER investigates bugs directly.** Any symptom (504, 500, wrong output, perf issue, test fail):

```
Spawn immediately:
  - API/FE bug  → Agent(subagent_type="10-debugger", model="sonnet")
  - Go BE bug   → Agent(subagent_type="12-go-debugger", model="sonnet")
```

Pass: symptom + repro command + what's already ruled out + deliverable `/tmp/<id>-diagnosis.md`.
Read ONLY the deliverable when done (`Read limit=30`). Zero direct Bash/Read into source.

**Trigger: ANY investigation requiring >1 tool call into source/logs/DB/pod.**

This overrides Phase 10 (async_wait resume) behavior: if RESUME.md lists P0 bugs → spawn debugger before anything else.

---

## Tests are MANDATORY in every PR

**Every PR that modifies production code (`.go`, `.ts`, `.tsx`, SQL) MUST include matching tests in the same PR.** No exceptions.

Concrete rules:
- New function / handler → unit test
- New SQL query / CTE / migration → integration test against Postgres testcontainer (Ginkgo style, see `pf3-backend/tests/marketplace_*_test.go`)
- New API endpoint → end-to-end test hitting the handler
- Bug fix → regression test that fails before the fix and passes after

**Lead enforcement**: in every developer mission file, include explicit test requirement:
> "Add a Ginkgo test for the new path. Place it in `tests/<feature>_test.go`. Verify: `make ginkgo focus=\"<your context\">` passes locally before commit."

**Why this rule exists**: PR #312 (CTE filter rewrite) shipped without integration tests. The SQL had an alias scope bug that unit tests + build + lint all missed because no test exercised the actual SQL against a real DB. Bug landed in prod and was caught only when founder opened the page.

**Lead post-deploy smoke**: after any BE deploy that touches SQL/handlers, run 2-3 curl smoke tests against the affected endpoints BEFORE moving to other work. Spawn devops/debugger if any fail.

**Frontend pre-push build verification (FE):** every FE PR/commit that touches `.tsx`/`.ts` MUST run `cd m3 && pnpm build 2>&1 | tail -20` locally and confirm exit 0 BEFORE `git push`. `pnpm type-check` alone is insufficient — Next.js production build has stricter checks. Vercel will block preprod URL via cookie bypass if the build fails (last seen 2026-05-22: TS `as const` readonly array broke 3 consecutive deployments because only `type-check` was run pre-push).

---

## BE deploy is THREE actions, not one (per founder 2026-05-21)

For ANY pf3-backend PR with autonomous-deploy approval:

1. **Squash-merge PR to main** — `gh pr merge <N> --squash --admin`. Pushing the branch is NOT enough.
2. **Approve `approve_deploy_dev` (or `approve_deploy_dev01`)** on the main CircleCI workflow when it hits `on_hold`. Use the CircleCI v2 approve endpoint with `$CIRCLECI_TOKEN`.
3. **Approve `approve_deploy_prod`** on the same workflow when it hits the SECOND `on_hold`. Same endpoint, different approval_request_id.

Pattern (curl):
```bash
WF=<workflow-id>
curl -s -H "Circle-Token: $CIRCLECI_TOKEN" "https://circleci.com/api/v2/workflow/$WF/job" \
  | jq -r '.items[] | select(.status=="on_hold" and .type=="approval") | "\(.approval_request_id) \(.name)"' \
  | while read aid jn; do
      curl -sX POST -H "Circle-Token: $CIRCLECI_TOKEN" "https://circleci.com/api/v2/workflow/$WF/approve/$aid"
    done
```

**Do NOT** consider the task done after merge — both gates must be approved. Watch the workflow until status=`success`, then verify via API that prod endpoint actually reflects the change.

If the watcher script dies (Monitor tool keeps crashing on subshells), fall back to manual approve via the curl pattern above when you see `on_hold` in pipeline status.

## Stack overview
Turborepo monorepo: `apps/main` (marketplace, port 3000), `apps/dashboard` (3001), `apps/admin` (3003).
Go 1.25+ microservices (pf3-*): gRPC + grpc-gateway, Kafka via franz-go, Temporal workflows.
Two chains: m3/pf3 → World Chain (4801), Pulse Arena → Abstract + Ethereum.

---

## Frontend (m3/) — Vercel

### Vercel config
- Team: `mythical` (ALWAYS `--scope mythical`)
- Project: `m3`
- Production domain: `market.pulse.xyz`
- Wildcard alias: `*.m3.mythical.work` (preprod + preview)
- Build command: `pnpm build:apps` (in `vercel.json`)

### CRITICAL: Privy domain whitelist
Only `*.m3.mythical.work` is whitelisted in Privy dashboard.
Raw `*.vercel.app` URLs DO NOT work with Privy login.
Every deployment MUST get a `*.m3.mythical.work` alias.

### Environments
| Env | Target | Privy App ID | Domain |
|-----|--------|-------------|--------|
| Production | `--prod` | `cmhugfp6k002tl90c9h07hn7b` | `market.pulse.xyz` |
| Preprod | `--target preprod` | Production (shared) | `{slug}.m3.mythical.work` |
| Preview | (default) | Dev (`cmfzmj80k00qjk40dxurdm14s`) | `dev-{slug}.m3.mythical.work` |

Dev Privy: `NEXT_PUBLIC_PRIVY_APP_ID=cmfzmj80k00qjk40dxurdm14s`, `NEXT_PUBLIC_PRIVY_CLIENT_ID=client-WY6QmH2ZwE2GwF9o3pWzwceE844cmhiZrQfF8uLHNcJsm`

### Deploy flows
**Preprod (RECOMMENDED):** Push to `preprod/<name>` → Vercel auto-deploys → GH Action (`vercel-preprod-domain.yml`) auto-aliases to `{slug}.m3.mythical.work`. Branch must contain `vercel-preprod-domain.yml` (merge develop if missing). No manual deploy/alias needed.

**Preview:** Override `.env.local` with dev Privy creds → `vercel deploy --scope mythical` → `vercel alias <url> dev-{slug}.m3.mythical.work --scope mythical` → rm `.env.local` (NEVER commit)

**Production:** `preprod/<branch>` → develop (PR) → `develop` → `main` (PR + review + Vercel check) → **MANDATORY back-merge `main` → `develop`** (prevents future conflicts)

### Rollback
- Instant (~30s): `vercel rollback <prev-url> --scope mythical`
- Revert PR (~5min): revert commit → merge to main → back-merge
- **NEVER** `vercel deploy --prod` directly

### Env var management
```bash
vercel env ls production --scope mythical
printf 'value' | vercel env add VAR_NAME production --scope mythical  # printf not echo (avoids \n)
vercel env rm VAR_NAME production --yes --scope mythical
```

### Backend APIs (all envs)
| Var | URL |
|-----|-----|
| `EXTERNAL_API_URL` / `NEXT_PUBLIC_MARKET_API` | `https://market-api.pulse.xyz` |
| `NEXT_PUBLIC_DPAY_API` | `https://dpay.pulse.xyz` |
| `NEXT_PUBLIC_WALLET_API` | `https://wallet.pulse.xyz` |

Chain: World L3 devnet (chain ID `48011`), RPC: `https://worldl3-devnet.g.alchemy.com/public`

---

## Go Backend (pf3-*) — CircleCI → ArgoCD → GKE

### Pipeline
```
Push to any branch → CI (golangci-lint + tests + build + Trivy scan)
  → Manual approval in CircleCI → deploy_dev (pf-dev01)
  → [main only] Integration tests → deploy_prod (pf-prod01)
```

### Environments
| Cluster | Purpose | Trigger |
|---------|---------|---------|
| `pf-dev01` | Dev/testing | Manual CircleCI approval |
| `pf-prod01` | Production | Auto after integration tests (main only) |

### Image naming
`us-docker.pkg.dev/mythical-games/platform3/go-service:{service}-{sha:7}-{pipeline_number}`

### GitOps flow
1. CI builds image → pushes to GCP Artifact Registry
2. `apply_version` step updates `kustomization.yaml newTag` in `environment-platform`
3. Push to `environment-platform/main` (with backoff retry)
4. ArgoCD detects change → syncs → K8s rolling rollout

### environment-platform repo
Repo: `MythicalGames/environment-platform`
Structure:
```
platform3/pf3-backend/{pf-dev01,pf-prod01}/
  ├── kustomization.yaml    # Image tags, replicas
  └── config.yaml           # App config, feature flags
```

### Feature flags
Config in `environment-platform/platform3/<service>/<env>/config.yaml`:
```yaml
features:
  some_feature_enabled: false
```
Enable: edit → commit → push → ArgoCD syncs (~1 min). Disable: set false → push (instant).

### Rollback options
| Method | Speed | When |
|--------|-------|------|
| Feature flag off | ~1 min | Behind a flag |
| ArgoCD revert | ~2 min | Revert `kustomization.yaml` in environment-platform |
| CircleCI re-run | ~10 min | Re-deploy previous green build |

ArgoCD commands:
```bash
argocd app list
argocd app get <app-name>
argocd app sync <app-name>           # force sync if stuck
argocd app rollback <app-name> <history-id>
argocd app history <app-name>
```

---

## Database (PostgreSQL 18)

- Local dev: `docker compose up -d` (PostgreSQL on `localhost:5432`, Redpanda/Kafka, pgAdmin)
- Migrations: `make migrate-up` (golang-migrate, idempotent)
- ORM: none — raw SQL with parameterized queries only (no `fmt.Sprintf` in SQL)
- Migrations live in each service repo under `migrations/`
- `make dev` auto-applies migrations via `--migrate` flag (air hot-reload)

### Local dev cycle (LEGACY single-repo — prefer the harness below)
```bash
cd pf3-backend
docker compose up -d     # start containers (data persists in volumes)
make pf3-local-migrate-up # apply all migrations (NOTE: target is pf3-local-migrate-up, NOT migrate-up)
make dev                 # hot-reload via air
```

### Full local stack — pf3-local-dev harness (CANONICAL, use for E2E)

Runs m3 FE (:3000) against a local pf3-backend (:8080) with contracts on World L3
Devnet (chain 48011). This is what `test E2E before done` actually means.

**Layout (THIS machine):** guide says `~/go/src/github.com/MythicalGames/` but our
checkouts live in `~/MythicalGames/`:
- harness: `~/MythicalGames/pf3-local-dev`  (docker infra + per-service secrets/.envrc)
- backend: `~/MythicalGames/pf3-backend`    (also symlinked into hub as `pf3-backend/`)
- frontend:`~/MythicalGames/m3`             (also symlinked into hub as `m3/`)

**One-time setup (DONE 2026-05-29 — see memory project_local_dev_env.md):**
GitHub access to `MythicalGames/*` + `dmarket/pkg` (dql, money — direct go deps, no
replace; guide omits this). Tools: Foundry (`~/.foundry/bin`), `tailwindcss` (brew).
`go env -w GOPRIVATE=github.com/MythicalGames,github.com/dmarket`. Both repos have
`.env` with `PF3_LOCAL_DEV=~/MythicalGames/pf3-local-dev` + `direnv allow`. Wallets
generated via `pf3-backend/build/tool wallet` and wired into gitignored harness
secrets. Codegen: `make generate-proto && make generate && make build-tools`.

**Daily up (run from pf3-backend, secrets must be filled — see blocker):**
```bash
cd ~/MythicalGames/pf3-local-dev && make up        # PG :5432, Redpanda :19092
cd ~/MythicalGames/pf3-backend
export PATH="$HOME/.foundry/bin:$PATH"              # forge MUST be on PATH
direnv exec . make pf3-local-seed-init             # migrate + forge deploy ERC721 + mint + seed game
direnv exec . make pf3-local-igm-seed-init         # deploy IGMSpenderAuth + register spender + deposit
direnv exec . make pf3-local-seed-jwks             # fetch Privy JWKS
direnv exec . make pf3-local-seed-check            # must report PASS N/N
direnv exec . make pf3-local-dev                   # API on :8080 (air hot-reload)
# new terminal — frontend:
cd ~/MythicalGames/m3 && direnv exec . pnpm dev:main   # Next.js :3000
```
Health: `curl localhost:8080/api/games` → Test Game JSON;
`curl localhost:3000/api/services/market/games` → same via FE proxy.

**Helper (leadv2 wraps all of this):** `bash .claude/scripts/leadv2-local-stack.sh <status|up|seed|health|down>`.
`verify.sh` with `LEAD_V2_DEPLOY_TARGET=local` probes localhost instead of prod.

**SECRETS BLOCKER:** seed + run need 4 values from 1Password "pf3 local dev" in
`pf3-local-dev/secrets.shared.env`: `ALCHEMY_API_KEY` (devnet RPC is
`worldl3-devnet.g.alchemy.com` → required), `ALCHEMY_GAS_POLICY_ID`,
`ALCHEMY_POLICY_ID`, `PRIVY_APP_ID`. Without them seed aborts. `make up` + migrate
+ build work without secrets.

**Gotchas (cost real time):**
- **Docker Desktop auto-stops mid-session** — socket `~/.docker/run/docker.sock`
  vanishes, `docker ps` fails. Fix: `open -a Docker`, wait for daemon, re-run `make up`.
- `forge` not on PATH after foundryup — `export PATH="$HOME/.foundry/bin:$PATH"`.
- Migrate target is `pf3-local-migrate-up` (dockerized migrate/migrate), NOT `migrate-up`.
- One bad line in a secrets file → direnv dotenv rejects the WHOLE file silently
  (Alchemy/Privy vars come up empty). Never leave unquoted placeholders.
- Stale submodule pin on pf3-smart-contracts → `cmd/deploy-spender-auth not found`.
  Fixed by detach: `git checkout --detach origin/main && git submodule update --init --recursive`.
- `tailwindcss` standalone CLI required for `make pf3-local-dev` (not in install-tools).
- Turbo strips server-only env (BLOB/Coinflow) — needs `turbo.json` `passThroughEnv`.
  Deferred: editing turbo.json pollutes the active preprod branch diff. Browse+login
  work without it. Only touch on a dedicated branch.
- m3 env comes from harness direnv (`services/m3/.envrc`), NOT `apps/main/.env.local`.
- nft_sync `dial tcp 127.0.0.1:50051 refused` is non-fatal (pf3-inventory, not in local-dev).

**When to spin the local stack:** full-stack tasks touching BOTH m3 + pf3-backend, or
any BE change where a live `curl localhost:8080/...` confirms behavior. Pure-FE
preprod tasks still verify via Vercel preview. Check `leadv2-local-stack.sh status`
first — don't blindly re-seed a running stack.

### Test cycle
```bash
make ginkgo focus="your test"   # specific integration test
make ginkgo                     # all integration tests (real HTTP → server → PG)
make test                       # unit + integration
make lint                       # golangci-lint
make build                      # build check
```

---

## Infrastructure access

### GKE clusters
- TODO: add GKE cluster names and kubectl context names (e.g. `gke_mythical-games_us-central1_pf-dev01`)
- TODO: confirm `kubectl config get-contexts` output with devops team

### Vault secrets
Paths: `secret/platform3/<service>/<env>/{db,redis,kafka,app}`
```bash
vault kv get secret/platform3/<service>/<env>/db
vault kv put secret/platform3/<service>/<env>/app KEY=value
# After secret change: pod restart required (Vault sidecar caches secrets)
kubectl rollout restart deployment/<service> -n platform3-<env>
```
Note: Vault auth method — TODO confirm (AppRole? k8s service account?)

### Kustomize overlay format
```yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
images:
  - name: go-service
    newName: us-docker.pkg.dev/mythical-games/platform3/go-service
    newTag: <service>-<sha:7>-<pipeline_number>
```
Validate: `cd environment-platform && kustomize build platform3/<service>/pf-dev01`

### Linkerd / mTLS
Services use Linkerd service mesh with mTLS between pods. Check `.claude/reference/` for linkerd-patterns.
TODO: confirm namespace injection annotations required for new services.

---

## Monitoring & Observability

### Grafana/Loki
- Prod: `https://mti-grafana-prod01.mythical.work` (orgId=12)
- Dev: `https://mti-grafana-dev01.mythical.work`

Common Loki queries:
```
{app="pf3-backend", container="app"}             # all logs
{app="pf3-backend", container="app"} |= "error"  # errors
{app="pf3-backend", container="app"} |= "matcher started"  # startup confirmation
```

### CircleCI
- UI: `https://app.circleci.com/pipelines/github/MythicalGames/<project>`
- API: `circleci workflow get <id>` / `circleci workflow approve <id> --job-name deploy_dev`

### Post-deploy checklist (backend)
1. Grafana/Loki — errors in first 5 minutes
2. ArgoCD — "Synced" + "Healthy"
3. CircleCI — integration tests passed (main only)
4. `curl https://market-api.pulse.xyz/api/health` → 200

---

## Services map
| Service | Responsibility |
|---------|---------------|
| pf3-web-gtw | BFF/API Gateway, HTTP→gRPC, ~20 upstream services |
| pf3-backend | Marketplace core: orders, offers, fees, NFT, nftsync, backoffice |
| pf3-catalog | NFT schema catalog |
| pf3-inventory | NFT inventory search |
| pf3-listing | Listing lifecycle |
| pf3-nft-executor | NFT transfer execution, block monitoring |
| pf3-metadata-hub | NFT metadata |
| pf3-webhook-notifier | Webhook delivery |
| pf3-directory | Auth/RBAC (Casbin) |
| pf3-dpayments | Payment gateway |
| pf3-ps-store | Primary Sales Store |

pf3-contract = central proto definitions, git submodule in all pf3-* services.

---

## Quality gates

### Frontend checks
```bash
cd m3 && pnpm type-check && pnpm build && npx sheriff verify
```
- No `any` without justification
- No direct library imports in apps
- No Privy in server components
- No hardcoded USDC decimals
- `'use client'` only where needed
- Imports use `@marketplace/*`
- No `console.log`

### Backend checks
```bash
cd pf3-backend && make build && make lint
```
- No `fmt.Println`/`log.Println` (use `slog`)
- No `panic` in prod code
- Errors wrapped with `%w`
- `context.Context` first param in all functions
- No modified `*.gen.go` / `*.pb.go`
- Idempotent migrations
- Parameterized SQL only

### Infrastructure checks
```bash
cd environment-platform && kustomize build platform3/<service>/pf-dev01
```
- No hardcoded secrets (Vault only)
- Specific image tags (never `:latest`)
- Resource requests/limits, probes, PDB, HPA
- Correct namespace

---

## Blockchain / Web3

- Privy (auth): production app ID `cmhugfp6k002tl90c9h07hn7b`
- Alchemy RPC: World L3 devnet `https://worldl3-devnet.g.alchemy.com/public`
- GCP KMS signing (NFT executor)
- Seaport protocol for NFT trades
- TODO: confirm mainnet chain IDs and Alchemy API key locations in Vault

---

## Git safety rules
- NEVER force-push to `main`
- MANDATORY back-merge `main → develop` after every prod release (prevents merge conflicts)
- Feature PRs: `preprod/<branch>` → `develop`
- Release PRs: `develop` → `main` (requires 1 review + Vercel status check)
- pf3-contract is a git submodule — update separately

---

## Visual verification after FE deploy — MANDATORY

After any FE commit pushed to a `preprod/*` branch (Vercel preview auto-deploys):

1. **Primary tool:** invoke `leadv2-gemini-ui-check` skill with URL `https://<branch-slug>.m3.mythical.work`
   - `agy` CLI is installed at `~/.local/bin/agy` — this is the Gemini browser backend
   - Works even without pre-configured Playwright auth cookies
2. **Fallback:** `leadv2-browser-check` skill (Playwright) if Gemini returns an error
3. **Last resort:** ask founder for manual screenshot with explicit checklist

**NEVER write "could not test" or "requires auth" without trying `agy` first.**

This applies in Phase 5 (Build) and Phase 10 (Async-Wait resume with FE changes).

---

## TODO / gaps (fill with devops team)
- GKE cluster names and kubectl context names
- Vault auth method (AppRole? k8s service account tokens?)
- ArgoCD login procedure (SSO? CLI token?)
- CircleCI environment variable names for secrets
- Mainnet chain IDs for World Chain (production)
- Alchemy production API key Vault path

## Dev-on-Codex routing (2026-06-22)
Route implementation to Codex (`codex-task.sh` / `codex:rescue` agent) when the task is self-contained / low integration risk, OR when a Sonnet developer got stuck (rescue / 2nd implementation). Keep integration-heavy pipeline work on Sonnet `developer` agents (they follow the handoff/off_limits subagent protocol). Codex has a separate quota — it does NOT consume the Opus/Sonnet usage budget, so prefer it for fitting work.

## Working faster — rules from the Braze epic retro (2026-08-20)

Four PRs and four ~30-minute pipelines went into what was **one** bug: "the recipient never
gets the email." Each deploy taught me the next layer, because I only ever measured up to the
edge of our own database. These rules exist so that stops repeating. They bind the lead.

### R1 — Measure across the outside boundary BEFORE writing code

The pipeline-walk rule ("boundary counts to the first zero") already exists in
`.claude/CLAUDE.md`. What I got wrong is where the pipeline ends: it does not end at our last
table, it ends **inside the third-party system**. Our row saying `sent` is not a send.

For any "X does not reach the user" bug, the first two numbers to put side by side are ours and
theirs, for the same day:

- ours: `select count(*) … where outcome='sent'`
- theirs: the vendor's own counter (Braze `campaigns/data_series`; for other vendors, whatever
  their delivery report is)

They must converge. If they do not, the bug is between us and the vendor and no amount of
reading our own code will find it. Corollary: identity/profile existence in the vendor is part
of the pipeline. `POST /users/export/ids` returning `invalid_user_ids` **is** a zero.

### R2 — Batch by root cause, not by ticket

Linear tickets are a planning unit, never a deploy unit. If two tickets close the same failure
mode, they are one PR. Code and the data migration that makes that code effective are **always**
one PR — shipping the code first and the data fix after is how 30 minutes becomes 60. Today's
concrete miss: PENG-812's ensurer and migration `000129` should have gone together; I knew about
the poisoned markers before I wrote the code and talked myself into "it self-heals in a day."

### R3 — When there is no local detector, build it once instead of deploying repeatedly

Prod became the only detector because nothing exercised resolve → vendor profile → trigger →
delivered outside prod. A single probe against a vendor sandbox (for Braze: the Development
workspace) that pushes one synthetic user through the whole path catches silent non-sends in
minutes. Building that probe is cheaper than the second extra deploy, and always cheaper than
the third. If a class of bug can only be seen in prod, that is a missing tool, not a fact of life.

### R4 — Never report delivery from our own status column

`outcome='sent'` counts attempts. Any completion claim about mail, push or webhook delivery cites
the vendor's number or says "unverified" in those words. See the memory
`braze-sent-outcome-over-reports`.

### R5 — Subagent missions: commit before verify, and expect the agent to die

Agents on this repo repeatedly die at the verification step, and twice today they died with
uncommitted work that I had to rescue by hand. Mission prompts order it explicitly: write →
`git add` the named files → commit → push → *then* vet/test/lint. The lead re-runs the checks
itself and reads real exit codes rather than trusting the agent's report.

### R6 — Re-verify current deployed behaviour BEFORE authoring a performance fix

The existing diagnosis protocol in `.claude/CLAUDE.md` is written for the moment a symptom appears.
This rule covers a different moment: the moment before writing the fix. Measure what is deployed
right now — `EXPLAIN (ANALYZE, BUFFERS)` against prod, not a hand-reconstructed query — and only
then write code. Evidence: PR #477 needed five CI rounds partly because the fix was authored
against a reconstruction, and on 2026-08-20 a candidate rewrite turned out to be an 8-13x
*regression* against what had already shipped, caught only by re-measuring first.

### R7 — A weak review is not a passed review

An agent that dies is obvious; an agent that finishes weakly is invisible. If a review returns a
single line, or stalled and resumed, or its verdict is a bare "looks standard" on a diff that
touches money, ordering, transactions or gating — it gets a second independent pass before its
verdict counts. Evidence: in the PENG-801 session the assigned reviewer saw an outbox-insert
failure that would roll back a real buy order, called it "standard defer rollback pattern
confirmed", and the P0 was caught only because the lead read the diff itself anyway.

### R8 — Three deploys against one bug is a circuit breaker, not a rhythm

Count deploys per underlying problem, not per ticket. The third deploy against the same
problem inside 72h stops the loop: no further PR opens until `07-architect` / `17-be-architect`
has reviewed the whole problem. `.claude/rules/05-opus-triggers.md` T5 already describes this
symptom in words; this makes it a number, because the words did not fire. Evidence: the Braze
epic ran to 14 prod deploys and the trait-offer facet saga to 8, neither with any stop.

**A note on all of R1-R8:** every one of them was written *after* the epic that taught it. The
audit's own sharpest finding is that the rules were not missing during the expensive part — some
of them existed and were applied one boundary short of where the bug was. Re-read this section
when opening a bug, not when closing one.

### R9 — Docker is available; the blanket "never run the app tests" ban was wider than the truth

Corrected 2026-08-20 after actually checking rather than repeating the rule. Docker Desktop runs on
this machine (28.5.1) once started, and with it a **narrow, named** testcontainers package runs
locally and passes — proven: `go test -timeout 520s -run 'Digest|Trait' ./app/traitoffers/...`
went green in 150s, which is the first time a container-backed pf3-backend test was ever run
outside CI here.

What still holds and what does not:

- **Still forbidden: `go test ./app/...`** — 27 container-backed specs at ~150s each is not a
  local test run, it is a hang, and the 600s watchdog kills the agent mid-edit.
- **Now allowed and expected: one named package with `-run` and an explicit `-timeout`.** If a
  change touches trait offers, run the trait-offer package before pushing. CI is no longer the
  only detector, and "I could not verify this locally" is no longer true by default.
- Docker does not start itself and cannot be started headlessly here — `open -a Docker` sat for
  over three minutes without a daemon. It needs the founder. Ask, do not fight it.

The general lesson, which is the same one as R1-R8: this rule survived for weeks as a hard "never",
and it was never re-tested against reality. A constraint that cannot be re-derived on demand is a
guess with seniority. Re-check the expensive ones.

### R10 — One agent never both builds and verifies

Four rescues in one day (PENG-811, 812, 813 twice), all the same shape: the mission said build AND
verify, verification costs 150s+ per container test here, and the agent died mid-edit with nothing
committed. Split it: a build agent whose stop condition is "committed and pushed", then a separate
verify agent — or the lead. Templates, including the exact stop-condition wording that works:
`.claude/leadv2-overrides/mission-templates.md`.

The verify half carries one non-obvious instruction: **prove it by breaking it.** Delete the
predicate the test is supposed to protect, watch the test go red, restore it. A passing test only
proves the code and the test agree.

### R11 — Never poll CI in a blocking foreground loop

CI runs whether or not anyone watches. A foreground poll loop buys nothing but the lead's own
wall-clock, and on 2026-08-20 that was several 10-minute blocks in a single session. Use
`.claude/scripts/ci-watch.sh <workflow-id> [gate|done]` with `run_in_background`: it prints one line
per state CHANGE, exits at the first actionable state, and the completion notification is the wake
signal. `gate` stops when an approval job is on_hold; `done` stops when the workflow finishes.

### R12 — Report email/webhook delivery from the reconciliation script, never from our own table

`.claude/scripts/braze-reconcile.sh [YYYY-MM-DD]` puts our `outcome='sent'` count next to Braze's
own `data_series` count and exits non-zero when they diverge. It distinguishes "no traffic" and
"could not measure" from "agrees" — a script that cannot reach the DB must never look like success.
First real run, 2026-08-20: `item_sold` 199 ours / 197 Braze (agrees), `item_offer` 120 / 86
(diverges 28%, dominated by the pre-fix morning window). Run it daily; the clean test of any fix is
a full day where the fix was live the whole time.

### R13 — One number per task: prod deploys spent per underlying bug

Log it on the task's line in `docs/leadv2/open-threads.md` when the task closes: `deploys=N`.
Target is 2 or fewer. Without the number this becomes a conversation about impressions again — the
August window ran to 14 deploys on one bug and 8 on another, and nobody noticed until it was counted.
