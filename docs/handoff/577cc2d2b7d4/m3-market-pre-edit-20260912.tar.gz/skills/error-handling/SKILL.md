---
name: error-handling
description: Use when implementing user-facing error UI or async error state in the m3 frontend. Triggers on Next.js error boundaries, TanStack Query `isError`/`onError`, or Zustand async action error handling. Covers `error.tsx` boundaries with reset, query error states, mutation `onError` toasts, and store status/error fields for async actions. Not for diagnosing WHY an error occurred (see error-detective) or backend error-handling strategy.
---

# Error Handling (React/TanStack/Zustand)

Next.js `error.tsx` boundaries take `{ error, reset }` and render a retry button. TanStack Query: check `isError`/`error` for reads, use mutation `onError` for toasts + `onSuccess` to invalidate queries. Zustand async actions track `status`/`error` fields and surface failures via toast.

Full reference: QUICKREF.md in this directory.
