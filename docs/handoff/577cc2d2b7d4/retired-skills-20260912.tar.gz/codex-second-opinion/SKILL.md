---
name: codex-second-opinion
effort: high
user-invocable: false
description: Dual planning — Claude and Codex both produce approaches, Claude synthesizes. Standard (with code) and Heavy tasks.
---

# Codex Second Opinion

For Standard (with code changes) and Heavy tasks, get an alternative approach from Codex before implementation. Claude synthesizes the best elements. User sees only the merged result.

## When to Run

- **Standard** tasks with code changes — second opinion before coding
- **Heavy** tasks (always) — strategy/architecture scope
- Triggered before coding begins (planning phase)
- **If using plan mode:** must complete BEFORE ExitPlanMode — plan file must contain the merged result
- Skip for Trivial, Light, Standard without code changes

## Flow

### Step 1: Gate Check

Verify task level:
- **Heavy:** always proceed
- **Standard + code changes:** proceed
- **Trivial / Light / Standard without code:** skip

### Step 2: Claude's Own Plan (First)

Before calling Codex, produce your own approach internally:
- Analyze the task requirements
- Consider project constraints (from CLAUDE.md, specs, persona rules)
- Draft approach, steps, risks

**Important:** Do this BEFORE seeing Codex's output to avoid bias.

### Step 3: Assemble Context

```bash
# Heavy tasks: full context
context=$(scripts/codex-context-bundle.sh --full)
# Standard tasks: smart context (smaller, faster)
context=$(scripts/codex-context-bundle.sh --smart)
```

### Step 4: Request Codex Plan

Call `/codex:rescue` with:

```
You are an architect reviewing a task for getmany-followup-bot, an autonomous expert-brand growth system for Threads.

TASK:
{task_description}

PROJECT CONTEXT:
{context_bundle}

INSTRUCTIONS:
1. Propose an implementation approach
2. List concrete steps with files to modify
3. Identify risks and edge cases
4. If you need clarification, return type="needs_clarification" instead

RESPONSE FORMAT:
Return JSON matching contracts/codex-response.schema.json with type="plan".
```

### Step 5: Question Proxy (if needed)

If Codex returns `type: "needs_clarification"`:

1. For each question with `answerable_from_project: true`:
   - Read the relevant file and answer from project knowledge
2. For remaining questions:
   - Combine with any Claude questions into single `AskUserQuestion`
3. Re-submit answers to Codex

Max 1 question round. If still unclear, proceed with Claude's plan only.

### Step 6: Synthesis

Compare both approaches across 4 axes:

**Completeness:**
- Did either miss requirements or edge cases?
- Take the union of both step lists (deduplicated)

**Risk Identification:**
- Merge both risk lists
- If one found risks the other missed, that's high signal

**Feasibility:**
- Given project constraints: bash scripts, Supabase, Hetzner VPS, systemd
- Given existing patterns in the codebase
- Reject approaches that contradict CLAUDE.md architecture

**Safety:**
- Alignment with persona guardrails
- Alignment with safety-overrides.json rules
- Medical claims, crisis detection, platform rules

### Step 7: Produce Merged Output

Create a single coherent plan that:
- Uses the strongest elements from both approaches
- Resolves conflicts (Claude's approach wins on project-specific decisions)
- Includes the combined risk list
- Follows the project's existing patterns

**Present to user as a single recommendation.** No mention of:
- "Two models were consulted"
- "Codex suggested..."
- "After comparing approaches..."

The user sees one clean plan.

### Step 8: Conflict Resolution

When approaches fundamentally disagree:

| Conflict type | Resolution |
|--------------|------------|
| Architecture/patterns | Claude wins (deeper project context) |
| Bug/edge case identification | Take the union (both may be right) |
| Risk assessment | More conservative wins |
| Implementation order | Claude wins (knows dependencies) |
| External API usage | Verify against docs, pick correct one |

## Fallback Rules — NEVER BLOCK

- Rate limit / token limit (429, "rate limit", "token limit") → skip immediately, use Claude's plan
- Codex timeout (>90s) → use Claude's plan
- Codex unavailable / auth expired → use Claude's plan
- Codex returns incoherent plan → ignore, use Claude's plan
- Codex returns needs_clarification after 1 round → use Claude's plan + partial result
- **If first Codex call in session failed → skip ALL subsequent Codex calls this session**

When skipping: log `[codex: skipped, {reason}]`. No degradation visible to user.

## What NOT to Do

- Never show two plans side-by-side to the user
- Never mention Codex's involvement
- Never delay presenting the plan waiting for Codex (if slow, proceed)
- Never let Codex override project-specific constraints from CLAUDE.md
- Never run on Trivial/Light tasks
- Never run on Standard tasks without code changes
