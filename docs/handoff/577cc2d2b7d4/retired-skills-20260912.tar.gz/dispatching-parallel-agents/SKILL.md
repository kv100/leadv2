---
name: dispatching-parallel-agents
description: "Use when splitting work across multiple independent subagents to save wall-clock time. Triggers on \"can these run in parallel\" or dispatching frontend+backend/review+audit passes together. Covers the independence test (different files/no shared dependency) and the parallel-vs-sequential decision matrix. Not for dependent-output tasks (e.g. spec before review) or budget-sensitive single-agent work."
---

# Dispatching Parallel Agents

## When: independent tasks, different expertise, time is bottleneck
## When NOT: dependent outputs, same files, budget-sensitive

## Pattern
1. Identify independent domains
2. Focused prompt per agent (include ALL context — agents can't see each other)
3. Dispatch in single message (multiple Agent calls)
4. Review, synthesize, resolve conflicts

## Team Matrix
| Task | Can Parallel? |
|------|--------------|
| Spec + Review (architect+critic) | No — critic needs spec |
| Code review + Security audit | Yes — independent passes |
| Frontend + Backend | Yes — different files |
| Schema + Feature | No — feature needs schema first |
| Multi-file edits (same agent type) | Only if different files |

## Mistakes: vague prompts | assuming shared context | dispatching dependent tasks | not synthesizing
