---
name: idea-validator
description: "Use before committing resources to a new feature or product idea. Triggers on \"should we build this\", early-stage feature proposals, or product-market-fit questions. Covers the Lean Canvas (problem, segments, UVP, solution, revenue, cost, metrics, moat) and a weighted scoring rubric with explicit decision gates. Not for already-committed work or incremental improvements to an existing shipped feature."
---

# Idea Validator — Business Idea Validation

## When: evaluating new feature or product idea before committing resources
## When NOT: already committed, incremental improvement to an existing working feature

## Lean Canvas (fill every section before scoring)
1. Problem — top 3 problems, existing alternatives customers use today
2. Customer Segments — early adopters: who specifically, what characteristics
3. Unique Value Prop — single clear compelling message, why buy from us not them
4. Solution — top 3 features, one per problem
5. Revenue Streams — model, LTV estimate, gross margin estimate
6. Cost Structure — CAC estimate, distribution, hosting, people
7. Key Metrics — what to measure to know it's working
8. Unfair Advantage — cannot be easily copied or bought

## Scoring (fill independently before comparing)
| Dimension | Weight | Score 1–5 | Weighted |
|---|---|---|---|
| Problem clarity | 25% | | |
| Market size | 20% | | |
| Solution uniqueness | 20% | | |
| Revenue viability | 20% | | |
| Execution feasibility | 15% | | |

## Decision gate
< 3.0 → stop, address gaps before any resourcing
3.0–3.9 → proceed with explicit risk acknowledgment
≥ 4.0 → green light

## Anti-patterns
- Scoring without completing Lean Canvas (guess-scoring)
- Skipping Unfair Advantage ("we'll figure it out") — it's the most revealing section
- Consensus scoring in a group — score independently first, then compare
