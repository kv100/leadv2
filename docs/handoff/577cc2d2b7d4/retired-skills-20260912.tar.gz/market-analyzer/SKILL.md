---
name: market-analyzer
description: "Use when sizing a new market or opportunity for investor prep or feature prioritization. Triggers on TAM/SAM/SOM estimation, competitive-landscape requests, or market-trend analysis. Covers bottom-up/top-down TAM sizing, SAM/SOM filtering with explicit assumptions, CAGR/tailwind/headwind analysis, and competitor positioning output format. Not for internal-tooling-only features with no commercial application."
---

# Market Analyzer — TAM/SAM/SOM + Competitive Landscape

## When: sizing a new market, validating opportunity, investor prep, feature prioritization
## When NOT: internal tooling only, no commercial application

## TAM / SAM / SOM
1. **TAM** — everyone who could need this, globally
   - Bottom-up preferred: (# potential customers) × (avg annual spend per customer)
   - Top-down fallback: industry report × relevant segment %
2. **SAM** — TAM filtered by real constraints: geography, language, distribution reach, regulation
3. **SOM** — SAM × realistic share in 3 years (early-stage honest range: 0.5–3%)

For each number: state the assumption explicitly, not just the figure.

## Trend Analysis
- Market CAGR: last 3 years actuals + analyst projected 3 years
- 3 tailwinds accelerating adoption
- 2 headwinds / risks that could slow or kill it

## Competitive Landscape
- Direct competitors: top 5, positioning, pricing tier, growth signal
- Winner-take-all or fragmented? (affects go-to-market strategy)
- Are incumbents growing or losing share?
- Customer switching cost: high / medium / low — and why

## Output format
```
TAM: $Xb — assumption: [one sentence]
SAM: $Xm — filtered by: [constraints]
SOM: $Xm — based on: [market share logic]
Confidence: High / Medium / Low per figure
Top risk: [one sentence]
Key insight: [what's non-obvious about this market]
```
