---
name: skill-distiller
description: "Use when a skill runs too slowly/expensively and its steps are largely mechanical rather than judgment-based. Triggers on a cost-optimization pass for an existing skill. Covers the 5-step distillation protocol (profile mechanical-vs-reasoning steps, extract, compress into rules/templates/lookup tables, validate against the same cases, document what was removed). Not for skills requiring genuine novel synthesis or adversarial judgment (e.g. devils-advocate)."
---

# Skill Distiller — Opus-Quality → Haiku-Executable Compression

## When: skill runs slowly or expensively, cost optimization pass, skill uses judgment for mechanical steps
## When NOT: skills requiring genuine novel synthesis, adversarial evaluation, ambiguous judgment calls

## Distillation Protocol
1. **Profile** — run skill 5×, categorize each step: mechanical vs reasoning
2. **Separate** — extract mechanical steps (lookup, format, validate, classify)
3. **Compress** — replace mechanical steps with: rules, decision trees, regex, lookup tables
4. **Validate** — run distilled version on same 5 cases, compare output quality
5. **Document** — note what was removed and why it's safe to remove

## What survives distillation (→ rules/templates)
- Pattern matching → keyword lists or regex
- Formatting → explicit templates
- Validation → checklists with yes/no criteria
- Simple classification → decision tree with ≤ 3 branches

## What cannot be distilled (keep Sonnet/Opus)
- Novel synthesis across multiple sources
- Judgment under genuine ambiguity
- Multi-hop reasoning chains
- Adversarial evaluation (critic, devil's advocate)

## Output: distilled SKILL.md + removed-reasoning.md (what dropped + why safe)
