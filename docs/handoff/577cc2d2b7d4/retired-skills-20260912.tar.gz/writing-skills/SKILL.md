---
name: writing-skills
description: "Use when creating a new Claude skill or rewriting an existing one. Triggers on \"write a skill for X\" or skill-quality review requests. Covers the required structure (title, When/When-NOT triggers, numbered mechanical steps, constraints, anti-patterns) and the one-screen quality bar. Not for using an existing skill or a one-off task that won't repeat."
---

# Writing Skills

## When: creating a new skill, rewriting an existing one
## When NOT: using an existing skill, one-off task that won't repeat

## Structure (required)
1. Title — one line, imperative verb
2. When: / When NOT: — observable triggers, not vague ("when needed")
3. Steps — numbered, max 6, each under 20 words, mechanical not judgmental
4. Constraints — what it must never do
5. Anti-patterns — common failures with examples

## Quality bar
- Fits on one screen (< 25 lines)
- Triggers are observable facts, not vibes
- Steps are executable without another skill to interpret them
- Has explicit "When NOT" to prevent over-triggering
- No throat-clearing or preamble — start with title

## Anti-patterns
- Steps that say "consider X" or "think about Y" — name the action
- Missing failure modes
- Explaining WHAT instead of HOW
- Skill that wraps another skill with no added specificity
