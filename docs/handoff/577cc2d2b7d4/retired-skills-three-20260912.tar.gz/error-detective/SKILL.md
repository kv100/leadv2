---
name: error-detective
user-invocable: false
description: Systematic error analysis and debugging for getmany-followup-bot platform.
---

# Error Detective

## Methodology: Work Backwards
1. **Symptoms** → What error/behavior was observed?
2. **Timeline** → When did it start? What changed? (`git log --since`)
3. **Scope** → One persona or all? One agent or all?
4. **Reproduction** → Can it be triggered with `DRY_RUN=true`?
5. **Root Cause** → Trace from symptom to source

## Common Failure Patterns
| Symptom | Likely Cause | Check |
|---------|-------------|-------|
| Agent hangs | LLM timeout | Check LLM_BACKEND, API key validity |
| Post not published | Safety gate block | Check safety gate logs |
| Duplicate actions | Missing dedup check | Check action_lifecycle table |
| Session not starting | Scheduler config | Check timing-config.json, quiet hours |
| Browser errors | Proxy/session issue | Check Patchright profile, proxy status |

## Debugging Checklist
- [ ] Check server status: `systemctl status getmany-followup-bot`
- [ ] Check recent logs for errors
- [ ] Check Supabase for failed actions
- [ ] Check if it's a known pattern in codex-learnings.md
- [ ] Reproduce locally with DRY_RUN=true if possible
