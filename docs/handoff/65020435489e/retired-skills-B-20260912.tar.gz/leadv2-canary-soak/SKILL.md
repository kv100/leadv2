---
name: leadv2-canary-soak
description: Use during Phase-7.5, after a canary (cascina-tiglio) deploy completes and before prod (respiro) promotion, when LEADV2_STAGE=both. Auto-invoked from deploy.sh — probes Supabase for canary liveness and crash-free status. Not for single-stage (canary-only or prod-only) deploys, which skip this gate entirely.
---

# leadv2-canary-soak — Phase-7.5 Invariant Watchdog

Internal skill. Auto-invoked by `deploy.sh` after canary (cascina-tiglio) deploy completes, before prod (respiro) promotion. Part of STAB-SPRINT-16 / STRAT-STABILITY-01.

## Trigger

Called from `.claude/leadv2-overrides/deploy.sh` when `LEADV2_STAGE=both` (canary deployed, prod pending). Not called when `LEADV2_STAGE=canary` (canary-only run) or `LEADV2_STAGE=prod` (prod-only, no canary gate needed).

Manual invocation: `bash .claude/scripts/canary-soak-probe.sh [--simulate-breach]`

## What it does

Runs a local invariant probe against the canary persona (Marco / cascina-tiglio) using the Supabase API. No SSH required.

**Checks:**
1. **Liveness** — `action_log` has at least one entry from Marco persona within the last 4 hours. Confirms engine ran at least one cycle post-deploy (Marco fires on a timer, not continuously).
2. **Crash-free** — `action_log` has no `status = 'error'` rows for Marco in the last 4 hours.

**Exit codes:**
- `0` (SOAK_OK) — all checks pass; prod promotion may proceed
- `1` (SOAK_FAIL) — any check fails, Supabase unreachable, or SSH key absent; prod promotion blocked

**Flags:**
- `--simulate-breach` — exits 1 immediately without any Supabase call. Used for acceptance tests and CI smoke tests.

## deploy.sh integration (STAB-SPRINT-07 → STAB-SPRINT-16)

```
STAGE=both flow:
  1. deploy canary (cascina-tiglio)     ← STAB-SPRINT-07
  2. canary-soak-probe.sh               ← STAB-SPRINT-16 (this skill)
     exit 1 → abort; prod NOT deployed
     exit 0 → continue
  3. deploy prod (respiro)
```

`LEADV2_STAGE=both` is the only stage that runs the soak gate. Single-stage deploys (`canary` or `prod`) skip it.

## Environment

Reads from environment (same as deploy.sh):
- `SUPABASE_URL` — project URL
- `SUPABASE_SERVICE_ROLE_KEY` — read-only queries only
- `MARCO_PERSONA_SLUG` — slug of Marco persona (default: `cascina-tiglio`). If not set, falls back to `MARCO_PERSONA_ID` for backward compat with older callers.

`SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` must be set; absent → SOAK_FAIL. `MARCO_PERSONA_SLUG` defaults to `cascina-tiglio` if neither it nor `MARCO_PERSONA_ID` is set.

## Acceptance criteria (STAB-SPRINT-16)

1. `canary-soak-probe.sh --simulate-breach` exits 1
2. With valid Supabase env and Marco action_log entry < 4h old → exits 0
3. `deploy.sh` with `LEADV2_STAGE=both` exits 1 if soak fails; respiro NOT touched
4. Missing `SUPABASE_SERVICE_ROLE_KEY` → SOAK_FAIL (not silent pass)
