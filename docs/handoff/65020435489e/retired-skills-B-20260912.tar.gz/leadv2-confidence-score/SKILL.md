---
name: leadv2-confidence-score
description: "[internal] Deterministic autopilot confidence scorer — bash, no LLM"
allowed-tools: [Bash]
---

# Confidence Scorer

## Purpose

Standalone bash scorer that reads breach event signals from env vars and emits a deterministic
`{ confidence, chosen_action, rationale }` JSON line. No LLM call. Same inputs always produce
the same output. Designed to gate or lower autopilot confidence before trigger.sh executes.

Script: `.claude/scripts/confidence-score.sh`

## Inputs — env var table (D6)

| Env var                              | Type       | Default | Description                                    |
|--------------------------------------|------------|---------|------------------------------------------------|
| `CONFIDENCE_SCORE_PROPOSED_ACTION`   | string     | —       | Required. Action Opus proposed (closed enum).  |
| `CONFIDENCE_SCORE_INV_ID`            | string     | —       | Required for hard-limit pattern check.         |
| `CONFIDENCE_SCORE_BREACH_CLASS`      | string     | `""`    | Event breach class (drives action mapping).    |
| `CONFIDENCE_SCORE_RECENT_BREACH_COUNT` | int      | `0`     | Breach count for this signature in past 24h.   |
| `CONFIDENCE_SCORE_COOLDOWN_ACTIVE`   | true/false | `false` | Whether signature is inside cooldown window.   |
| `CONFIDENCE_SCORE_GIT_DIFF_SENSITIVE`| true/false | `false` | Whether current git diff touches sensitive paths. |
| `CONFIDENCE_SCORE_FLAG_TOGGLE_COUNT` | int        | `0`     | Count of recent feature-flag toggles.          |
| `CONFIDENCE_SCORE_POLICY_FILE`       | path       | `.claude/leadv2-overrides/stability-policy.yaml` | Override policy file path. |

## Output JSON schema

```json
{
  "confidence": 0.75,
  "chosen_action": "escalate",
  "rationale": "recent_breach_count>=3:-0.3,cooldown_active:-0.15,score_below_threshold(0.8):coerced_to_escalate"
}
```

- `confidence`: float in `[0.0, 1.0]`
- `chosen_action`: one of `systemctl_restart | control_sync | clear_state_files | escalate | noop`
- `rationale`: comma-separated deduction tags
- Always exits 0; errors emit `confidence=0.0, chosen_action=escalate` to stdout + message to stderr.

## Signal → score-delta table (D3)

Base score: `1.0`. Deductions are additive. Result clamped to `[0.0, 1.0]`.

| Signal                        | Condition           | Deduction |
|-------------------------------|---------------------|-----------|
| `recent_breach_count`         | `>= 3`              | `-0.3`    |
| `breach_class` severity       | contains `"crit"`   | `-0.2`    |
| `cooldown_active`             | `true`              | `-0.15`   |
| `git_diff_sensitive`          | `true`              | `-0.1`    |
| `flag_toggle_count`           | `>= 1`              | `-0.05`   |
| `hard_limit_pattern_match`    | any match           | force `0.0` |
| `action_not_whitelisted`      | not in enum/policy  | force `0.0` |

Score `< confidence_threshold` (default `0.8`, read from policy) → `chosen_action` coerced to `"escalate"`.

## Action-mapping table (D4)

Ordered first-match on `CONFIDENCE_SCORE_BREACH_CLASS`:

| Match              | Candidate action      |
|--------------------|-----------------------|
| `*service*`        | `systemctl_restart`   |
| `*config*`/`*sync*`| `control_sync`        |
| `*state*`/`*stale*`| `clear_state_files`   |
| (default)          | `escalate`            |

Whitelist re-validates: `systemctl_restart` needs non-empty `WL_RESTART_UNITS`; `control_sync` needs `WL_CONTROL_SYNC=true`; otherwise downgrades to `escalate`.

## Hard-limit pattern false-match risk

> **WARN:** `hard_limit_invariant_patterns` entries are bare substrings matched case-insensitively against both `CONFIDENCE_SCORE_INV_ID` and `CONFIDENCE_SCORE_BREACH_CLASS`. Patterns like `key` or `post` (from policy) will match any inv_id containing those strings as a non-initial subword — e.g. `monkey_check`, `turnkey_op`, `postprocess_eval`. Such matches produce `confidence=0.0 + escalate` (fail-safe, but noisy false-positives). Operators **must not** use subwords from `hard_limit_invariant_patterns` inside invariant ID names. Review policy patterns before naming new invariant IDs.

## Integration contract (D2 follow-up — not in STAB-SPRINT-17)

After trigger.sh line ~673 (where `confidence` is read from Opus JSON), add:

```bash
det_result=$(bash "$SCRIPT_DIR/confidence-score.sh")
det_confidence=$(printf '%s' "$det_result" | json_field_float confidence)
# effective_confidence = min(opus_confidence, deterministic_confidence)
if python3 -c "import sys; sys.exit(0 if float(sys.argv[1]) < float(sys.argv[2]) else 1)" \
    "$det_confidence" "$confidence" 2>/dev/null; then
  confidence="$det_confidence"
fi
```

This only potentially lowers confidence — it never raises it. No existing gate logic changes.

## Example invocation

```bash
export CONFIDENCE_SCORE_PROPOSED_ACTION=control_sync
export CONFIDENCE_SCORE_BREACH_CLASS=config_drift
export CONFIDENCE_SCORE_RECENT_BREACH_COUNT=0
export CONFIDENCE_SCORE_INV_ID=cfg_sync_check
bash .claude/scripts/confidence-score.sh
# {"confidence": 1.0, "chosen_action": "control_sync", "rationale": "no_deductions_applied"}
```
