---
name: leadv2-soak-watch
description: Phase-7.5 soak invariant watch + auto-rollback on canary breach.
---

# leadv2-soak-watch — Phase-7.5 Auto-Rollback

Extends `leadv2-canary-soak` (the probe). That skill defines what is checked; this skill defines what happens when the probe fails.

**Do NOT modify `canary-soak-probe.sh` or `leadv2-canary-soak/SKILL.md`.**

## When invoked

After canary deploy completes, before prod promotion — during `LEADV2_STAGE=both` flow:

```
1. deploy canary (cascina-tiglio)
2. canary-soak-probe.sh        ← leadv2-canary-soak (probe gate)
   exit 0 → promote to prod
   exit 1 → (this skill) BREACH RESPONSE
3. deploy prod (respiro)        ← skipped on breach
```

## Breach response (exit 1 from probe)

```bash
# Step A — fleet rollback to pre-deploy SHA
bash agent/deploy/rollback-fleet.sh \
  --task-id <task_id> \
  --yes

# Step B — file RECOVERY task in docs/tasks.yaml
# Append to docs/tasks.yaml:
# - id: RECOVERY-<task_id>
#   lane: recovery
#   priority: P0
#   parent: <task_id>
#   status: open
#   title: "Soak breach recovery for <task_id>"
#   created_at: <ISO timestamp>
```

`<task_id>` is the current leadv2 task being deployed (from `context.yaml.task_id`).

## Manual trigger

```bash
# Simulate breach to test the response path:
bash .claude/scripts/canary-soak-probe.sh --simulate-breach
# expect exit 1 → then run breach response above
```

## Acceptance criteria

1. `canary-soak-probe.sh --simulate-breach` exits 1 (probe responsibility)
2. This skill file present and references `rollback-fleet.sh` (docs acceptance)
3. `bash agent/deploy/rollback-fleet.sh --task-id TEST --dry-run` exits 0

## References

- Probe: `.claude/skills/leadv2-canary-soak/SKILL.md` + `.claude/scripts/canary-soak-probe.sh`
- Rollback: `agent/deploy/rollback-fleet.sh`
- Manifest written by Phase-6 deploy: `docs/handoff/<task-id>/deploy-manifest.yaml`
- Recovery tasks: `docs/tasks.yaml`
