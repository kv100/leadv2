---
name: anthropic-caching
description: "Use when tuning Anthropic prompt caching, setting cache_control breakpoints, debugging cache hit rates in Claude API calls, or reducing token costs on repeated system prompts and tool definitions."
---

# Anthropic Prompt Caching

Anthropic's native prompt caching lets you mark stable prefix blocks with `cache_control: { type: "ephemeral" }` so repeated API calls skip re-tokenizing those blocks. This cuts input token costs by ~90% and reduces latency up to 2x on cached turns. Reach for it whenever you have a large, stable system prompt, a knowledge base, or a long tool list that repeats across many calls.

## When to use
- Large system prompt (>1000 tokens) reused across multiple calls
- Tool definitions list that doesn't change per request
- Multi-turn conversation where the system block is stable
- RAG-style patterns where you pre-load a document corpus into the prefix (CAG)
- Debugging unexpectedly high `cache_creation_input_tokens` costs

## When NOT to use
- Single one-off calls — cache warm-up cost exceeds savings
- Dynamic content (timestamps, per-user state) that must live in the prefix — cache will always miss
- Response-level caching (full LLM output for identical queries) — that is a separate Redis/KV concern not covered here

## Core patterns

### 1. Marking cache breakpoints

Place `cache_control` on the last block you want cached. Everything up to and including that block is the cacheable prefix. The 5-minute TTL resets on each cache hit; the `ephemeral` flag is the only supported type.

```python
import anthropic

client = anthropic.Anthropic()  # uses ANTHROPIC_API_KEY or CLAUDE_CODE_OAUTH_TOKEN

response = client.messages.create(
    model="claude-sonnet-5",
    max_tokens=1024,
    system=[
        {
            "type": "text",
            "text": STATIC_SYSTEM_PROMPT,          # stable instructions
            "cache_control": {"type": "ephemeral"}  # cache up to here
        },
        {
            "type": "text",
            "text": KNOWLEDGE_BASE_TEXT,            # stable reference docs
            "cache_control": {"type": "ephemeral"}  # extend cache to here
        }
    ],
    messages=[{"role": "user", "content": user_query}]  # dynamic — NOT cached
)

print(response.usage.cache_read_input_tokens)    # tokens read from cache
print(response.usage.cache_creation_input_tokens) # tokens written to cache
```

### 2. Caching tool definitions

Tool definitions are large and static. Cache them by placing `cache_control` on the last tool entry.

```python
tools = [
    {"name": "search", "description": "...", "input_schema": {...}},
    {
        "name": "publish",
        "description": "...",
        "input_schema": {...},
        "cache_control": {"type": "ephemeral"}  # cache entire tools list
    }
]
response = client.messages.create(model="...", tools=tools, messages=[...])
```

### 3. Multi-turn conversation caching

In a chat loop, mark the system block and the last assistant turn. New user messages append after the cached prefix — the prefix itself never changes, so the cache stays warm.

```python
def chat_turn(history: list, user_msg: str) -> str:
    messages = history + [{"role": "user", "content": user_msg}]
    response = client.messages.create(
        model="claude-sonnet-5",
        max_tokens=512,
        system=[{"type": "text", "text": SYSTEM, "cache_control": {"type": "ephemeral"}}],
        messages=messages
    )
    history.append({"role": "user", "content": user_msg})
    history.append({"role": "assistant", "content": response.content[0].text})
    return response.content[0].text
```

### 4. TTL and hit-rate expectations

- Default TTL: **5 minutes** from last use. Claude Code itself uses this window.
- Extended TTL: **1 hour** (available via a flag on some model tiers — check API docs for your account).
- A cache write on turn 1 costs the same as a normal input token. Turn 2+ reads at ~10% of input cost.
- If `cache_read_input_tokens == 0` on turn 2, the prefix changed — see pitfalls below.

## Common pitfalls (our codebase)

- **Dynamic content in cached prefix** — Any timestamp, request ID, or per-call value inside a `cache_control` block causes every call to be a cache miss. Move dynamic content into `messages`, not `system`.
- **OAuth vs API key** — Our stack uses `CLAUDE_CODE_OAUTH_TOKEN` for Claude Code CLI calls and `ANTHROPIC_API_KEY` for SDK calls in the platform backend. Caching works with both, but the client must be initialized with the right credential source — they are not interchangeable.
- **Wrong block ordering** — Anthropic caches the prefix up to each `cache_control` marker. If you add a block before the marker that varies per call, the marker position shifts and busts the cache.
- **No cache metrics logged** — Without reading `response.usage.cache_read_input_tokens`, you cannot tell if caching is working. Always log both fields in staging.

## Verification
- `cache_creation_input_tokens > 0` and `cache_read_input_tokens == 0` on first call — correct warm-up
- `cache_read_input_tokens > 0` on subsequent calls within TTL — cache is working
- Input token cost drops ~90% on cached turns vs uncached baseline
- Zero `cache_read_input_tokens` despite identical prompt — inspect for dynamic content in the cached block
