---
name: async-python
description: "Use when writing or reviewing asyncio code in the Python backend — TaskGroup structured concurrency, cancellation propagation, async context managers, httpx/supabase-py/anthropic async clients, backpressure patterns."
---

# Async Python Patterns

The backend is Python 3.11+ using `asyncio`. All I/O paths — Supabase
PostgREST, Anthropic SDK, httpx HTTP calls — are async. This skill covers the
patterns we use: structured concurrency with `TaskGroup`, cancellation
propagation, async context managers for resource cleanup, async generators for
streaming, and `asyncio.Semaphore` for backpressure against external APIs.

## When to use
- Writing concurrent calls to Supabase, Anthropic, or httpx
- Propagating cancellation correctly through nested tasks
- Building async generators that stream LLM output
- Limiting concurrency with semaphores (API rate limits)
- Designing cleanup in async context managers

## When NOT to use
- CPU-bound work (use a subprocess, not asyncio)
- One-off scripts with a single sequential I/O call (plain `asyncio.run` is enough)
- Comparing threading vs asyncio — we are asyncio-only on all I/O paths

## Core patterns

### TaskGroup: structured concurrency (Python 3.11+)

```python
import asyncio

async def fetch_context(persona_id: str) -> dict:
    async with asyncio.TaskGroup() as tg:
        profile_task   = tg.create_task(get_persona_profile(persona_id))
        knowledge_task = tg.create_task(query_rag(persona_id))
        recent_task    = tg.create_task(get_recent_actions(persona_id))
    # All three finish (or the group raises ExceptionGroup) before here
    return {
        "profile":  profile_task.result(),
        "knowledge": knowledge_task.result(),
        "recent":   recent_task.result(),
    }
```

`TaskGroup` cancels all sibling tasks when any one raises. Prefer it over
`asyncio.gather` for structured fan-out. Use `gather(return_exceptions=True)`
only when you want partial results despite failures.

### Cancellation propagation — always re-raise

```python
async def run_with_cleanup(resource):
    try:
        await do_work(resource)
    except asyncio.CancelledError:
        await resource.cleanup()   # release locks, close connections
        raise                      # MUST re-raise — never swallow CancelledError
```

Swallowing `CancelledError` leaves parent tasks waiting forever. The only safe
pattern is cleanup → re-raise.

### Async context managers for external clients

```python
import httpx
from contextlib import asynccontextmanager

@asynccontextmanager
async def http_client():
    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
        yield client

# Usage — connection pool is always closed, even on exception
async def fetch_url(url: str) -> bytes:
    async with http_client() as client:
        resp = await client.get(url)
        resp.raise_for_status()
        return resp.content
```

Re-use a single client across a request lifetime rather than creating one per call.

### Anthropic async client

```python
import anthropic

client = anthropic.AsyncAnthropic()  # re-use at module level

async def call_llm(prompt: str) -> str:
    message = await client.messages.create(
        model="claude-sonnet-5",
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
    )
    return message.content[0].text
```

### Streaming LLM output with async generator

```python
from typing import AsyncIterator

async def stream_llm(prompt: str) -> AsyncIterator[str]:
    async with client.messages.stream(
        model="claude-sonnet-5",
        max_tokens=2048,
        messages=[{"role": "user", "content": prompt}],
    ) as stream:
        async for text in stream.text_stream:
            yield text
```

Callers consume with `async for chunk in stream_llm(prompt)`. Avoid collecting
to a list unless you need the full response at once.

### Semaphore for API backpressure

```python
# Module-level semaphore — limits concurrent Anthropic calls to 3.
_anthropic_sem = asyncio.Semaphore(3)

async def safe_llm_call(prompt: str) -> str:
    async with _anthropic_sem:
        return await call_llm(prompt)

async def score_batch(items: list[str]) -> list[str]:
    tasks = [safe_llm_call(item) for item in items]
    return await asyncio.gather(*tasks)
    # gather dispatches all tasks but only 3 run concurrently
```

### Supabase async client pattern

```python
from supabase._async.client import AsyncClient

async def upsert_action(client: AsyncClient, action: dict) -> dict:
    result = await (
        client.table("actions")
        .upsert(action, on_conflict="id")
        .execute()
    )
    if result.data:
        return result.data[0]
    raise RuntimeError(f"Upsert failed: {result}")
```

Always `await` the `.execute()` call. Forgetting the await returns a
coroutine object, not data — silent bug with no TypeError.

### Timeout guard

```python
async def fetch_with_timeout(url: str, timeout_s: float = 10.0) -> dict:
    try:
        return await asyncio.wait_for(fetch_url(url), timeout=timeout_s)
    except asyncio.TimeoutError:
        raise RuntimeError(f"Timeout after {timeout_s}s fetching {url}")
```

## Common pitfalls (our codebase)

- **Swallowing CancelledError.** A bare `except Exception` that catches
  `CancelledError` breaks structured concurrency. Use `except asyncio.CancelledError:
  ...; raise` or narrow the except to specific error types.
- **Forgetting `await` on supabase `.execute()`.** Returns a coroutine object
  silently — the insert never happens, no exception is raised.
- **`asyncio.run()` inside an already-running loop.** This happens in Jupyter
  or if called from a sync function inside an async path. Use
  `await coro()` directly, or `asyncio.get_event_loop().run_until_complete()`
  as a last resort.
- **Blocking calls inside async functions.** `time.sleep()`, `requests.get()`,
  or any synchronous DB driver blocks the event loop. Use `await asyncio.sleep()`,
  `httpx.AsyncClient`, and `supabase-py` async client respectively.
- **Creating a new `httpx.AsyncClient` per call.** Each client opens a
  connection pool. Reuse a single client via an async context manager or
  module-level singleton.
- **`gather` with no error strategy.** Default `gather` re-raises the first
  exception and leaves other tasks running. Use `TaskGroup` for automatic
  sibling cancellation, or `gather(return_exceptions=True)` when partial
  results are acceptable.

## Verification

- `asyncio.get_event_loop().is_running()` inside a test should be True when
  using `pytest-asyncio` with `asyncio_mode = "auto"`.
- Add `asyncio.timeout(30)` around any external I/O in tests to prevent
  infinite hangs on mocked clients that never resolve.
- `mypy --strict` catches missing `await` on coroutines as an error.
