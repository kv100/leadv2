---
name: auth-store-snapshot
description: Single-shot truth table of all auth state for a persona — cookies.enc keys present, instagrapi pickle TTL, browser daemon socket, dashboard Connected value, latest auth_health/comment action_log rows. Triggered by "auth snapshot <persona>", "что с авторизацией <persona>", "auth-store-snapshot". Use when "Connected" looks misleading or comments fail and you can't tell which auth layer broke.
---

# /auth-store-snapshot

Single-shot truth table of all auth state for a persona, across all 3 cookie stores + DB + dashboard. Use when "Connected" badge looks misleading or when comments fail and you can't tell which auth layer broke.

See `docs/specs/AUTH_ARCHITECTURE.md` for the 3-store / 3-protocol model.

## When to trigger
- "Connected" badge green but founder reports broken behavior.
- Comment publish returns `auth_expired` / `challenge_required`.
- After a relogin flow — verify post-flow state landed in the right store.
- Daily as part of `/audit-personas` health pass.

## Procedure (read-only — never triggers relogin)

```bash
PERSONA="$1"
REPO=/home/claudebot/persona-engine     # adjust per VPS

# 1. cookies.enc — the canonical write-path store
source "$REPO/platform/session/discovery-auth.sh"
bundle=$(_da_load_bundle_raw "$PERSONA" 2>/dev/null || echo '{}')
echo "cookies.enc:"
for k in sessionid ds_user_id csrftoken ig_did mid; do
  v=$(echo "$bundle" | jq -r ".cookies.$k // empty")
  printf "  %s=%s\n" "$k" "$( [[ -n "$v" ]] && echo YES || echo NO )"
done

# 2. instagrapi pickle — ephemeral 2FA bridge (expected absent between flows)
echo "instagrapi 2FA pickle:"
ls -la /tmp/pe-mobile-session-* 2>/dev/null | head -3 || echo "  none (expected)"

# 3. Browser daemon socket
echo "browser daemon:"
sock="/tmp/.pe-browser-${PERSONA}.sock"
if [[ -S "$sock" ]]; then
  printf '%s\n' '{"action":"healthcheck"}' \
    | timeout 5 socat -t 4 - UNIX-CONNECT:"$sock" 2>/dev/null \
    | jq -c '{ok, state, uptime_s}'
else
  echo "  socket absent (daemon idle — normal between scans)"
fi

# 4. Dashboard Connected from Supabase
curl -s "$SUPABASE_URL/rest/v1/personas?select=config&slug=eq.$PERSONA" \
  -H "apikey: $SUPABASE_KEY" -H "Authorization: Bearer $SUPABASE_KEY" \
  | jq -r '.[0].config.threads.connected // "unset"' \
  | xargs -I{} echo "dashboard.personas.config.threads.connected: {}"

# 5. Latest auth_health row
curl -s "$SUPABASE_URL/rest/v1/action_log?select=created_at,status,status_reason&persona_id=eq.$PERSONA&action_type=eq.auth_health&order=created_at.desc&limit=1" \
  -H "apikey: $SUPABASE_KEY" -H "Authorization: Bearer $SUPABASE_KEY" \
  | jq -r '.[0] | "last auth_health: \(.created_at) \(.status)/\(.status_reason)"'

# 6. Latest confirmed comment
curl -s "$SUPABASE_URL/rest/v1/action_log?select=created_at,target&persona_id=eq.$PERSONA&action_type=like.*comment*&status=eq.confirmed&order=created_at.desc&limit=1" \
  -H "apikey: $SUPABASE_KEY" -H "Authorization: Bearer $SUPABASE_KEY" \
  | jq -r '.[0] | "last confirmed comment: \(.created_at) \(.target)"'
```

## Interpretation
- `sessionid=NO` or `ds_user_id=NO` → relogin required. `configure_text_only_post` write will fail.
- `dashboard.connected=true` BUT `sessionid=NO` → bug in the connected-status reconciler (we fixed this 2026-05-28 with `9184a69f`; if it returns: investigate).
- `last auth_health` older than 26h → drift cron broken or persona-cookies-health.timer not running.
- Browser daemon socket absent + last successful scan recent → normal (idle timeout). Absent + scans failing → start the daemon.

## NOT for triggering anything
This skill is **read-only**. Relogin is an explicit user action — never auto-triggered from a snapshot result. The result informs the lead, who reports to the founder.
