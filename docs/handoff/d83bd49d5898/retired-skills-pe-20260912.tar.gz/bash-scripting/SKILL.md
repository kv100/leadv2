---
name: bash-scripting
user-invocable: false
description: Production-ready shell script patterns for persona-engine bash scripts, including set -e defensive patterns.
---

# Bash Scripting Patterns

## Mandatory Header
Every bash script MUST start with:
```bash
#!/usr/bin/env bash
set -euo pipefail
```

## Structure
1. Shebang + safety flags
2. Constants (readonly)
3. Logging function (timestamped)
4. Argument parsing (getopts or positional)
5. Validation (check deps, files, env vars)
6. Cleanup trap (`trap cleanup EXIT`)
7. Core logic
8. Exit with meaningful code

## Logging Pattern
```bash
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >&2; }
log_error() { log "ERROR: $*"; }
log_info() { log "INFO: $*"; }
```

## Error Handling
- `trap cleanup EXIT` for temp files, locks
- Retry pattern for network ops: max 3 retries, exponential backoff
- Validate ALL external input (JSON values from config, env vars)
- Quote ALL variables: `"$var"` not `$var`
- Use `${var:-default}` for optional vars

## Security
- Never inject unvalidated config values into awk/sed/SSH (known pattern from codex-learnings)
- Use `mktemp` for temp files, never hardcoded paths
- Lock files for shared config: `flock` or mkdir-based
- No `eval` with user-supplied data

## Testing
- ShellCheck: `shellcheck -x script.sh`
- Dry-run mode: `DRY_RUN=true` skips side effects
- Verify dry_run doesn't leak side effects (cost logging, DB writes)

## Quality Gates
- [ ] set -euo pipefail
- [ ] All variables quoted
- [ ] Cleanup trap exists
- [ ] ShellCheck passes
- [ ] Dry-run tested

## Common Pitfalls (set -e)

### Arithmetic — `(( ))` exits non-zero on zero result
```bash
# BAD: kills script when i==0
(( i++ ))

# GOOD
i=$(( i + 1 ))
(( i++ )) || true   # acceptable if value doesn't matter
```

### Pipefail — `cmd | jq` kills script if cmd fails
```bash
# BAD: pipefail kills on non-zero exit from first segment
result=$(cmd | jq -r '.key')

# GOOD — best-effort; fail loudly instead
result=$(cmd || true | jq -r '.key')
# OR — capture cmd separately, check exit, then pipe
raw=$(cmd) && result=$(echo "$raw" | jq -r '.key')
```

### Printf over echo
```bash
# BAD: echo -n, echo -e behave differently across systems
echo "$var"

# GOOD: portable, handles leading dashes
printf -- '%s\n' "$var"
```

### Heredoc + pipe stdin conflict
```bash
# BAD: python3 reads heredoc on stdin, echo data is lost
echo "$data" | python3 - <<'HEREDOC'
  import sys; print(sys.stdin.read())
HEREDOC

# GOOD: pass data via argv or temp file
python3 - "$data" <<'HEREDOC'
  import sys; print(sys.argv[1])
HEREDOC
```

### jq safety
```bash
# Boolean check: jq -e exits 1 if value is false/null
if jq -e '.enabled' config.json >/dev/null 2>&1; then ...

# Merge files: use --slurpfile, not process substitution
jq --slurpfile overlay overlay.json '. * $overlay[0]' base.json

# Null key: guard with // to avoid null propagation
jq -r '.key // empty'   # emits nothing on null (better than "null" string)
jq -r '.key // "default"'
```

### Math — use awk, not bc
```bash
# BAD: bc not always installed; no float support in bash arithmetic
result=$(echo "scale=2; $a / $b" | bc)

# GOOD: awk is POSIX, handles floats
result=$(awk "BEGIN{printf \"%.2f\", $a/$b}")
```

### Path comparison — normalize first
```bash
# BAD: symlinks and trailing slashes cause false mismatches
if [[ "$path1" == "$path2" ]]; then

# GOOD
if [[ "$(realpath "$path1")" == "$(realpath "$path2")" ]]; then
```
