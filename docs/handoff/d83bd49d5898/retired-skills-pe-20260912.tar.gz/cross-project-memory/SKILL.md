---
name: cross-project-memory
description: Search MemPalace for decisions and work in OTHER repos (respiro-ios, m3, threads-agent). Triggers only on an explicit cross-project ask — "в respiro-ios", "почему мы выбрали X?", "мы уже делали X?". Never for current-project code or state.
---

# MemPalace — cross-project memory

MCP server: `~/.claude/.mcp.json`. Palace: `~/.mempalace/`.

## When to use

**ONLY on explicit user request:**
- "в respiro-ios", "в threads-agent" — cross-project search
- "почему мы выбрали X?" — historical decision lookup
- "мы уже делали X?" — dedup check

Discard results with similarity < 0.75.

**Never use for:** current project code, current state, any Trivial/Light task.

Moved out of `.claude/ref/03-mempalace.md` (was `@import`ed into every session) on 2026-07-26 by
CTXENG-REVISION-01 — the palace is queried on a handful of sessions, so it belongs behind a trigger
rather than in every request's prefix.
