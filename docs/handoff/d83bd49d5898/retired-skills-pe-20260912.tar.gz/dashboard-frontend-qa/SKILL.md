---
name: dashboard-frontend-qa
description: |
  Project-local workflow + skill-router for ANY persona-engine dashboard work that touches
  visual quality, UX, modern web APIs, browser-based QA, or accessibility. Triggers on web/
  edits, dashboard audits, page rebuilds, "посмотри дашборд", "screenshot", "headless",
  /modern-web-guidance, /browser-check, /dashboard-audit. Stitches together leadv2: plugin
  skills, project scripts, and Timbre design tokens so the lead doesn't re-discover the
  toolset on every task.
when_to_invoke: |
  - Any edit under web/app/, web/components/, web/lib/, web/app/globals.css
  - Founder asks: "посмотри что на дашборде", "проверь UI", "сделай скриншот", "QA дашборда",
    "headless audit", "/modern-web-guidance", "is this accessible", "broken in dark mode"
  - Dashboard audit task spawning multiple analysis agents
  - Reviewing a frontend PR — orchestrator picks the right sub-skill from the router below
  - DO NOT trigger for: pure backend (agent/, scripts/, platform/), Supabase migrations,
    devops/VPS, llm orchestration — those have their own skills
---

# dashboard-frontend-qa

**One-stop reference for frontend QA + visual + UX work in persona-engine.** Composes
existing skills rather than duplicating them.

## Step 1 — Pick the right tool (router)

| You need to… | Use this skill / tool | Cost / speed |
|---|---|---|
| Look up a modern Web API (Popover, View Transitions, anchor positioning, scroll-driven anim, `field-sizing`, fetch priority, autosize) | **`leadv2:modern-web-guidance`** — `npx -y modern-web-guidance@latest search "<query>"` | offline, instant |
| Programmatic network/console/DOM check on a deployed URL | **`leadv2:leadv2-browser-check`** (Playwright headless) | ~1-3K tokens/call |
| Holistic UX read (layout, copy, hierarchy, a11y feel) of a deployed URL | **`leadv2:leadv2-gemini-ui-check`** (Antigravity `agy` CLI) | ~1K tokens, needs `agy` installed |
| Take + diff screenshots across all dashboard routes | **`scripts/audit/dashboard-screenshot.py`** (see §3) | local, 1–2 min |
| Enforce Timbre design tokens / 10 hard rules | **`timbre-ui`** (project, mandatory for web/) + read `docs/design-system.md` | free |
| WCAG 2.2 patterns (skip links, ARIA, focus, contrast) | `~/MythicalGames/m3-market/.claude/skills/accessibility/QUICKREF.md` (project-portable cheatsheet) | free |
| Distinctive aesthetic critique | **`frontend-design`** plugin skill (Microsoft) | free |
| Build/extend an E2E Playwright suite | `~/MythicalGames/m3-market/.claude/skills/browser-automation/QUICKREF.md` patterns | scaffold time |

**Default pairing for a dashboard audit:** `timbre-ui` + `leadv2:modern-web-guidance` + `dashboard-screenshot.py` for evidence. Add `leadv2:leadv2-browser-check` only when you need network/console proof.

## Step 2 — Project-specific facts (avoid re-discovery)

- **Prod URL:** `https://timbre.fyi`
- **Layout groups:** `web/app/(marketing|auth|onboarding|dashboard|admin)/`
- **Route count:** ~40 (live as of 2026-05-24 — `find web/app -name page.tsx | wc -l`)
- **Auth model:** Supabase session cookie. Most dashboard routes rely on implicit RLS rather than explicit `getUser` checks.
- **Multi-persona switch:** `?persona=<slug>` URL param read by `PersonaContextProvider`.
- **Forbidden in `web/` (from timbre-ui hard rules):**
  hardcoded colors / hex / `bg-white` (use `var(--surface-raised)` etc.) · Lucide icons (use `@phosphor-icons/react`) · emoji in UI · UUIDs or raw JSON shown to customers · re-inventing primitives in `web/components/primitives/` · amber accent for anything other than AI-active or primary CTA.
- **Customer copy rules:** pillars→themes, T1→Key, session→activity cycle, confirmed→published. See CLAUDE.md "customer language" + `docs/redesign/07-multi-persona-ux.md`.

## Step 3 — Headless screenshot + auth (project-built infra)

Two scripts live in `scripts/audit/` (committed by DASHBOARD-AUDIT-PO-01):

```bash
# 1) ONE-TIME interactive auth save (headed browser, founder logs in once):
python3 scripts/audit/dashboard-auth.py
# → writes .secrets/dashboard-auth-state.json (gitignored)

# 2) Headless screenshot of every route, full-page + viewport-fold:
python3 scripts/audit/dashboard-screenshot.py \
  [--auth .secrets/dashboard-auth-state.json] \
  [--out docs/handoff/<task>/screenshots] \
  [--base https://timbre.fyi]
# → PNGs + INDEX.md table per run
```

If auth state expires: script writes `<slug>.ERROR.txt` with `AUTH_LOST` and exits non-zero — re-run step 1.

## Step 4 — Audit pattern (multi-agent, parallel)

For a full dashboard audit, fan out three discovery agents in one message:

1. **A1 page-inventory** (general-purpose+sonnet) — write routes × layout × auth × data sources table
2. **A2 persona-features** (Explore+haiku) — enumerate every persona capability from agent/, supabase
3. **A3 api-wiring** (Explore+haiku) — map all `web/app/api/**/route.ts` to UI callers, find orphans

Then capture screenshots (Step 3), then fan out three analysis agents:

4. **A4 visual-ux** (frontend-developer+sonnet, must load `timbre-ui` + `frontend-design` + `leadv2:modern-web-guidance` for each top-finding)
5. **A5 feature-gaps** (product-owner+sonnet, applies must-have / should-have / nice-to-have / operator-only triage)
6. **A6 functional-qa** (critic+sonnet, state-coverage matrix: loading / empty / error / auth-expired / multi-persona / mobile / a11y)

Lead synthesizes into one `FIXES.md`. Reference template: `docs/handoff/DASHBOARD-AUDIT-PO-01/`.

## Step 5 — Required reads when entering web/ work

```
docs/design-system.md            # canonical tokens, primitives, archetypes
docs/redesign/10-design-v3.md    # full direction + execution plan
docs/redesign/07-multi-persona-ux.md   # multi-persona flows
docs/redesign/08-functionality-audit.md  # E2E control wiring
```

Read these once per task entry. Do NOT make agents re-discover them — inject paths in mission file.

## Step 6 — Verify before commit

```bash
cd web && npx tsc --noEmit
```

Plus the timbre-ui checklist: zero hardcoded colors · primitives composed not invented · Phosphor only · no emoji/UUIDs · `tabular-nums` on digits · focus-visible rings · both dark + light themes verified · TypeScript clean · fits an archetype.

## Hard bans

- Do NOT bypass `timbre-ui` rules even when prototyping
- Do NOT add Tailwind named colors (`bg-blue-500`) in new code — use design tokens
- Do NOT install another headless browser stack — Playwright via `scripts/pw/` is the project standard
- Do NOT skip `leadv2:modern-web-guidance` lookup when proposing a UI fix that touches dialogs, popovers, scroll animations, form autofill, image LCP, or anchor positioning — the API surface evolves faster than training weights
- Do NOT take screenshots through computer-use of the founder's machine for routine audit work — use Step 3 instead (faster, scriptable, reproducible)

## See also

- `.claude/skills/timbre-ui/SKILL.md` — mandatory design system enforcer
- `.claude/skills/audit-personas/SKILL.md` — sibling pattern for backend audits
- `~/Projects/leadv2/plugins/leadv2/skills/{modern-web-guidance,leadv2-browser-check,leadv2-gemini-ui-check}/SKILL.md` — upstream plugin skills
