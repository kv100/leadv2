---
name: dashboard-po-walkthrough
description: |
  Project-local skill for running a Product-Owner customer-narrative walkthrough of the
  persona-engine dashboard. Produces a per-page WORKS/PARTIAL/BROKEN verdict + "what works /
  what's broken / what's missing / what's confusing / recommended" narrative — as if a real
  respiro-brand operator opened each page for the first time. Distinct from bug-list audits.
  Triggers on: "PO прогон", "посмотри глазами клиента", "customer walkthrough", "PO review of
  dashboard", "what works what doesn't from PO POV", "/dashboard-po-walkthrough".
when_to_invoke: |
  - Founder asks for a customer-narrative read (NOT a bug list)
  - Quarterly product review or pre-release demo prep
  - Onboarding a new PO/designer who needs the lay of the product
  - Decision: which feature gap to close NEXT (the walkthrough surfaces customer pain)
  - DO NOT use when: pure functional QA needed (use `dashboard-frontend-qa`); pure backend
    persona audit needed (use `audit-personas`); shipping a single fix (use direct PO subagent)
---

# dashboard-po-walkthrough

**A narrative product walkthrough is not a bug list.** Use this skill when the founder wants
to UNDERSTAND the product the way a customer experiences it, then decide priorities.

## Step 1 — Choose the right tool for the depth needed

| Depth | Tool | Output |
|---|---|---|
| One-off "what's on this page?" read | **`leadv2:leadv2-gemini-ui-check`** (Gemini Antigravity) | textual UX report, ~1K tokens |
| Code-only PO judgment (no live browser) | **`product-owner`** subagent + read screenshots via Read tool | feature-gap matrix |
| Full per-cluster narrative walkthrough (this skill's pattern) | **`product-owner`** + screenshots + 6 discovery/analysis docs | `po-walkthrough.md` (cluster verdicts + 5 moments + ladder) |
| Live click-and-verify | spawn alongside `dashboard-frontend-qa` for A8 QA pair | `qa-walkthrough.md` |

## Step 2 — Inputs the PO walkthrough needs (mandatory pre-reads)

1. **Visual evidence:** screenshots of every covered route via `scripts/audit/dashboard-screenshot.py` — opened by the subagent as PNG via Read tool (Claude reads images directly). Without screenshots the walkthrough is speculation.
2. **Capability ground truth:** `discovery/persona-features.md` (54 persona capabilities across 11 categories — what the persona actually CAN do under the hood).
3. **Surface inventory:** `discovery/pages-inventory.md` (every route, layout, auth, data sources).
4. **API wiring:** `discovery/api-wiring.md` (which surfaces really call which routes; identifies phantom controls).
5. **Functional baseline:** `analysis/functional-qa.full.md` (so PO doesn't re-discover bugs already documented; only references them).
6. **Product framing:** `docs/specs/PRODUCT_SPEC.md` (job-to-be-done + customer mental model).

If any of these don't exist for the current scope → run discovery agents first (see `dashboard-frontend-qa` §4).

## Step 3 — Cluster the 40 routes, don't list 40 sections

Suggested clusters (use as starting template; merge if natural):

1. Marketing + auth + onboarding — first-visit narrative
2. Health / Fleet / PriorityRail — landing experience
3. Focus — weekly steering
4. Queue / Queue-health / Stories — action lifecycle
5. Voice / Safety — quality + compliance
6. Growth / Efficiency / Funnel / Analytics — outcome views
7. Experiments + Adaptations — learning surface
8. Notifications — async signal
9. Settings root + 6 subpages — configuration
10. Admin — operator surface

## Step 4 — The narrative template per cluster

Each cluster section must include (and ONLY these — keep it tight):

```
## Cluster N — <name>
Pages covered: /a, /b, /c

**As a respiro-brand operator opening this cluster for the first time…**
(1 paragraph: emotional first impression)

**What works (✓):** (2-5 bullets, concrete, from screenshots)
**What's broken or unusable today (✗):** (reference PO-DASH-* ids where applicable)
**What's missing that I expected (→):** (anchored to A2 capability)
**What's confusing (?):** (copy gotchas, wrong page placement, ambiguous icons)
**Recommended next move (one line, customer-verb):**

**Cluster verdict:** WORKS / PARTIAL / BROKEN
**Customer-impact severity if not fixed:** Critical / High / Medium / Low
```

Then close with three project-wide sections:
- §N+1 — The 5 moments that will define customer experience (signup, account-paused, vacation pause, first AI proposal, persona switch — for each: what should / what does / what to fix)
- §N+2 — PO priority ladder (re-ranked top 10 after walkthrough)
- §N+3 — What the dashboard does brilliantly today (don't only critique)

## Step 5 — Customer-language enforcement

The walkthrough text itself must use customer language. Hard bans for ANY string the founder will read:

- pillars → themes
- action_log / actions → activity
- session → activity cycle (or hide entirely)
- confirmed → published
- T1 / T2 — replace with Key/Outcome
- voice DNA → brand voice
- RAG / Qdrant — never appears
- raw enum values (planned/attempted/scored/learned…) → human labels
- raw slugs (respiro-brand, cascina-tiglio) → display names
- UUIDs / raw JSON — never

## Step 6 — Pair with QA walkthrough (recommended)

The PO walkthrough answers "WHY a page is broken/missing for the customer" but cannot prove
"does the click actually fire the API." For a complete read, spawn alongside a QA agent that
runs live headless probes — see `dashboard-frontend-qa` §4 cluster A8 pattern. Then the lead
synthesizes both into one `REPORT-QA-PO.md` for the founder.

## Step 7 — Output format

The deliverable file lives at `docs/handoff/<task-id>/analysis/po-walkthrough.md`. Must:
- start with `summary_for_lead: <one-line>`
- end with literal `DELIVERABLE_COMPLETE`
- ≤7K words
- second-person English ("you see…")
- no internal terms (Step 5 enforcement)

## Hard bans

- Do NOT produce a bug list — the bug list lives in `analysis/functional-qa.full.md`; this skill produces NARRATIVE
- Do NOT propose features the persona doesn't actually support (must be in `persona-features.md`)
- Do NOT critique aesthetics — that's the frontend-developer + timbre-ui review (different skill)
- Do NOT skip the screenshots — text-only walkthroughs are speculation
- Do NOT recommend changes that violate `docs/design-system.md` rules
- Do NOT bundle 40 routes into 40 sections — use ~10 customer-meaningful clusters

## See also

- `.claude/skills/dashboard-frontend-qa/SKILL.md` — sibling skill for visual + QA-flavored audits
- `.claude/skills/audit-personas/SKILL.md` — backend PO audit (live state of personas), different scope
- `~/Projects/leadv2/plugins/leadv2/skills/leadv2-gemini-ui-check/SKILL.md` — quick on-demand UX read
- Reference walkthrough: `docs/handoff/DASHBOARD-AUDIT-PO-01/analysis/po-walkthrough.md`
