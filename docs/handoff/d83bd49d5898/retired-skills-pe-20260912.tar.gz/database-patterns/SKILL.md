---
name: database-patterns
user-invocable: false
description: Supabase/PostgreSQL patterns for persona-engine migrations and queries.
---

# Database Patterns (Supabase/PostgreSQL)

## Migration Convention
File: `supabase/migrations/YYYYMMDDHHMMSS_description.sql`
- Sequential numbering, never reorder
- Each migration is idempotent where possible
- Always test on local Supabase first

## Schema Design
- Use `timestamptz` not `timestamp` (always timezone-aware)
- Add `created_at timestamptz DEFAULT now()` and `updated_at` to every table
- Foreign keys with `ON DELETE CASCADE` or `SET NULL` (explicit, never default)
- Indexes: create for any column used in WHERE, JOIN, or ORDER BY
- RLS policies: every table must have explicit policies

## Query Optimization
- Profile before optimizing: `EXPLAIN ANALYZE`
- Avoid N+1: use joins or batch queries
- Use `SELECT` only needed columns, never `SELECT *` in production
- Pagination: cursor-based (`WHERE id > $last_id LIMIT N`) over offset
- Connection pooling: use Supabase's built-in pooler

## Migration Safety
- Never DROP COLUMN in production without checking dependents
- Add columns as NULL first, backfill, then add NOT NULL constraint
- Test migrations against a copy of production data
- Check for lock contention on large tables

## Known Patterns (from codex-learnings)
- JSON race condition: read-modify-write on shared configs needs locking
- Validate column existence before INSERT (persona_timeline schema changes)
- Duplicate migration directories can drift — verify single source
