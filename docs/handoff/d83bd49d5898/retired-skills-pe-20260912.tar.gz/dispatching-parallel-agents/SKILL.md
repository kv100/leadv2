---
name: dispatching-parallel-agents
description: Use when deciding whether to fan out 2+ Agent spawns in one message instead of sequentially. Triggers on independent task domains or when wall-clock is the bottleneck. Not for dependent outputs or agents touching the same files.
---

# Dispatching Parallel Agents

## When: independent tasks, different expertise, time is bottleneck
## When NOT: dependent outputs, same files, budget-sensitive

## Pattern
1. Identify independent domains
2. Focused prompt per agent (include ALL context — agents can't see each other)
3. Dispatch in single message (multiple Agent calls)
4. Review, synthesize, resolve conflicts

## Team Matrix
| Task | Can Parallel? |
|------|--------------|
| Spec + Review (architect+critic) | No — critic needs spec |
| Code review + Security audit (critic+security-auditor) | Yes — independent passes |
| Frontend + Backend (frontend-developer+developer) | Yes — different files |
| Schema + Feature (postgres-pro+developer) | No — feature needs schema first |
| Multi-file edits (developer+developer) | Only if different files |

## Mistakes: vague prompts | assuming shared context | dispatching dependent tasks | not synthesizing
