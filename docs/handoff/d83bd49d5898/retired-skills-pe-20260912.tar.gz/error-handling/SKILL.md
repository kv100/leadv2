---
name: error-handling
user-invocable: false
description: Error handling and resilience patterns for bash scripts and platform code.
---

# Error Handling Patterns

## Bash Error Handling
```bash
# Retry with exponential backoff
retry() {
  local max_attempts=${1:-3} cmd="${@:2}"
  local attempt=1
  while [ $attempt -le $max_attempts ]; do
    if eval "$cmd"; then return 0; fi
    log_error "Attempt $attempt/$max_attempts failed"
    sleep $((2 ** attempt))
    ((attempt++))
  done
  return 1
}

# Cleanup on exit
cleanup() {
  rm -f "$LOCKFILE" "$TMPFILE"
  log_info "Cleanup complete"
}
trap cleanup EXIT
```

## Platform Error Categories
| Category | Strategy | Example |
|----------|----------|---------|
| Transient | Retry with backoff | Network timeout, API 429 |
| Permanent | Fail fast, log, alert | Invalid config, missing key |
| Degraded | Continue with fallback | LLM unavailable → skip agent |
| Critical | Stop, alert, require human | Safety gate violation |

## Graceful Degradation Rules
- LLM backend down → skip agent run, log, try next session
- Supabase unreachable → queue writes locally, sync on recovery
- Proxy down → skip engagement agent, content agent can still draft
- Codex unavailable → skip review, note in commit message
- Browser session expired → attempt re-login, fail to scheduler

## Never
- Swallow errors silently
- Retry indefinitely (max 3 attempts)
- Let dry_run mode execute side effects
- Continue after safety gate violation
