---
name: investigate
description: Use for production bugs with unclear root cause — "debug this", "why is this broken", 500 errors, multi-layer failures, "it was working yesterday". Runs the 4-phase Observe→Analyze→Hypothesize→Implement protocol; no fix without root cause. Not for an obvious typo or missing import already visible in the trace.
triggers:
  - debug this
  - fix this bug
  - why is this broken
  - root cause analysis
  - investigate this error
  - it was working yesterday
  - 500 error
  - unexpected behavior
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
  - Grep
  - Glob
  - WebSearch
---

# Investigate — Root Cause Debugging

## Iron Law: no fix without root cause. Symptoms are not causes.

## When: bug with unclear root cause, 500 errors, unexpected behavior, multi-layer failures
## When NOT: obvious typo/missing import visible in the trace

## 4-Phase Protocol

1. **Observe** — reproduce exactly. Document: error message verbatim, stack trace, request/response, env. No guessing yet.
2. **Analyze** — map the call path (scheduler → operator → micro-agent → safety → publish → learn). Where does it enter? Where does it exit wrong?
3. **Hypothesize** — list 3+ causes ranked by likelihood. For each: what evidence would confirm/deny? Pick most testable first.
4. **Implement** — fix root cause, not symptom. One change at a time. Verify fix doesn't break sibling hypotheses.

## Rules
- Never skip to Fix without completing Observe + Analyze + Hypothesize
- Each verify step changes exactly one variable
- Document failed hypotheses — they're evidence, not waste
- "It works now" is not done — know WHY it works
- If fix is non-obvious: add a comment explaining the root cause

## Pipeline-specific checklist
- Check Supabase logs for the action row (planned → approved → attempted → ?)
- Check safety gate logs — did it block?
- Check timing-config for rate limit hits
- Check if `.env` is PROD or local (local → PROD Supabase)

## Diagnostic tool audit (before Hypothesize)
Before writing any fix, verify the diagnostic tool itself:
- **Monitoring probe**: does it query the right source? (journalctl unit, log file, Supabase table, metric namespace)
- **Graveyard/dead-signal probe**: does it check ALL systemd units that could emit the signal? A signal emitted by `persona-scan-feed.service` is invisible to a probe scoped to `persona-engine.service`.
- **SQL query**: does it filter the right `persona_id`, `run_mode`, `error_code IS NULL`?
- **Time window**: is `--since` wide enough? Signal at 0-hits in 25min ≠ signal dead in 7d.

Rule: if the probe could be wrong, fix the probe before filing a bug. Spend 2 minutes here to avoid 2 hours on a false fix.

## Anti-patterns
- Changing multiple things simultaneously
- Fixing from memory without reproducing first
- Restarting the service and calling it fixed
- Blaming "flaky" without a hypothesis
- **Writing fixes before verifying the diagnostic tool** — caused 2 wrong commits + reverting on 2026-05-21
