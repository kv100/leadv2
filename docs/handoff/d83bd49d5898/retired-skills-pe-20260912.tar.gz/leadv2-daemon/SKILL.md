---
name: leadv2-daemon
description: "[internal] Headless daemon polling PO QUEUE and spawning /leadv2 autonomously; circuit-breaks after N consecutive failures, honors quiet hours, pauses on AskUserQuestion."
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
---

# Lead v2 Daemon Mode

## When: long-running 24/7 autonomous operation. When NOT: single-session interactive work (use /leadv2 normally).

## Architecture

Daemon = bash script polling loop:
- Every N seconds (default 1800 / 30 min)
- Call `leadv2-queue-sweep.sh` once per tick to reclaim dead-PID sidecars and expired leases
- Iterate lanes in order `recovery → action → intelligence` via `leadv2-queue-claim.sh --by <daemon-id>`
- Spawn `claude -p "/leadv2 next" --max-turns 50 --permission-mode acceptEdits`
- That claude session runs the full /leadv2 flow headless
- Log outcome to `/tmp/leadv2-daemon.log`

`human-needed.yaml` is intentionally never claimed by the daemon — items there are blocked on founder input.

Daemon does NOT run the orchestrator itself — it's a scheduler/launcher that spawns fresh `/leadv2` invocations.

## Starting

```bash
cd /Users/kostiantyn.vlasenko/Projects/persona-engine
.claude/scripts/leadv2-daemon.sh --poll-seconds 1800 &
echo $! > /tmp/leadv2-daemon.pid.startup
```

For persistence across reboots (systemd unit template, launchd note for macOS), see
`~/.claude/leadv2-shared/handbooks/leadv2-daemon-runbook.md` — not needed for a one-off
foreground run.

## Stopping

```bash
kill $(cat /tmp/leadv2-daemon.pid)
# trap handler in daemon cleans up
```

## Configuration via env vars

| Env var | Default | Purpose |
|---|---|---|
| `LEADV2_POLL_SECONDS` | 1800 | poll interval |
| `LEADV2_QUIET_HOURS` | 23-06 | skip launches in these hours (Kyiv local) |
| `LEADV2_MAX_CONSECUTIVE_FAILURES` | 3 | circuit-break after this many /leadv2 exit-non-zero in a row |
| `LEADV2_COST_CEILING_USD` | 50 | soft budget per day (best-effort) |

## Queue format expectations

Canonical source: `docs/tasks.yaml` (managed by `leadv2-tasks-lib.sh`).
- Items with `status: pending` and `claim.by: null` are claimable (lane `human-needed` never claimed by daemon)
- Items sorted by lane rank `(recovery→action→intelligence)` then priority rank `(critical→high→medium→low)` then `created_at`
- `leadv2-queue-claim.sh --dry-run --top-n 3` shows what daemon would pick next (calls `leadv2_tasks_top_n 3` internally)
- To inspect directly: `source .claude/scripts/leadv2-tasks-lib.sh && leadv2_tasks_top_n 5`

Note: `docs/agents/product-owner/QUEUE.md` is frozen — do not read it as queue source.

## Circuit breaker

State stored in `/tmp/leadv2-daemon.state`:
```
consecutive_failures: 2
last_success: 2026-04-24T12:00Z
last_failure: 2026-04-24T13:30Z
```

- 3 failures in a row → daemon pauses, writes `paused: true` to state, sends `PushNotification` to founder via API if configured, and stops spawning until founder issues:
  ```bash
  .claude/scripts/leadv2-daemon.sh --resume
  ```

## Monitoring

```bash
tail -f /tmp/leadv2-daemon.log
cat /tmp/leadv2-daemon.state
ps -p $(cat /tmp/leadv2-daemon.pid)
```

## Safety rails

- **Never auto-deploy critical changes at night.** `LEADV2_QUIET_HOURS` honored.
- **Max 1 parallel /leadv2 invocation.** No concurrent runs.
- **PushNotification on every circuit-break.** Founder is informed.
- **Automatic pause on `AskUserQuestion` from /leadv2.** Since headless, no interactive answer possible — /leadv2 marks task paused, daemon moves on to next item (skipping the paused one on subsequent polls).

## When to run daemon vs manual

| Scenario | Mode |
|---|---|
| Tight weekend, need many routine tasks done | daemon |
| Anything safety-critical shipping | manual /leadv2 |
| Testing /leadv2 itself | manual |
| Daily routine / housekeeping | daemon |
| Emergency bug fix | manual |

Rule: if you're not around to answer ask-lead within 10 minutes, switch to daemon — it'll skip human-blocked items and do what it can.

## Anti-patterns

- Running daemon with empty `docs/tasks.yaml` — just idles logging "queue empty" repeatedly. Add items via `leadv2_tasks_add` first.
- Running daemon alongside interactive /leadv2 — race on LEAD_V2_STATE.md. Stop daemon first.
- Setting `LEADV2_POLL_SECONDS < 300` — hammers Anthropic API too fast.
- Ignoring circuit-break notifications — defeats the safety net.
- Editing `docs/agents/product-owner/QUEUE.md` — it is frozen, edits have no effect on the queue.
