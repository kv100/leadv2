---
name: leadv2-deploy
description: "[SUPERSEDED — see plugin leadv2:leadv2-deploy] [internal] Phase 6 — commit, push, deploy to both VPS, verify systemd; circuit-breaks to founder on…"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Grep
  - Glob
---

# Lead v2 Deploy — Automated

## When: Phase 6, after Review clean. When NOT: Critical/High unresolved.

## Protocol

### 0.5. Pre-mortem check (deploy phase)

Run before the full precondition gate — cheap, no LLM cost:

```bash
bash .claude/scripts/leadv2-premortem.sh \
  --task-id <task-id> \
  --phase deploy
pm_rc=$?
```

| Exit | Verdict | Action |
|---|---|---|
| 0 | proceed | Continue |
| 1 | proceed_with_caution | Add premortem caution flag to LLM-judge packet; proceed |
| 2 | skip_recommended | Tier B pause — "Premortem says <pct>% success — redesign / continue?" (default: redesign via architect) |

Record verdict in `context.yaml.deploy_gate.premortem_verdict`.

### 0.7. LLM-judge gate (after premortem, before auto-Gate 2)

Skip condition (skip to save Opus tokens):
```
task.classification == Light
AND offlimits exit 0
AND premortem.verdict == proceed
AND hack_findings.block == 0
```

If not skipped — assemble packet and invoke judge:

```bash
# Step 1: assemble packet + check skip
judge_out=$(bash .claude/scripts/leadv2-llm-judge.sh \
  --task-id <task-id> --class <classification>)
judge_rc=$?

# judge_rc=2 means hard cost ceiling — treat as go-with-caveats, continue
# judge_rc=0 means packet ready or Light+clean skip

# Extract prompt file path for lead to spawn agent
prompt_file=$(printf '%s\n' "$judge_out" | grep '^judge_prompt_file=' | cut -d= -f2)
packet_file=$(printf '%s\n' "$judge_out" | grep '^packet_file=' | cut -d= -f2)
judge_model=$(printf '%s\n' "$judge_out" | grep '^model=' | cut -d= -f2)
```

If not skipped — lead spawns Opus/Sonnet judge agent:

```
Agent(
  subagent_type: architect,
  model: <judge_model>,  # from router — may be sonnet if ceiling warn
  effort: high,
  prompt: "<read $prompt_file>"
)
```

Parse agent response:
```bash
bash .claude/scripts/leadv2-llm-judge-parse.sh \
  --task-id <task-id> \
  --response-file <agent_response_file> \
  --model <judge_model>
judge_parse_rc=$?
# 0 = go or go-with-caveats
# 1 = no-go
# 3 = parse error (treated as go-with-caveats)
```

Route decision from `docs/handoff/<task-id>/llm-judge.yaml`:

| verdict | overall_risk | Action |
|---|---|---|
| `go` | < 5 | Proceed silently (Tier A eligible) |
| `go` | 5–7 | Promoted to `go-with-caveats` by parse script — Tier B |
| `go-with-caveats` | any | Tier B default-timeout (10 min, default=proceed, caveats noted) |
| `no-go` | any | Tier B (default=redesign via architect; founder can override) — block deploy, spawn architect, return to Plan |

Record `context.yaml.deploy_gate.llm_judge_verdict` and `llm_judge_overall_risk`.

### 0.9. VPS smoke (Heavy tasks only)

Skip entirely for Light and Standard tasks — too expensive. Skip condition:
```
task.classification in [Light, Standard]  →  skip (record smoke_gate: skipped)
```

For Heavy tasks — run smoke **after** llm-judge verdict is `go` or `go-with-caveats` (if `no-go`, deploy is already blocked; smoke is moot):

```bash
# Smoke Nik (always for Heavy)
bash .claude/scripts/leadv2-vps-smoke.sh \
  --task-id <task-id> \
  --target nik \
  --smoke-duration-min 5 \
  --commit-sha <pending-commit-sha>
smoke_nik_rc=$?

# Smoke Respiro in parallel — only if task touches Respiro-specific files
# (check git diff --name-only for personas/respiro/ or platform/ changes)
if <task_touches_respiro>; then
  bash .claude/scripts/leadv2-vps-smoke.sh \
    --task-id <task-id> \
    --target respiro \
    --smoke-duration-min 5 \
    --commit-sha <pending-commit-sha> &
  smoke_respiro_pid=$!
  wait "$smoke_respiro_pid"
  smoke_respiro_rc=$?
fi
```

Smoke script writes result to `docs/handoff/<task-id>/vps-smoke-<target>.yaml`.
Record `context.yaml.deploy_gate.smoke_results`:
```yaml
smoke_results:
  nik: pass | fail | skipped
  respiro: pass | fail | skipped
  smoke_gate: pass | fail | skipped
```

**Routing:**

| smoke_nik_rc | smoke_respiro_rc | Action |
|---|---|---|
| 0 (pass) | 0 or skipped | Proceed to auto-Gate 2 |
| 1 (fail) | any | **BLOCK deploy** — open `RECOVERY-<task-id>-smoke` with `failure_detail` from report; route to architect for root-cause redesign (Tier B, default=redesign) |
| 2 (infra error) | any | AskUserQuestion: "SSH/git infra error during smoke — retry or proceed without smoke?" |

On smoke-fail:
1. Script auto-rolls back VPS (NEVER left in snapshot state — enforced by trap)
2. PushNotification: "Smoke fail on <target> for <task-id>: <failure_detail>"
3. Set `LEAD_V2_STATE.status: paused`
4. Open RECOVERY task — always architect-first for durable fix (not a patch)

### 0. Auto-Gate 2 check (Tier A — silent deploy for low-risk tasks)

Before running precondition checks, evaluate auto-Gate 2 eligibility. Requirements — **ALL** must be true:

```
[ ] task.classification == Light
[ ] graph_footprint.risk_score == low
[ ] off_limits check clean (exit 0)
[ ] coverage.yaml.passed == true  OR  coverage_gate == skipped (non-Python / Light task)
[ ] no matches in .claude/ref/lead-patterns.md#immune for this task's fingerprint
[ ] llm_judge.verdict in [go, go-with-caveats]  OR  llm_judge.skipped == true
```

If ALL true:
- Proceed to deploy steps below without Gate 2 notification.
- After deploy completes, append to `docs/LEAD_V2_STATUS.md` autonomous-decisions table:
  `| <time> | <task-id> | A | "auto-Gate-2: deploy (durable)" | "all Light+low-risk criteria met" |`
- Log `"auto-Gate-2 passed (Tier A)"` to `LEAD_V2_STATE.md` step note.

If `llm_judge.verdict == no-go`:
- **Block deploy regardless of other conditions.**
- Tier B decision: "LLM-judge blocked deploy (risk=<score>). Redesign via architect or founder override?"
- Default: redesign via architect.

If any other requirement fails:
- Compose Tier B decision via `leadv2-founder-input` skill with pre-selected recommended option = "Deploy (durable)".
- Founder can run `leadv2-decide.sh <id> <abort-option>` to cancel; otherwise auto-applies in 10 min.

### 0.8. Compress Review outputs before reading

Before reading Review-phase handoff files (critic.md, developer.md, hack-detection.summary.md), compress them if large:

```bash
source .claude/scripts/leadv2-helpers.sh
for f in \
  "docs/handoff/${TASK_ID}/critic.md" \
  "docs/handoff/${TASK_ID}/developer.md" \
  "docs/handoff/${TASK_ID}/hack-detection.summary.md"; do
  [[ -f "$f" ]] && leadv2_compress_handoff "$f"
done
# Read disposition summary via helper
review_summary=$(leadv2_read_handoff "docs/handoff/${TASK_ID}/critic.md")
```

YAML files (disposition.yaml) are never compressed — downstream schema parsing is strict.

### 1. Precondition gate — ALL must pass

Check each, write results to `context.yaml.deploy_gate:`. If any fails → circuit break.

Before checking individual fields, validate the disposition file schema:

```bash
source .claude/scripts/leadv2-helpers.sh
if ! leadv2_validate_handoff "docs/handoff/<task-id>/reviews/disposition.yaml" review_disposition 2>/tmp/hv-err.txt; then
  err=$(</tmp/hv-err.txt)
  # Ask the Review phase to fix it ONCE, then re-validate
  .claude/scripts/ask-lead.sh "<task-id>" "disposition.yaml invalid at deploy gate: $err — fix before deploy"
  leadv2_validate_handoff "docs/handoff/<task-id>/reviews/disposition.yaml" review_disposition \
    || { .claude/scripts/ask-lead.sh "<task-id>" "disposition.yaml still invalid: $err"; exit 1; }
fi
```

```
[ ] reviews.codex_round_1.critical == 0 AND high == 0 (or rev2/rev3 cleared)
[ ] reviews.disposition == "resolved" OR "TODO-filed-with-ticket"
[ ] Tests pass: run via Agent(developer, sonnet, "run relevant test suite, quote output")
[ ] `git status -sb` non-empty; `git diff --stat` touches expected files (from plan.steps.writes)
[ ] off_limits check passes (see step 1.5 below)
[ ] decisions: all honored — spot-check via grep of diff against locked choices
[ ] verification.live_signal defined in context.yaml
[ ] G-Eval gate passes (see step 1.6 below — Standard+ only)
```

### 1.6. G-Eval quality + safety gate (Standard+ tasks only)

Skip condition (Light class):
```
task.classification == Light  →  skip this step entirely (record eval_gate: skipped)
```

For Standard and Heavy tasks — run when `ANTHROPIC_API_KEY` is present AND handoff data exists:

```bash
if [[ -n "${ANTHROPIC_API_KEY:-}" ]] && ls docs/handoff/*/context.yaml 2>/dev/null | head -1 >/dev/null; then
  pytest tests/leadv2/eval/ -q -x --tb=short
  eval_rc=$?
else
  eval_rc=0  # skip gracefully when key absent
fi
```

| eval_rc | Action |
|---|---|
| 0 | Proceed silently |
| non-zero | **Block deploy** — emit Tier B decision with the failed rubric name + score from pytest output. Default: fix rubric violation before retrying deploy. |

Record `context.yaml.deploy_gate.eval_gate: pass | fail | skipped`.

### 1.5. Off_limits structural check (replaces grep-of-diff)

Run the AST/import-graph enforcer — catches renames, directory moves, and import-path bypasses that simple grep misses:

```bash
source .claude/scripts/leadv2-helpers.sh
bash .claude/scripts/leadv2-offlimits-check.sh \
  --context docs/handoff/<task-id>/context.yaml \
  --start-sha <build_start_sha>
rc=$?
```

| Exit code | Meaning | Action |
|---|---|---|
| 0 | Clean pass | Proceed |
| 2 | Direct file or rename match | **BLOCK** — circuit break, AskUserQuestion |
| 3 | Import-graph match (changed file imports off_limits module) | **BLOCK** — circuit break, AskUserQuestion |
| 4 | Warning only (re-export or transitive import) | Log warning, do NOT block |

Structured YAML diagnostics are written to stderr by the script — capture and append to `context.yaml.deploy_gate.offlimits_result`.

### 1.6. Coverage gate (Standard+ tasks with Python changes)

If task class is Standard or above AND `git diff --name-only <start_sha>..HEAD` includes any `platform/**/*.py` or `agent/**/*.py` file — run the coverage gate before commit:

```bash
bash .claude/scripts/leadv2-coverage-gate.sh \
  --start-sha <build_start_sha> \
  --task-id <task-id> \
  --threshold 50
rc=$?
# rc=0: passed, rc=1: coverage below threshold
```

- `rc=0` → `docs/handoff/<task-id>/coverage.yaml` written with `passed: true`, proceed
- `rc=1` → the shown `leadv2-coverage-gate.sh` line-coverage gate failed; add coverage and re-run it.
- Separately, `scripts/mutation-kill-rate.sh` can return `rc=5` when its measured kill rate is below the configured threshold; add mutation-killing tests before deploy.
  - Spawn developer to write missing tests, re-run gate
  - If still failing: `AskUserQuestion` with block/continue/adjust options
  - Record decision in `context.yaml.deploy_gate.coverage_decision`
- Light tasks and non-Python diffs: skip gate, record `coverage_gate: skipped`

Failure at any step:
```
PushNotification: "leadv2 deploy blocked: <which check> failed"
AskUserQuestion with 2 options (abort / fix-then-retry)
Set LEAD_V2_STATE.status: paused
```

### 2. Commit

```
Agent(developer, sonnet, prompt="
Task-id: <id>
Write conventional commit for the current staged + unstaged changes.
Message format: <type>: <subject> (≤72 chars)
Types: feat | fix | chore | docs | platform | agent
Body: 2-3 lines max, reference task-id.
Do NOT include 'Generated with Claude' or similar attribution.
Stage all expected files, commit, output commit hash.
")
```

Record commit hash in `context.yaml.deploy_gate.commit_hash`.

### 3. Push to main

```
Agent(devops-engineer, sonnet, prompt="
git push origin main
Confirm push succeeded (origin/main == local main).
Output last commit on origin/main.
")
```

### 4. Deploy to both VPS — via helpers

Use the shared helper — hardcoded VPS targets from project memory:

```bash
source .claude/scripts/leadv2-helpers.sh
leadv2_deploy_both_vps
rc=$?
```

Helper does:
- Nik: `ssh persona@87.99.142.240 "cd /home/persona/persona-engine && git fetch && git reset --hard origin/main"` then `ssh root@87.99.142.240 "systemctl restart persona-engine.service && systemctl is-active"`
- Respiro: same pattern with `claudebot@204.168.169.186` and `root@204.168.169.186`
- Returns: 0 both-ok, 1 partial, 2 both-failed

Alternative if lead wants more control / logging → spawn:
```
Agent(devops-engineer, sonnet, prompt="source .claude/scripts/leadv2-helpers.sh && leadv2_deploy_both_vps; echo exit=$?")
```

Update context.yaml based on rc:
```
context.yaml.deploy_gate.vps_status:
  nik: active|failed
  respiro: active|failed
  deploy_rc: 0|1|2
```

### 5. Failure handling

| Result | Action |
|---|---|
| Both VPS active, no errors | Proceed to Phase 7 Verify |
| One VPS failed, one succeeded | AskUserQuestion: "partial deploy. continue with one?" OR trigger `leadv2-rollback.sh` |
| Both VPS failed | Immediate `leadv2-rollback.sh` → PushNotification |
| systemd active but errors in log | Proceed to Phase 7 — verify will catch it, faster loop |

### 6. State update

```
LEAD_V2_STATE.md:
  phase: deploy
  step: shipped
  note: "commit <hash>, Nik/Respiro <status>, verify pending"
```

```bash
source .claude/scripts/leadv2-helpers.sh && leadv2_active_update_phase verify
```

Proceed to Phase 7 Verify.

## Rules

- **No human gate here.** Gate 1 was the only approval. Deploy is automated given preconditions.
- **Parallel VPS deploy.** Serial ssh = wasted wall time.
- **Conventional commit only.** No attribution lines.
- **Verify systemd after reload** — deploy success ≠ service running.
- **Rollback is cheap — use it.** Don't debate if in doubt.

## Anti-patterns

- Skipping off_limits structural check — grep-of-diff misses renames and import-path bypasses; always use `leadv2-offlimits-check.sh`.
- Deploying one VPS and "will do other later" — leaves fleet inconsistent. Both or rollback.
- Ignoring systemd errors because "tests pass" — tests are not live signal (MD from lead-patterns).
