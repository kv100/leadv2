---
name: leadv2-graph-reflect
description: "[internal] Close-phase step that captures the MCP codebase-memory diff footprint for the lead-reflect history entry; triggers after a successful commit, before lead-reflect writes its entry; skips mid-task, on failed/rolled-back tasks, or when no commit was made."
allowed-tools:
  - mcp__codebase-memory-mcp__detect_changes
  - mcp__codebase-memory-mcp__trace_path
  - mcp__codebase-memory-mcp__index_status
---

# Lead v2 Graph Reflect — Structural Diff Footprint

## When: Close phase, after commit success, before lead-reflect emits history entry
## When NOT: mid-task; on failed/rolled-back tasks; if no commit was made

---

## Inputs

| Input | Source |
|---|---|
| `start_sha` | task context.yaml `git.start_sha` |
| `head_sha` | `git rev-parse HEAD` after commit |
| `project_id` | `Users-kostiantyn.vlasenko-Projects-persona-engine` |

---

## Protocol

### Precondition: Index freshness check

Call `mcp__codebase-memory-mcp__index_status` with `project=<project_id>`.

If `last_indexed` timestamp < start_sha commit time:
- Set `graph_footprint.degraded: true`
- Skip all `trace_path` calls
- Proceed with detect_changes output only (basic counts still valid)
- For Heavy tasks: log `WARN: graph index stale — re-index before next task recommended`

If index is fresh: proceed normally (`degraded` field omitted or false).

### Step 1 — Detect changed symbols

Call `mcp__codebase-memory-mcp__detect_changes` with:
- `since=<start_sha>`
- `depth=2`
- `project=<project_id>`

Collect:
- `added_nodes`: list of `{qualified_name, label}` for newly added symbols
- `modified_nodes`: list of `{qualified_name, label}` for modified symbols

### Step 2 — Count inbound callers (skip if degraded)

For each node in `added_nodes + modified_nodes` where `label` in `[Function, Method, Route]`:

Call `mcp__codebase-memory-mcp__trace_path` with:
- `function_name=<qualified_name>`
- `direction=inbound`
- `depth=1`
- `project=<project_id>`

Count the returned caller nodes. Accumulate:
- `impacted_callers_count`: sum of all inbound caller counts
- `new_edges.CALLS`, `new_edges.HTTP_CALLS`, `new_edges.DATA_FLOWS`, `new_edges.ASYNC_CALLS`: count edge types from detect_changes output
- `orphans`: added symbols (label=Function|Method|Route) with 0 inbound callers

### Step 3 — Classify change_kind

Apply the first matching rule (checked in order):

| Condition | change_kind |
|---|---|
| Any added node has `label=Route` | `new-route` |
| Any added node path matches `supabase/migrations/` | `new-migration` |
| Any edge type `HTTP_CALLS` or `ASYNC_CALLS` in new_edges > 0 | `cross-service` |
| All changed symbols in `web/` or `*.tsx?` paths only | `ui-only` |
| All changed symbols in `*.md`, `docs/`, `.claude/` paths only | `docs-only` |
| All changed symbols in config files (`*.json`, `*.yaml`, `*.env`) | `config-only` |
| Any `failure_class` signal in task context (bug fixed, no new symbols) | `bugfix-pure` |
| Default (internal refactor, no external surface change) | `refactor-internal` |

### Step 4 — Derive risk_score

Start at 0 risk points. Apply:

| Condition | +points | Signal tag |
|---|---|---|
| `change_kind == new-route` AND no `critic` in `involved_agents` history | +1 | `new-route-no-critic` |
| `change_kind == cross-service` | +1 | `cross-service` |
| `impacted_callers_count > 20` | +1 | `high-fanout` |
| `len(orphans) > 0` | +1 | `orphans-present` |

Map total points → `risk_score`:
- 0 points → `low`
- 1–2 points → `medium`
- 3+ points → `high`

### Step 5 — Emit graph_footprint block

```yaml
graph_footprint:
  change_kind: <value>           # from closed vocab in leadv2-signatures
  added_symbols: []              # qualified_names of added nodes
  modified_symbols: []           # qualified_names of modified nodes
  impacted_callers_count: 0      # sum of inbound callers across all changed symbols
  new_edges:
    CALLS: 0
    HTTP_CALLS: 0
    DATA_FLOWS: 0
    ASYNC_CALLS: 0
  orphans: []                    # added symbols with 0 inbound callers
  risk_score: low                # low | medium | high
  risk_signals: []               # subset of: [cross-service, high-fanout, new-route-no-critic, orphans-present]
  degraded: false                # true if index was stale; omit if false
```

Pass this block to lead-reflect as context to merge into the history entry.

### Step 6 — Write graph_footprint to task-scoped file

Write the `graph_footprint:` block to a task-scoped intermediate file so that
`lead-reflect` can pick it up when it creates the history entry. This avoids
the race condition from whole-file LEAD_V2_STATE.md rewrites (H2) and the
ordering dependency where graph-reflect ran before the history entry existed (H1).

**Do NOT write directly to LEAD_V2_STATE.md.** lead-reflect owns that file.

Output path: `docs/leadv2/tasks/<task_id>/graph-footprint.yaml`

Uses `flock` on a stable lock inode `<task-dir>/.graph-footprint.lock` so
parallel sessions cannot corrupt the file.

```bash
python3 - "$TASK_ID" "docs/handoff/$TASK_ID/build-summary.yaml" <<'PY'
import sys, yaml, os, fcntl
from pathlib import Path
from datetime import datetime, timezone

task_id, build_summary_path = sys.argv[1], sys.argv[2]

# Read graph_footprint from build-summary.yaml
src = Path(build_summary_path)
if not src.is_file():
    print(f"[graph-reflect] WARN: {build_summary_path} not found, skipping", file=sys.stderr)
    sys.exit(0)

raw = yaml.safe_load(src.read_text()) or {}
footprint = raw.get("graph_footprint")
if footprint is None:
    print("[graph-reflect] WARN: no graph_footprint in build-summary.yaml, skipping", file=sys.stderr)
    sys.exit(0)

task_dir = Path(f"docs/leadv2/tasks/{task_id}")
task_dir.mkdir(parents=True, exist_ok=True)

lock_path = task_dir / ".graph-footprint.lock"
out_path  = task_dir / "graph-footprint.yaml"

with open(lock_path, "w") as lock_fh:
    fcntl.flock(lock_fh, fcntl.LOCK_EX)
    data = {
        "task_id": task_id,
        "written_at": datetime.now(timezone.utc).isoformat(),
        "graph_footprint": footprint,
    }
    tmp = out_path.with_suffix(".tmp")
    tmp.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=120))
    os.replace(tmp, out_path)
    # flock released on context exit

print(f"[graph-reflect] wrote graph_footprint to {out_path}", file=sys.stderr)
PY
```

**Safety rules for this step:**
- Only runs when `LEADV2_TASK_ID` env var is set (guard against accidental standalone runs).
- Does NOT touch `LEAD_V2_STATE.md` — only writes to the task-scoped dir.
- If `build-summary.yaml` not found or has no `graph_footprint` → skip with warning, do not crash.
- Task dir (`docs/leadv2/tasks/<id>/`) is created by M1; `mkdir -p` here is a safety net only.
- Uses `tempfile + os.replace` inside `flock` for atomic, race-free write.
- `lead-reflect` reads `graph-footprint.yaml` and merges into the history entry it creates.

---

## Rules

- `change_kind` values are authoritative in `leadv2-signatures` — never invent new values inline.
- If `detect_changes` returns empty (no symbols found): emit `graph_footprint` with all counts=0, `change_kind=docs-only` (conservative default), `risk_score=low`.
- `orphans` only flags newly ADDED symbols — modified symbols with 0 callers are not orphans (they may have had callers before).
- Do not block Close on MCP errors — catch failure, set `degraded: true`, emit best-effort block.
- `impacted_callers_count` counts unique callers (deduplicate across symbols that share a caller).

## Anti-patterns

- Treating `degraded: true` as a failure — it is a graceful fallback, Close continues normally.
- Running trace_path on non-function nodes (Class, Module, File) — skip those, they inflate counts.
- Using change_kind to override task_class retroactively — graph_footprint is signal, not authority.
