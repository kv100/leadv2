---
name: leadv2-graveyard-scan
description: Detect silently-broken features by checking pe_log signal emission rates. 0 hits in 7d = graveyard candidate. Triggers: /leadv2 graveyard; start of any session after >24h outage; weekly retro; "never triggered in prod" suspicion; cadence-floor / bypass_chosen suspected dead.
allowed-tools:
  - Bash
  - Read
  - Write
---

# leadv2-graveyard-scan — Silent Feature Detector

## Purpose
Features are deployed but never actually run due to:
- Wrong column name in SQL (V4 restore: cadence-floor used `id=eq.${persona_id}` where id=UUID but persona_id=handle → silent 0 rows → function never ran)
- `2>/dev/null` suppressing pe_log that would reveal errors
- Config flag never flipped on
- Auth error on first call → function permanently skipped

## Key signals to probe

```sql
-- Run via Supabase SQL editor or ssh + psql
SELECT signal, COUNT(*) as hits_7d, MAX(created_at) as last_seen
FROM pe_log
WHERE created_at > NOW() - INTERVAL '7 days'
  AND signal IN (
    'cadence_floor_check',
    'bypass_chosen',
    'feed_scan completed',
    'learning_loop step success',
    'scrape_insights success',
    'visual_post selected',
    'comment_execute',
    'organic_action_taken',
    'safety_gate pass',
    'safety_gate block'
  )
GROUP BY signal
ORDER BY hits_7d ASC;
-- Any signal with 0 hits = graveyard candidate → investigate
```

## Response protocol for 0-hit signal

**Step 0 — Verify the probe first (do this before any code investigation)**
Before assuming the feature is broken, confirm `graveyard-probe.sh` is querying the right log source:
- Check which `journalctl -u <unit>` the probe uses. The signal may fire from a *different* systemd unit (e.g. `persona-scan-feed.service` vs `persona-engine.service`).
- Run: `journalctl -u persona-engine -u persona-scan-feed --since "24h ago" --no-pager | grep "<signal_name>" | wc -l`
- If hits appear when querying additional units → update probe to include them; not a feature bug.
- Lesson: `feed_scan completed` hit 0 in graveyard-probe for 7 days — actual cause was wrong unit in probe, not broken code (2026-05-21).

1. Grep platform/ + agent/ for the signal name: `grep -r "signal_name" agent/ platform/ --include="*.sh" --include="*.py"`
2. Trace the call path: is it reachable from `run-cycle.sh`?
3. Check for SQL column mismatches: does the query use `id` when the column is `slug`/`handle`?
4. Check for `2>/dev/null` suppression on that code path
5. Check config flags — is this behind a feature flag that defaults off?
6. Check `is_active` state in Supabase for this persona
7. File a task in PO QUEUE if root cause found; tag `bug: graveyard signal <name>`

## Output
Write results to `docs/ops/graveyard-scan-<YYYY-MM-DD>.md`:
```markdown
# Graveyard scan — <date>
## GREEN (active signals)
- cadence_floor_check: 42 hits, last 2h ago
## RED (0 hits — investigate)
- bypass_chosen: 0 hits — UUID vs handle bug (PO-102 never ran)
## GREY (expected silence)
- scrape_insights success: 0 hits — Playwright session expired (known, T18 pending)
```

## Schedule
- After any outage > 24h: mandatory before declaring system healthy
- Weekly: pair with retro as health baseline
- Any time "this feature should be running but I don't see evidence" is voiced
