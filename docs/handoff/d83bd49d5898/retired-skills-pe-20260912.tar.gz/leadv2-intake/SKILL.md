---
name: leadv2-intake
description: "[internal] Phase 0 — reads BOARD/RECOVERY/patterns, picks task source (explicit/bug/QUEUE/meeting), triggers PO meeting if stale, composes Russian proposal, writes LEAD_V2_STATE.md."
allowed-tools:
  - Read
  - Write
  - Edit
  - Grep
  - Glob
---

# Lead v2 Intake

## When: Phase 0 of /leadv2 loop, after Close proposing next
## When NOT: mid-task, during active subsession

## Protocol

### 0. Establish LEADV2_TASK_ID

If `LEADV2_TASK_ID` is already set in env (e.g. `/leadv2` was invoked from an external script that pinned the id) — use it as-is.

Otherwise:
- If task source is PO QUEUE → use the QUEUE item's `id` field as `LEADV2_TASK_ID`.
- Else (user-given task or RECOVERY) → generate one:
  ```bash
  printf 'TASK-%s-%s' "$(date -u +%Y%m%dT%H%M%SZ)" "$(openssl rand -hex 3)"
  ```

Export `LEADV2_TASK_ID` so all subsequent skill bash blocks see it:
```bash
export LEADV2_TASK_ID="<id>"
```

Call `leadv2_active_register intake` to add this task to `docs/leadv2/active.md`:
```bash
source .claude/scripts/leadv2-helpers.sh
leadv2_active_register intake
```

Do NOT proceed to task source decision until `LEADV2_TASK_ID` is set and registered.

### 0.5. Claim PO QUEUE item (when source is PO QUEUE)

Skip this step for user-given tasks and RECOVERY tasks — claim only applies when the task source is PO QUEUE (i.e. `/leadv2 next` or `/leadv2` bare daemon mode).

```bash
source .claude/scripts/leadv2-helpers.sh

ITEM_ID=$(leadv2_po_claim) || {
    rc=$?
    if [[ $rc -eq 2 ]]; then
        # Exit 2 = nothing to claim — all lanes empty or all items owned by alive sessions
        echo "[intake] PO QUEUE empty or all claimed"
        exit 0
    fi
    # Other non-zero = unexpected error — escalate
    .claude/scripts/ask-lead.sh "$LEADV2_TASK_ID" "PO QUEUE claim failed unexpectedly (exit $rc)"
    exit 1
}
export LEADV2_PO_ITEM_ID="$ITEM_ID"
export LEADV2_PO_LANE="${LEADV2_PO_LANE}"   # set by leadv2_po_claim automatically
```

`LEADV2_PO_ITEM_ID` and `LEADV2_PO_LANE` must both be exported before any subagent spawns so that the Close phase can release the item to the correct lane.

Do NOT proceed to §1 until `LEADV2_PO_ITEM_ID` is set (or the task source is not PO QUEUE).

### 1-5. Read inputs → determine task source → staleness check → compose proposal → write LEAD_V2_STATE.md

Full protocol (queue reads, task-source table, staleness thresholds, Russian proposal format,
LEAD_V2_STATE.md schema, Rules, Anti-patterns) archived to shared handbook:
`~/.claude/leadv2-shared/handbooks/leadv2-intake-procedure.md` — read it before running Phase 0
for the first time in a session; it is not re-stated here to keep this file cheap to load.

Load-bearing rules worth keeping visible even without opening the handbook: never skip the
staleness check; proposal text is Russian only; RECOVERY items open 48h+ trump QUEUE; never
propose from the human-needed lane.
