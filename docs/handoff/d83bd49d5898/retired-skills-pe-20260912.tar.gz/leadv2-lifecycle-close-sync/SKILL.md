---
name: leadv2-lifecycle-close-sync
description: Use when a /leadv2 task closes and the diff touched pipeline-affecting or live-verified code. Auto-fires via the lifecycle-close-sync PostToolUse hook — do not invoke manually mid-task. Maps the close diff to lifecycle-visual node ids and marks them AMBER only (never VERIFIED; that requires /lifecycle-refresh). Not for docs-only changes.
---

# Skill: leadv2-lifecycle-close-sync

## Trigger
PostToolUse:TaskUpdate hook fires this skill on every `status=completed` TaskUpdate.
Hook file: `.claude/hooks/lifecycle-close-sync.sh`
Timeout: 60s (non-blocking — hook is PostToolUse, not PreToolUse).

## AMBER-only contract (D1 — LOCKED by founder)
Close-sync may ONLY set a node badge to `AMBER`. It NEVER writes `VERIFIED`.
Only `/lifecycle-refresh full` (evidence reprobe via lifecycle-refresh.js) may promote
a node to `VERIFIED`. Any close-sync that writes `VERIFIED` reintroduces lying-green = BANNED.

## Dual-mode guarantee (R12)
On EVERY invocation (even no-ops):
1. Emits the reminder text to stdout — human-visible in Claude session.
2. Writes `docs/handoff/.lifecycle-sync-last-run` (ISO timestamp) — freshness watchdog target.

These two actions happen BEFORE any gate check. Even if the skill exits early (wrong status,
no pipeline marker, no LLM match), the sentinel is always written.

## Pipeline-affecting gate (R03)
The yaml update path is gated. A close without any of these markers → reminder-only, no yaml touch:
- `changed_pipeline_behavior: true` (or `yes`/`1`)
- `live_verified: true` (or `yes`/`1`)
Marker is searched in: STATE.md, docs/leadv2/tasks/<task-id>/*, docs/handoff/<task-id>/*.

## Execution steps (when gate passes)
```
1. Extract node IDs
   python3 yaml.safe_load(lifecycle-data.yaml) → list of node['id']

2. Get changed files
   git diff --name-only HEAD~1

3. LLM mapping (claude -p, model=claude-haiku-4-5, max-turns=1)
   Input: diff filenames + task_id + node-id list
   Output: JSON [{node_id, reason}] max 3 nodes

4. Validate LLM output
   Drop any node_id not in extracted list. If empty → exit 0, no update.

5. Apply AMBER badge + evidence-pending note
   python3: load yaml, set badge='AMBER', append note to summary (<=240 chars enforced)
   Re-write lifecycle-data.yaml.

6. Regen HTML
   bash scripts/gen-lifecycle-html.sh

7. Stage + commit
   git add lifecycle-data.yaml lifecycle-visual.html (path-scoped, NEVER -A)
   If staged changes exist: git commit -m "docs: lifecycle close-sync <task> — AMBER badge..."
   (follow-up commit; never amend — R1 decision)

8. Write last-run.json
   .claude/skills/leadv2-lifecycle-close-sync/last-run.json
   {task_id, nodes_updated: [<ids>], timestamp}
```

## Badge enum (canonical — NEVER diverge from gen-lifecycle-html.sh BADGE_ORDER)
```
VERIFIED | LYING-GREEN | AMBER | UNPROBED | BROKEN | DEPLOYED-UNPROBED
```

## Data paths
- lifecycle-data.yaml: `docs/systems-map/lifecycle-data.yaml`
- generator:           `scripts/gen-lifecycle-html.sh`
- sentinel:            `docs/handoff/.lifecycle-sync-last-run`
- last-run:            `.claude/skills/leadv2-lifecycle-close-sync/last-run.json`

## Failure modes
- claude command not available → LLM step returns empty → exit 0, no yaml update
- lifecycle-data.yaml missing → log + exit 0
- gen script fails → log warning, continue (sentinel + last-run still written)
- Any unhandled error → hook exits non-zero (visible to lead), but close is NOT blocked

## When close-sync misses a node
Check `.claude/skills/leadv2-lifecycle-close-sync/last-run.json` → `nodes_updated: []`.
Manual fallback: update lifecycle-data.yaml directly and run `scripts/gen-lifecycle-html.sh`.
Or run `/lifecycle-refresh full` for a full evidence-backed reprobe.
