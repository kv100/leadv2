---
name: leadv2-llm-judge-haiku
description: [internal] Haiku-executable deploy gate.
---

# leadv2-llm-judge-haiku

Haiku-model deploy gate. Runs FIRST for Light/Standard tasks. Escalates to Opus judge only when ambiguous.

Distilled from `leadv2-llm-judge` (Opus version). Same input schema, tighter output.

## Input — compact deploy packet

```yaml
task_id: <id>
classification: Light | Standard | Heavy | Strategic
diff_stats:
  files_changed: N
  lines_added: N
  lines_removed: N
  files: [list]
coverage_pct: 0-100
offlimits_touched: []
premortem_verdict: proceed | proceed_with_caution | skip_recommended
hack_findings:
  info: N
  warn: N
  block: N
summary: <planner one-paragraph>
```

## Output — YAML strict

```yaml
verdict: go | no_go | escalate_to_opus
risk_score: 0..10
confidence: 0.0..1.0
reasons:
  - short-sentence
  - short-sentence
escalate_reason: null | confidence_low | risk_ambiguous | class_heavy
```

## Verdict normalization (MANDATORY before writing llm-judge.yaml)

Haiku emits internal vocabulary (`no_go`, `escalate_to_opus`) but the canonical
file schema uses hyphenated forms (`no-go`, `go-with-caveats`). Normalize BEFORE
writing to `llm-judge.yaml`:

| Haiku emits | Canonical verdict written | Extra field |
|---|---|---|
| `go` | `go` | — |
| `no_go` | `no-go` | — |
| `escalate_to_opus` | `no-go` | `escalation_pending: true` at top level |

Never write `no_go` or `escalate_to_opus` to `llm-judge.yaml` — only the normalized
canonical form.

## Model resolution for escalation (MANDATORY, PROVIDER-AGNOSTIC-LEAD-01 Phase 2)

"escalate_to_opus" names the escalation TARGET ROLE (judge), not a hardcoded
model string. Whichever model is driving the active `/leadv2` session (Opus,
Sonnet, Terra, Sol, Luna, or GLM), the escalation target MUST be resolved
via:

```bash
bash .claude/scripts/leadv2-judge-resolve.sh
```

This resolves `roles.judge` from `.claude/ref/leadv2-role-model-map.yaml`,
clamped UP to `safety_floor` (opus) -- it can never resolve weaker than opus
and never to a non-Claude provider. In the map shipped with this repo today
that always resolves to `opus`, so behaviour is byte-identical to before;
the resolver is the enforcement mechanism (config-level, not driver
discipline), not a behaviour change. With the map absent, the resolver also
returns `model=opus` -- so this is additive and back-compatible. Spawn the
escalated judge Agent with the resolved `model=` value, never with whichever
model happens to be driving the session.

## Escalation rules (self-applied)

Emit `verdict: escalate_to_opus` when ANY of:
- `confidence < 0.7`
- `risk_score` in [4, 5, 6, 7]
- `classification` in (Heavy, Strategic) — never decide these alone

For everything else: emit direct `go` or `no_go`.

## Mandatory YAML writer

Write `docs/handoff/<task-id>/llm-judge.yaml` immediately after Haiku emits its
verdict — even if verdict is `escalate_to_opus`. If Opus subsequently runs, it
overwrites the file with the final verdict.

```bash
python3 - "$TASK_ID" "$HAIKU_VERDICT" "$RISK_SCORE" "$CONFIDENCE" "$ESCALATE_REASON" <<'PY'
import sys, yaml, os
from pathlib import Path
from datetime import datetime, timezone

task_id, raw_verdict, risk_score, confidence, escalate_reason = sys.argv[1:6]

# Normalize Haiku internal vocab → canonical hyphenated form (H5 fix).
escalated = (raw_verdict == "escalate_to_opus")
_VERDICT_MAP = {"go": "go", "no_go": "no-go", "escalate_to_opus": "no-go"}
canonical_verdict = _VERDICT_MAP.get(raw_verdict, raw_verdict)

out = Path(f"docs/handoff/{task_id}/llm-judge.yaml")
out.parent.mkdir(parents=True, exist_ok=True)

now = datetime.now(timezone.utc).isoformat()
findings = (
    f"Haiku: {raw_verdict}. Escalate reason: {escalate_reason}" if escalated
    else f"Haiku: {raw_verdict}"
)

data = {
    # Nested llm_judge block — matches shape expected by existing readers (H4 fix).
    "llm_judge": {
        "task_id": task_id,
        "judged_at": now,
        "model_used": "haiku",
        "verdict": canonical_verdict,
        "overall_risk": float(risk_score),
        "confidence": float(confidence),
        "axes": {},
        "blockers": [],
        "caveats": [],
        "reasoning": findings,
        "skipped": False,
        "skip_reason": escalate_reason if escalated else "",
    },
    # Top-level convenience fields.
    "escalated_from_haiku": False,   # self: this IS Haiku's write
    "escalated_to_opus": escalated,
    "escalation_pending": escalated,  # true when Opus must verify before deploy
    "opus_used": False,
    "timestamp_utc": now,
}
import tempfile
tmp = out.with_suffix(".tmp")
tmp.write_text(yaml.safe_dump(data, sort_keys=False))
os.replace(tmp, out)
print(f"[llm-judge-haiku-writer] wrote {out} (canonical_verdict={canonical_verdict}, escalated={escalated})", file=sys.stderr)
PY
```

Note: when `escalated_to_opus: true`, the full Opus judge (leadv2-llm-judge)
runs next. Its writer sets `escalated_from_haiku: true` and overwrites this file.

## System-prompt budget

Target ≤800 input tokens system prompt (vs Opus ~2500). Be terse. Output YAML only — no narrative.

## Cost model

- Haiku: ~$0.001 per judgment (~200 tok output × $5/M output)
- Opus escalation: ~$0.08 per judgment

Expect ~70% Haiku-only resolution rate in Light/Standard → ~$0.015 average (vs $0.08 Opus-only).
