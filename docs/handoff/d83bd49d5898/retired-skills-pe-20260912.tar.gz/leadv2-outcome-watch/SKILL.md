---
name: leadv2-outcome-watch
description: "[internal] Close-phase step that schedules a 48h post-deploy regression monitor via outcome-watch.sh; triggers for Heavy tasks, or Standard tasks whose diff touches platform/agent/supabase surfaces; skips for Light/Trivial tasks or tasks with no Supabase-observable side effects."
allowed-tools:
  - Read
  - Write
  - Bash
---

# Lead v2 Outcome Watch — 48h Production Feedback

## When: Close phase, for Heavy or Standard tasks that touched runtime files.
## When NOT: Light / trivial tasks, or tasks with no Supabase-observable side effects.

## Protocol

### Step 1. Confirm outcome-watch is required

Check `docs/handoff/<task-id>/context.yaml`:
- `classification.class == "Heavy"` → required
- `classification.class == "Standard"` AND `classification.scope.surfaces` includes `platform`, `agent`, or `supabase` → required
- Otherwise → skip (no 48h watch needed)

### Step 2. Create outcome-watch-config.yaml

Write `docs/handoff/<task-id>/outcome-watch-config.yaml` with the metrics relevant to the task. Use the table/column/filter values that match what the task changed.

Minimum template (adapt filter.persona to actual persona id):
```yaml
metrics:
  - name: nik_engagement_rate
    source: supabase
    table: persona_metrics
    filter: persona=nik, window=deploy+48h
    column: engagement_rate
    baseline: deploy-7d..deploy
    regression_threshold: 0.8   # fail if current < 80% of baseline
  - name: safety_reject_rate
    source: supabase
    table: safety_gate_events
    filter: persona=nik, outcome=rejected, window=deploy+48h
    column: count
    baseline: deploy-7d..deploy
    regression_threshold: 1.5   # fail if current > 150% of baseline
```

Guidelines for threshold selection:
- Engagement metrics (rate, reach, impressions): threshold 0.8 (20% drop = regression)
- Safety / error counters: threshold 1.5 (50% rise = regression)
- Revenue / conversion: threshold 0.9 (10% drop = regression)

### Step 3. Compute cron schedule for deploy_ts + 48h

Given `deploy_ts` (ISO UTC), compute deploy_ts + 48h → cron fields:
```
deploy_ts = 2026-04-24T18:00:00Z
+48h      = 2026-04-26T18:00:00Z
cron      = 0 18 26 4 *
```

### Step 4. Schedule via CronCreate (session-level)

```
CronCreate(
  cron="0 18 26 4 *",
  prompt="/leadv2 outcome-check <task-id>",
  recurring=false
)
```

Note: CronCreate is session-scoped. If the orchestrator session ends before the cron fires, the durable fallback (Step 5) is the safety net.

### Step 5. Write durable fallback script

Create `docs/handoff/<task-id>/outcome-watch.sh`:

```bash
#!/usr/bin/env bash
# Durable fallback — register in crontab if CronCreate was session-scoped:
# 0 18 26 4 *  SHELL=/bin/bash /path/to/.claude/scripts/leadv2-outcome-watch.sh \
#   --task-id <task-id> \
#   --config /path/to/docs/handoff/<task-id>/outcome-watch-config.yaml \
#   --deploy-ts 2026-04-24T18:00:00Z
#
# To register: crontab -e  (then paste the line above, uncommented)
```

Make it executable (`chmod +x`).

### Step 6. Log to Close output

Report to Close phase summary:
```
outcome-watch scheduled: deploy+48h = <ISO>, cron=<cron_fields>
fallback: docs/handoff/<task-id>/outcome-watch.sh
```

## What the outcome-watch script does at T+48h

1. Reads `outcome-watch-config.yaml`
2. Queries Supabase PostgREST for each metric: post-deploy window vs 7-day baseline
3. If any metric regresses:
   - Writes `outcome_watch: regression` to `LEAD_V2_STATE.md` history entry
   - Opens a recovery task via lib (replaces former QUEUE.md append):
     ```bash
     source .claude/scripts/leadv2-tasks-lib.sh
     # --origin self-heal routes to recovery lane for 48h regression follow-up
     leadv2_tasks_add "REGRESSION-${TASK_ID}" recovery high \
       --title "investigate 48h regression: ${TASK_ID}" \
       --origin self-heal
     ```
4. If all stable:
   - Writes `outcome_watch: stable`
5. Sends push notification either way (requires `NTFY_TOPIC` env var)

## Manual trigger (if cron missed)

```bash
PROJECT_ROOT=/path/to/persona-engine \
  .claude/scripts/leadv2-outcome-watch.sh \
    --task-id <task-id> \
    --config docs/handoff/<task-id>/outcome-watch-config.yaml \
    --deploy-ts <deploy_ts_iso>
```

## Creds

Script reads `.env` for `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` (or `SUPABASE_SERVICE_ROLE_KEY`). If creds missing → outcome_watch set to `skipped`, not failure. Close is never blocked.

## Anti-patterns

- Scheduling outcome-watch for Light tasks — noise, no runtime effect.
- Setting regression_threshold too tight (e.g. 0.99) — flaps on normal variance.
- Not writing the durable fallback — CronCreate is session-scoped, if session ends the watch is lost.
- Blocking Close on outcome-watch result — outcome-watch is async; Close completes first.
