---
name: leadv2-preflight-business-signal
description: "[internal] Phase 3 Gate-1 hook (before leadv2-gate1-prompt.sh, class >= Standard): triggers when context.yaml.verification.business_signal is empty and the diff touches publish/GLM/voice/schema change-class files; skips for Trivial/Light or docs-only diffs."
allowed-tools:
  - Read
  - Bash
  - AskUserQuestion
---

# leadv2-preflight-business-signal — Gate-1 Business Signal Check

## When
Phase 3 Gate 1, BEFORE `leadv2-gate1-prompt.sh`. Required for class ≥ Standard.

## When NOT
- Class = Trivial or Light → skip entirely, return PASS
- `docs/handoff/<task_id>/context.yaml` absent → skip (no verification declared)
- `verification.business_signal.class = "none"` → PASS, log bypass

---

## Step 1 — Read business_signal from context.yaml

```bash
TASK_ID="${LEADV2_TASK_ID}"
CTX="docs/handoff/${TASK_ID}/context.yaml"

BSIG_CLASS=""
if [[ -f "$CTX" ]]; then
  BSIG_CLASS=$(python3 - "$CTX" <<'PY' 2>/dev/null || echo "")
import yaml, sys
c = yaml.safe_load(open(sys.argv[1]))
v = (c or {}).get('verification', {}) or {}
bs = v.get('business_signal', None)
if bs is None:
    print('')
elif isinstance(bs, dict):
    print(str(bs.get('class', '') or '').replace('-touched', '').strip())
else:
    print(str(bs).replace('-touched', '').strip())
PY
fi
```

## Step 2 — Short-circuit if signal already set

- `$BSIG_CLASS` non-empty and not `"none"` → **PASS** (stop here, proceed to gate prompt)
- `$BSIG_CLASS == "none"` → **PASS**, append `bsig_bypass: explicit_none` to STATE.md

## Step 3 — Detect risky change-class files in diff

```bash
BASE=$(git merge-base HEAD origin/main 2>/dev/null || echo "HEAD~1")
CHANGED=$(git diff --name-only "${BASE}..HEAD" 2>/dev/null \
  || git diff --name-only HEAD~1..HEAD 2>/dev/null || echo "")

# docs/config-only exception — all changed files are doc/config types → PASS
NON_DOCS=$(printf '%s\n' "$CHANGED" \
  | grep -vE '\.(md|yaml|yml|json|txt|toml)$' | grep -v '^$' || true)
[[ -z "$NON_DOCS" ]] && { echo "[preflight-bsig] PASS: docs-only diff"; exit 0; }

# Detect risky files by change class
RISKY=$(printf '%s\n' "$CHANGED" | grep -E \
  '(^platform/publish/|^agent/publish/|^platform/llm/|^platform/briefing/|\
^supabase/migrations/.*\.sql|^platform/voice/|voice-dna\.md|voice-card|\
safety-gate|run-cycle\.sh|agent-prompt\.md|agent-tool[^/]*\.sh)' \
  || true)
```

## Step 4 — Decision table

| `BSIG_CLASS` | `RISKY` non-empty | Action |
|---|---|---|
| non-empty (not `none`) | any | **PASS** (handled in Step 2) |
| empty | no | **PASS** |
| empty | yes | **BLOCK** → Step 5 |
| `none` | any | **PASS** + bypass log |

## Step 5 — BLOCK: surface to founder via AskUserQuestion

Do NOT call `leadv2-gate1-prompt.sh`. Call `AskUserQuestion` with:

```
question: |
  Gate-1 заблоковано: verification.business_signal не вказано.
  Diff містить файли ризикового класу змін:
    <$RISKY>

  Додай у docs/handoff/${TASK_ID}/context.yaml:
    verification:
      business_signal:
        class: <publish|glm|voice|schema|safety>
      soak_minutes: <120|60|30|1440>   # publish=120, glm=60, schema=30, safety=1440

  Після додавання — повідом і я продовжу Gate 1.

options:
  - "Додав business_signal — продовжити Gate 1"
  - "Пропустити (не publish/GLM/voice/schema — впевнений)"
```

If founder chooses **"Пропустити"**:
- Append `bsig_bypass: founder_skip | risky: <files>` to STATE.md
- PASS with warning in pulse log

If founder chooses **"Додав"**:
- Re-run Step 1 to read updated `context.yaml`
- If still empty → re-surface block (max 1 re-check, then escalate)
- If set → PASS, proceed to gate prompt

## Step 6 — PASS: log and continue

```bash
printf '[preflight-bsig] PASS: class=%s risky=%s task=%s\n' \
  "${BSIG_CLASS:-empty}" "${RISKY:+yes}" "$TASK_ID" \
  >> "docs/leadv2/tasks/${TASK_ID}/pulse.md"
```

Proceed to `bash .claude/scripts/leadv2-gate1-prompt.sh "$TASK_ID" "$CLASS" "$PLAN_SUMMARY"`.

---

## Change-class reference

| Class | Risky file patterns | Default soak |
|---|---|---|
| `publish` | `platform/publish/`, `agent/publish/`, `run-cycle.sh`, `post-*.sh` | 120 min |
| `glm` | `platform/llm/`, `platform/briefing/`, `agent-prompt.md`, `agent-tool*.sh` | 60 min |
| `voice` | `voice-dna.md`, `voice-card*`, `platform/voice/` | 120 min |
| `schema` | `supabase/migrations/*.sql` | 30 min |
| `safety` | `safety-gate*`, `platform/safety/` | 1440 min |
| `none` | docs-only, infra config, tooling scripts only | — |

---

## Integration note

This skill is invoked by the lead at Phase 3 (Gate 1) before `leadv2-gate1-prompt.sh`.
Per-repo machine-executable override: `.claude/leadv2-overrides/gate1.sh` (create if needed
for daemon mode where interactive AskUserQuestion is unavailable — wrap this protocol
in a bash script that exits 0=pass / 1=block with message on stdout).
