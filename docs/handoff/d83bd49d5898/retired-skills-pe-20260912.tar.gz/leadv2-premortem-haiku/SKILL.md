---
name: leadv2-premortem-haiku
description: [internal] Haiku-model premortem refinement.
---

# leadv2-premortem-haiku

Refinement step for `leadv2-premortem`. The probability table is free (bash+heuristic). This skill runs a fast Haiku pass to sanity-check it; escalates to Opus only when ambiguous.

## Input

```yaml
task_id: <id>
classification: Light | Standard | Heavy | Strategic
plan_summary: <one-paragraph from plan phase>
probability_table:
  build_success: 0.0..1.0
  deploy_clean: 0.0..1.0
  block_risk: 0.0..1.0
  rollback_probability: 0.0..1.0
risk_factors_detected:
  - short-string
```

## Output

```yaml
verdict: proceed | proceed_with_caution | skip_recommended | escalate_to_opus
confidence: 0.0..1.0
adjusted_probabilities:
  build_success: 0.0..1.0
  deploy_clean: 0.0..1.0
  block_risk: 0.0..1.0
  rollback_probability: 0.0..1.0
reasons:
  - short-sentence
escalate_reason: null | confidence_low | class_heavy
```

## Escalation rules

Emit `verdict: escalate_to_opus` when:
- `confidence < 0.7`
- `classification == Heavy`

## Mandatory YAML writer

After emitting output (whether Haiku verdict or escalate_to_opus), write
`docs/handoff/<task-id>/premortem.yaml` with Haiku's current values.
If Opus then runs and overwrites it, the final file reflects Opus values.

```bash
python3 - "$TASK_ID" "$HAIKU_VERDICT" "$HAIKU_CONFIDENCE" "$BUILD_SUCCESS" "$DEPLOY_CLEAN" "$BLOCK_RISK" "$ROLLBACK_PROB" <<'PY'
import sys, yaml, os
from pathlib import Path
from datetime import datetime, timezone

(task_id, verdict, confidence,
 build_success, deploy_clean, block_risk, rollback_prob) = sys.argv[1:8]

escalated = (verdict == "escalate_to_opus")
out = Path(f"docs/handoff/{task_id}/premortem.yaml")
out.parent.mkdir(parents=True, exist_ok=True)

data = {
    "task_id": task_id,
    "phase": "haiku",
    "verdict": verdict,
    "confidence": float(confidence),
    "probability_table": {
        "build_success":        float(build_success),
        "deploy_clean":         float(deploy_clean),
        "block_risk":           float(block_risk),
        "rollback_probability": float(rollback_prob),
    },
    "signals_used": [],
    "escalated_to_opus": escalated,
    "timestamp_utc": datetime.now(timezone.utc).isoformat(),
}
import tempfile
tmp = out.with_suffix(".tmp")
tmp.write_text(yaml.safe_dump(data, sort_keys=False))
os.replace(tmp, out)
print(f"[premortem-haiku-writer] wrote {out} (escalated={escalated})", file=sys.stderr)
PY
```

Note: if `escalated_to_opus: true`, the Opus premortem path (leadv2-premortem)
MUST also run and will overwrite this file with the final values.

## System-prompt budget

≤600 input tokens. YAML-only output.
