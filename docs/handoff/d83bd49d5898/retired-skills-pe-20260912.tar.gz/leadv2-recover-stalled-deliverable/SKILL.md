---
name: leadv2-recover-stalled-deliverable
description: When a subagent (developer/architect/Explore) returns without DELIVERABLE_COMPLETE — cutoff, mid-sentence truncation, context overflow — try ONE SendMessage recovery. Hard cap=1 per task. After one retry fails, lead falls back to direct Edit/Write or escalates to architect-opus. NEVER spawn a third instance of the same agent-type on the same task.
---

# /leadv2-recover-stalled-deliverable

Lead-only skill. When a subagent returns without `DELIVERABLE_COMPLETE` marker, try ONE recovery via SendMessage. If that also fails, lead writes directly or escalates to architect-opus. Never spawn a third same-type instance — two failures = the agent cannot solve this class of problem; throwing more at it wastes budget.

## Trigger heuristics
Lead detects a stall when:
- Agent output ends mid-sentence (e.g. trailing `:`, `Let me check…`, `Now I'll write…`).
- No `DELIVERABLE_COMPLETE` or equivalent marker present.
- Reported usage shows context near-limit (high `tool_uses` count + truncated final message).
- Promised commit hash absent from `git log origin/main`.

We hit this 3+ times on 2026-05-27/28 (BUG-ENGAGEMENT) with developer-sonnet agents.

## Procedure

```bash
TASK_ID="${LEADV2_TASK_ID:?TASK_ID required}"
COUNTER_FILE="/tmp/pe-recover-stalled-${TASK_ID}.txt"
PRIOR=$(cat "$COUNTER_FILE" 2>/dev/null || echo 0)
```

1. Read prior counter. If `PRIOR >= 1` → STOP, fall through to lead direct-edit or architect-opus escalation. Do NOT call this skill again for this task this session.
2. Increment counter: `echo $((PRIOR + 1)) > "$COUNTER_FILE"`.
3. SendMessage to the same agentId with a continuation prompt that:
   - States what's verifiably done so far (`git diff` of any cited commits, files known to exist on disk).
   - States the remaining sub-tasks precisely — file:line where to edit, what to add.
   - Requires `bash -n` / `python3 -c "import ast; ast.parse(...)"` on each file before commit.
   - Caps remaining mission to ≤120 LOC. If the rest is bigger, the lead SPLITS first (Phase A core + Phase B tests/deploy) and dispatches only Phase A.
4. Wait for response. Capture commit hash if reported.
5. Verify on disk: `git log origin/main --oneline -3` must show the new commit. If not → second stall.
6. On second stall → STOP, do not spawn a third. Either:
   - Lead writes directly with Edit/Write (preferred for ≤200 LOC remaining).
   - Escalate to architect-opus with full state dump if the problem is conceptual (e.g. library API mismatch, broken design).

## Counter cleanup
At Phase 8 close: `rm -f /tmp/pe-recover-stalled-*.txt`. Clear before starting a new task.

## When NOT to use
- Agent returned `DELIVERABLE_COMPLETE` with `verdict: BLOCKED` — that IS a successful delivery; act on the verdict, don't retry.
- Founder is actively waiting and the remaining work is <50 LOC — write directly, faster than another agent round-trip.
- Two prior recovery attempts on the same task already failed — escalate or lead-write only.

## Why not a PostToolUse hook
Architect verdict (2026-05-28 `architect-retro-deferred-review.md`): a PostToolUse hook on the Agent tool that spawns another Agent risks recursion. "No DELIVERABLE_COMPLETE" is a fuzzy signal — sometimes agents legitimately omit it. Lead judgment with explicit invocation beats automated retry for this class.

Related: `feedback_token_budget_hard_cap`, `feedback_phase8_close_discipline`, `feedback_verify_library_api_real_source`.
