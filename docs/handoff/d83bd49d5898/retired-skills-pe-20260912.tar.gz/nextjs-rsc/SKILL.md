---
name: nextjs-rsc
description: "Use when building, reviewing, or debugging any file under web/ — RSC patterns, Server Actions, Suspense boundaries, data fetching, or 'use client' placement."
---

# Next.js 16 App Router — RSC Patterns

Before touching any file under `web/`, read `docs/design-system.md` (tokens,
Phosphor icons, primitives, customer language, dark+light themes).

This skill covers the App Router rendering model: when components run on the
server, when they run on the client, how to stream slow data, and how Server
Actions replace API routes for mutations.

## When to use
- Adding a new page or route under `web/app/`
- Deciding where to place `"use client"` boundaries
- Wiring up a Server Action for form mutations or button clicks
- Debugging hydration mismatches or stale cached data
- Setting up `<Suspense>` to stream slow API responses

## When NOT to use
- Pages Router patterns (not used in this project)
- API-only route handlers that have no React component counterpart
- Debugging server-side Python or Supabase logic unrelated to the web layer

## Core patterns

### Default: everything is a Server Component

```typescript
// web/app/dashboard/page.tsx — Server Component by default, no directive needed
export default async function DashboardPage() {
  const data = await fetchFromSupabase()  // runs on server, secrets safe
  return <DashboardOverview data={data} />
}
```

Never add `"use client"` to a page that only reads data. The directive
propagates down — every child of a Client Component becomes a client bundle.

### Push "use client" to the leaves

```typescript
// Good: isolate interactivity at the edge of the tree
// web/components/primitives/RefreshButton.tsx
"use client"
import { useTransition } from "react"
import { refreshAction } from "@/app/actions/refresh"

export function RefreshButton() {
  const [pending, startTransition] = useTransition()
  return (
    <button disabled={pending} onClick={() => startTransition(() => refreshAction())}>
      {pending ? "Refreshing…" : "Refresh"}
    </button>
  )
}
```

### Server Actions for mutations

```typescript
// web/app/actions/persona.ts
"use server"
import { revalidatePath } from "next/cache"
import { createClient } from "@/lib/supabase/server"

export async function updatePersonaName(id: string, name: string) {
  const supabase = createClient()
  const { error } = await supabase
    .from("personas")
    .update({ name })
    .eq("id", id)
  if (error) return { error: error.message }
  revalidatePath(`/personas/${id}`)
  return { success: true }
}
```

Server Actions run only on the server. Never call `revalidatePath` from a
Client Component — trigger it inside the action instead.

### Streaming slow data with Suspense

```typescript
// web/app/activity/page.tsx
import { Suspense } from "react"
import { ActivitySkeleton } from "@/components/primitives/Skeleton"

export default async function ActivityPage() {
  return (
    <div>
      <PageHeader title="Activity" />
      <Suspense fallback={<ActivitySkeleton />}>
        <ActivityFeed />   {/* fetches slowly — streams in */}
      </Suspense>
    </div>
  )
}

// This component suspends until its data resolves
async function ActivityFeed() {
  const items = await getActivityItems()  // slow Supabase query
  return <ul>{items.map(i => <ActivityRow key={i.id} item={i} />)}</ul>
}
```

Give `<Suspense>` a `key` prop when the fallback should reset on param changes
(e.g., `key={searchParams.page}`).

### Route handlers (API endpoints)

```typescript
// web/app/api/personas/[id]/route.ts
import { NextRequest, NextResponse } from "next/server"

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const data = await getPersona(id)
  if (!data) return NextResponse.json({ error: "Not found" }, { status: 404 })
  return NextResponse.json(data)
}
```

`params` is a Promise in Next.js 15+. Always await it.

### Tag-based cache invalidation

```typescript
// Fetch with a cache tag so targeted revalidation works
const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/personas`, {
  next: { tags: ["personas"], revalidate: 60 },
})

// In a Server Action after a write:
import { revalidateTag } from "next/cache"
revalidateTag("personas")
```

## Common pitfalls (our codebase)

- **Hardcoded colors / Lucide icons.** Both are forbidden. Use CSS tokens
  (`var(--surface-raised)`) and Phosphor icons only.
- **UUID or raw JSON visible to customer.** Translate at the boundary: resolve
  IDs to names, shape data into customer language before returning from a
  Server Component.
- **`"use client"` at the page level.** This sends everything to the browser.
  Isolate it to interactive leaves only.
- **Vercel deploy: never `cd web`.** Run `vercel --cwd web` or set `rootDir`
  in `vercel.json`. Always `vercel link` first in a fresh checkout.
- **TypeScript check before commit.** Run `cd web && npx tsc --noEmit` — CI
  will reject type errors.
- **Skipping `loading.tsx`.** Every slow page needs either `loading.tsx` or an
  explicit `<Suspense>` wrapper. Missing both causes a blank stall.

## Verification

- `npx tsc --noEmit` from `web/` — zero errors before commit.
- Verify dark and light themes both render correctly (no hardcoded colors).
- Check Network tab: RSC payload arrives as `text/x-component` (server-rendered
  HTML streamed as React flight data), not a full JSON blob.
- Confirm no UUIDs or raw field names appear in customer-visible UI text.
