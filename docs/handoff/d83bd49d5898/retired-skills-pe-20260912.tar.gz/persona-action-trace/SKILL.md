---
name: persona-action-trace
description: Fetch full lifecycle trace for a single action_id — Supabase row + VPS journal lines + failure-stage diagnosis. Use when an action failed, was skipped, or got stuck and you need to pinpoint where in the pipeline it broke. Trigger with /persona-action-trace <action_id>.
---

# /persona-action-trace — Single Action Lifecycle Tracer

Takes one argument: an `action_id` UUID. Fetches the Supabase row, greps the
VPS journal, and identifies the failure stage with an actionable next step.

## Procedure

### 1. Fetch action row from Supabase

Query `action_log` for the given action_id:

```
select=created_at,persona_id,action_type,status,status_reason,target,context,payload
filter: action_id=eq.<action_id>
limit=1
```

Use `sb_get` (sourced from `platform/adapters/supabase/client.sh`) or the
Supabase REST API directly with service-role key:

```bash
curl -s "${SUPABASE_URL}/rest/v1/action_log?action_id=eq.<action_id>&select=created_at,persona_id,action_type,status,status_reason,target,context,payload&limit=1" \
  -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
  -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}"
```

Print the row as formatted JSON. If no row found, stop and report "action_id not found in action_log."

### 2. Derive SSH target from persona_id

From the `persona_id` field in the row:

| persona_id     | SSH target                    | repo path                    |
|----------------|-------------------------------|------------------------------|
| cascina-tiglio | `root@178.104.186.246`        | `/home/persona/persona-engine` |
| respiro-brand  | `claudebot@204.168.169.186`   | `/home/claudebot/persona-engine` |

For cascina-tiglio, use identity file: `-i ~/.ssh/cascina-tiglio-key` if present.

### 3. Grep journal on VPS for this action_id

SSH to the VPS and run:

```bash
journalctl -u persona-engine.service --since "30 min ago" --no-pager -o cat \
  | grep "<action_id>" | head -50
```

If the action `created_at` is older than 30 minutes, expand the window:

```bash
journalctl -u persona-engine.service --since "<created_at minus 5 minutes>" \
  --until "<created_at plus 30 minutes>" --no-pager -o cat \
  | grep "<action_id>" | head -50
```

Print the matching journal lines chronologically.

### 4. Identify failure stage

Match the journal lines against these keywords (in order — first match wins):

| Keyword in log               | Failure stage        |
|------------------------------|----------------------|
| `pre_screen_skip`            | pre_screen stage     |
| `drafter_skip`               | drafter stage        |
| `verdict=reject` (×2 occurrences) | critic stage (hard reject after 2 redrafts) |
| `verdict=defer`              | critic stage (soft defer) |
| `runner_execute_failed`      | execute stage        |
| `runner_blocked_safety`      | post_gate stage      |
| `published`                  | SUCCESS              |

If no keywords match, report "stage unknown — check journal window (action may be older than 30 min)."

### 5. Print structured summary

```
=== ACTION TRACE: <action_id> ===
persona:     <persona_id>
action_type: <action_type>
status:      <status>
reason:      <status_reason>
target:      <target (truncated to 80 chars)>
created_at:  <created_at>

--- Journal lines ---
<journal lines chronologically>

--- Diagnosis ---
Failure stage: <stage from step 4>
Actionable next step: <see table below>
```

### 6. Actionable next steps by stage

| Stage        | Next step |
|--------------|-----------|
| pre_screen   | Check pre-screen rules in `agent/pre-actions/pre-screen.sh`; verify opportunity still valid (target not deleted/private) |
| drafter      | Check LLM backend availability (`ANTHROPIC_API_KEY` env); look for rate-limit errors in journal |
| critic       | Check voice-card examples for this action_type; run `/persona-tune-voice <persona_id> <action_type>` if reject rate is high |
| execute      | Check Threads token validity; run `scripts/check-cookie-expiry.sh`; verify target post still exists |
| post_gate    | Safety gate is working as intended for warm-up personas — check if spacing thresholds are calibrated correctly |
| SUCCESS      | No action needed — action published successfully |
| unknown      | Expand journal time window; check if action was processed in a different service unit |
