---
name: persona-tune-voice
description: Diagnose high critic-reject rate for a persona+action_type pair, identify the dominant rejection pattern from journal logs, and propose new voice-card examples to fix it. Requires founder approval before writing. Trigger with /persona-tune-voice <persona_id> <action_type>.
---

# /persona-tune-voice — Voice Card Example Tuner

Takes two arguments: `<persona_id>` and `<action_type>` (one of: `comment`, `post`).

Diagnoses why the critic keeps rejecting drafts and proposes targeted new
examples. Requires founder approval (via AskUserQuestion) before writing any file.

## Procedure

Fetch rejected actions from Supabase → grep VPS journal for rejection reasons
→ read the current voice card → identify the dominant rejection pattern →
propose new GOOD EXAMPLES → get founder approval via AskUserQuestion → on
"Apply", write/commit/deploy; on "Skip"/"Edit", handle accordingly without
writing.

**Full step-by-step (exact queries, SSH commands, message templates):
`.claude/handbooks/persona-tune-voice-procedure.md`.**

## P-E: Voice-DNA Size Gate

Before drafting any additions to `voice-dna.md`, run:

```bash
bash .claude/scripts/voice-dna-size-check.sh
```

If the file returns WARN (> 3072 bytes), recommend extracting concrete examples
into a separate `voice-dna-examples.md` before adding more content. The core
`voice-dna.md` should contain rules and constraints only — not example banks.

To get JSON output (e.g. for programmatic checks):
```bash
bash .claude/scripts/voice-dna-size-check.sh --json | jq .
```

Exit code 1 = at least one file over threshold. Exit code 0 = all clear.
