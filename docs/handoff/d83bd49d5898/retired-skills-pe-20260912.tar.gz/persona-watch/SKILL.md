---
name: persona-watch
description: Periodic production-health audit for both Threads personas (Respiro + Cascina del Tiglio / Marco): detect deviation → diagnose → fix via subagent → deploy both VPS → report to Telegram. Trigger with /persona-watch. Covers throughput lagging, image-post ratio below target, pipeline errors, stalled cadence, discovery gaps, queue starvation, scoring lag, learning loop failures, voice stagnation, engagement collection gaps, and snapshot staleness.
---

# /persona-watch — Persona Production Health Audit

Repeatable monitoring + fix routine for the two live personas. Codifies the
audit-and-fix approach: **detect deviation → diagnose → fix via subagent →
review diff → deploy both VPS → verify → report**.

## Topology

| Persona | VPS | ssh | repo | tz | wake | targets |
|---|---|---|---|---|---|---|
| respiro-brand | 204.168.169.186 | `claudebot@` | /home/claudebot/persona-engine | NY (America/New_York) | 7–21 | 6 posts / 60 comments, 30% image |
| cascina-tiglio | 178.104.186.246 | `root@` (run as `persona`) | /home/persona/persona-engine | Rome (Europe/Rome) | 7–22 | 2 posts / 5 comments, 45% image |

Each VPS has its own Supabase project. Helpers: `source .env && source platform/lib/common.sh && source platform/adapters/supabase/client.sh`, then `sb_get` / `sb_update`. Full pipeline map: `docs/ops/persona-pipeline-monitoring.md`.

## Procedure

### 1. Detect
Run the deviation detector:
```bash
bash scripts/persona-healthcheck.sh
```
It pulls live counters + journal from both VPS and compares against norms.
Exit 0 = within norms; exit 1 = at least one `[ALERT]`; exit 2 = probe failure.

For cron callers, use quick-status mode (no Telegram, no fixes, one-line summary to stdout):
```bash
bash scripts/persona-healthcheck.sh quick
```

Deviation signals checked:
- **Signal 1 — Throughput pace**: actual posts/comments vs time-of-day pace toward daily target. `[ALERT]` if comments < 60% of pace.
- **Signal 2 — Image-post ratio**: fraction of today's posts carrying a photo. `[ALERT]` if < target (30% respiro, 45% cascina).
- **Signal 3 — Pipeline errors**: failed/blocked actions, FATAL/Traceback in journal, 5 consecutive `tool_calls=0` cycles.
- **Signal 4 — Cadence / stale**: `next_session_at` locked > 90min ahead during wake hours, no `Cycle start` in 40min, crash_count ≥ 3, scan-feed not completing.
- **Signal 5 — Discovery pipeline freshness**: `discovery_sessions` today by session_type; `[ALERT]` if 0 sessions in last 4h during wake hours; `[WARN]` if any session has error_code set.
- **Signal 6 — Queue health**: `operator_opportunity_queue` pending/claimed/resolved counts; `[ALERT]` if pending=0 AND claimed=0 (queue starved); `[WARN]` if claimed > 5 (piling up).
- **Signal 7 — Scoring lag**: `action_log` confirmed rows with `scored_at IS NULL` older than threshold (6h posts, 3h comments); `[ALERT]` if lag > 5.
- **Signal 8 — Learning loop health**: `learning_loop_health` last 24h; `[ALERT]` if last exit_code != 0; `[WARN]` if no rows in 24h; `[WARN]` if all `action_bandits` arms updated > 48h ago.
- **Signal 9 — Voice evolution**: `voice_evolution_proposals` last 14d by status; `[WARN]` if 0 applied in last 14d; reports current `voice_dna_versions` version + age.
- **Signal 10 — Engagement collection**: `engagement_aggregates` for today; `[ALERT]` if persona posted ≥ 2 posts but 0 rows (signals not collecting).
- **Signal 11 — Daily snapshot freshness**: `daily_snapshot` today; `[ALERT]` if row missing after 12:00 local time; `[WARN]` if followers unchanged across last 2 snapshots.
- **Signal 12 — Safety gate block rate**: ratio of `status=failed` with `status_reason LIKE 'runner_blocked_safety%'` over total non-planned; `[ALERT]` if > 50%.
- **Signal 13 — RAG lift health**: reads `agent/state/beliefs.json` on VPS for `rag_lift` value; `[WARN]` if field missing (insufficient data); `[ALERT]` if `rag_lift ≤ 0pp` (RAG providing no quality uplift).

### 2. If no alerts
Post a one-line "within norms" summary to Telegram (topic 103 via the sender below) and stop. Do not fix what is not broken.

### 3. Diagnose each [ALERT]
For every `[ALERT]` line, pull the relevant journal context (`journalctl -u persona-engine.service` / `persona-scan-feed.service` on the VPS) and consult the failure-mode table in `docs/ops/persona-pipeline-monitoring.md`. To pinpoint a code root cause without burning context, spawn `Agent(subagent_type=Explore, model=haiku)` with a narrow question (file:line, the precondition). Do not trace the whole lifecycle.

### 4. Fix via subagent
Spawn `Agent(subagent_type=developer, model=sonnet, run_in_background=true)` per fix with a precise mission: the diagnosed root cause, the exact change wanted, "do NOT commit/push — leave tree dirty for review", `bash -n`, minimal surgical diff. The orchestrator never writes the .sh/.py/.sql code itself.

### 5. Review the diff — mandatory
`git diff <file>` every change before deploy. Agent summaries describe intent, not what landed. Past /persona-watch runs caught real bugs in agent output (a global lost across a `$(...)` subshell; a `local`-scoped var that should be global; an off-by-one). Verify the logic, not just that a diff exists.

### 6. Deploy both VPS
```bash
git add <files> && git commit -m "<conventional msg>" && git push origin main
# then per VPS — file-only checkout (avoids drift):
ssh persona@178.104.186.246   'cd ~/persona-engine && git fetch origin main && git checkout origin/main -- <files>'
ssh claudebot@204.168.169.186 'cd ~/persona-engine && git fetch origin main && git checkout origin/main -- <files>'
```
Config-only changes under `agent/state/` need `touch /tmp/pe-state-write-override` before the local Edit.

### 7. Verify
Force a fresh cycle so the fix is exercised immediately:
```bash
# on each VPS shell, with sb_* sourced:
sb_update persona_config "persona_id=eq.<id>" "{\"next_session_at\":\"$(date -u +%Y-%m-%dT%H:%M:%S+00:00)\"}"
```
Then `Monitor` the journal for the expected signal (publish / escalation / redraft). Confirm the action_log row reached `status=confirmed` — "tests green" is not verification, a real published action is.

### 8. Report to Telegram
Topic 103. Sender:
```bash
TOKEN=$(awk -F= '/TELEGRAM_BOT_TOKEN/{print $2}' .claude/secrets/telegram.env)
curl -sS "https://api.telegram.org/bot${TOKEN}/sendMessage" \
  -d chat_id=-1003936724876 -d message_thread_id=103 -d parse_mode=HTML \
  --data-urlencode "text=<message>"
```
Report: what deviated, the root cause, the commit, deploy status. Terse.

## Quick-status mode

For cron callers that need a one-line health pulse without triggering fixes or Telegram:

```bash
bash scripts/persona-healthcheck.sh quick
```

Behaviour:
- Runs the full check (all 12 signals) against live DB.
- Emits a single line to stdout: `persona-healthcheck: OK <iso-timestamp>`, `ALERT(<N>) <ts>`, or `PROBE_FAIL <ts>`.
- No Telegram messages sent.
- No auto-fixes triggered.
- Exit codes remain the same (0 = ok/warn, 1 = alert, 2 = probe failure).

Cron example (runs every 30 min, logs to syslog):
```cron
SHELL=/bin/bash
*/30 * * * * /home/claudebot/persona-engine/scripts/persona-healthcheck.sh quick | logger -t persona-watch
```

## Rules
- Fix authority is pre-granted — diagnose and fix without asking, deploy to both VPS.
- One concern at a time: fix, review, deploy, verify before starting the next. Don't batch unrelated changes into one commit.
- Posts are 4h-spaced (human-behaviour safety) — never shorten post spacing to chase the post target. Comment cadence is the throughput lever.
- The critique gate rejecting drafts (`reject`/`revise`) is content quality, not a pipeline bug — do not weaken the critique to raise numbers. Flag it to the founder instead.
- After fixes, leave `Monitor` armed on cycle results and keep watching — a /persona-watch run ends when the deviation is verified resolved, not when the commit lands.
