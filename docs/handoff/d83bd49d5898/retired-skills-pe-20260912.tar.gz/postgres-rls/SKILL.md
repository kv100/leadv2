---
name: postgres-rls
description: "Use when writing or reviewing Postgres schemas, RLS policies, partial indexes, or diagnosing PostgREST PGRST102 errors in the Supabase-managed database."
---

# Postgres RLS & PostgREST Patterns

Supabase uses managed Postgres with PostgREST as the HTTP layer. Most schema
and policy bugs only surface at runtime. This skill covers RLS policy design,
partial indexes, EXPLAIN ANALYZE workflow, and the PostgREST-specific traps
we consistently hit.

## When to use
- Writing or reviewing RLS policies on any table
- Designing indexes (especially partial or expression-based)
- Debugging PGRST102 batch upsert failures
- Adding Supabase service-role bypass patterns
- Running EXPLAIN ANALYZE to diagnose slow queries

## When NOT to use
- Supabase connection pooling config (PgBouncer, max_connections) — separate ops concern
- Postgres replication or WAL tuning — not relevant on managed instances
- `pg_partman` table partitioning — not in use in this project

## Core patterns

### RLS: service-role bypass

```sql
-- Always add a service-role bypass before user-facing policies.
-- Without it, backend agents (which use the service key) hit RLS too.
CREATE POLICY "service_role_bypass" ON public.actions
  AS PERMISSIVE FOR ALL
  TO service_role
  USING (true);
```

### RLS: per-persona row isolation

```sql
-- Typical pattern: user sees only rows belonging to their persona.
CREATE POLICY "owner_select" ON public.posts
  FOR SELECT TO authenticated
  USING (persona_id IN (
    SELECT id FROM public.personas
    WHERE owner_id = auth.uid()
  ));
```

Avoid calling functions like `auth.uid()` inside `USING` on hot tables without
a supporting index — the planner cannot push the predicate down if it is
non-immutable. Wrap in a security-definer helper if needed.

### Partial indexes

```sql
-- Index only the rows that matter; keep the index small.
CREATE INDEX idx_actions_pending
  ON public.actions (persona_id, created_at DESC)
  WHERE status = 'pending';
```

Partial-unique indexes and PostgREST upsert interact badly (see pitfalls).

### EXPLAIN ANALYZE workflow

```sql
-- Always use BUFFERS to see cache hits vs disk reads.
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT * FROM public.actions
WHERE persona_id = $1 AND status = 'pending'
ORDER BY created_at DESC
LIMIT 10;
```

Look for: `Seq Scan` on large tables, `rows=N` estimates far from actual,
`Bitmap Heap Scan` with many recheck rows — all indicate missing or wrong index.

### Composite index column order

```sql
-- Put the equality column first, the range/sort column second.
-- Wrong order forces a full index scan for range queries.
CREATE INDEX idx_actions_persona_created
  ON public.actions (persona_id, created_at DESC);
-- ↑ persona_id = $1 hits the first level; created_at filters the rest.
```

### Batch upsert via PostgREST (PGRST102)

```bash
# PGRST102 fires when the batch rows do NOT all share the same column set.
# Every JSON object in the array must have identical keys.
# Partial-unique indexes also break ON CONFLICT upsert — use a full unique
# constraint or switch to a regular unique index instead.

curl -X POST "$SUPABASE_URL/rest/v1/actions" \
  -H "Prefer: resolution=merge-duplicates" \
  -H "Content-Type: application/json" \
  -d '[{"id":"...","persona_id":"...","status":"pending"},
       {"id":"...","persona_id":"...","status":"pending"}]'
# ↑ Both objects have the same keys — valid batch.
```

### Check columns before INSERT

```sql
-- Run before writing any INSERT/UPDATE in a new migration.
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'actions'
ORDER BY ordinal_position;
```

## Common pitfalls (our codebase)

- **Local `.env` hits PROD Supabase.** Always verify `SUPABASE_URL` before
  running any migration or direct SQL. Add `SELECT current_database();` as a
  sanity check at the top of ad-hoc scripts.
- **Partial-unique index + upsert.** PostgREST `ON CONFLICT` cannot target a
  partial index. Either promote to a full unique constraint or do a manual
  SELECT → INSERT/UPDATE in a function.
- **PGRST102 identical-keys rule.** A batch where even one row has an extra
  field fails the entire request. Strip or fill to make all objects uniform.
- **RLS off by default on new tables.** `ALTER TABLE ... ENABLE ROW LEVEL
  SECURITY;` is separate from policy creation. Easy to miss.
- **Non-immutable functions in USING clauses.** `now()` or `current_setting()`
  in a policy blocks index-only scans. Use stable or immutable alternatives.
- **Never run raw SQL migrations manually.** Use the `/migrate` skill to track
  every schema change in `supabase/migrations/`.

## Verification

- `EXPLAIN (ANALYZE, BUFFERS)` shows actual vs estimated row counts.
- `\d+ table_name` in psql shows indexes and policies together.
- `SELECT * FROM pg_policies WHERE tablename = 'actions';` confirms RLS state.
- PostgREST error `PGRST102` → check batch key uniformity and index type.
- After enabling RLS, test with both `anon`/`authenticated` role AND
  `service_role` to confirm bypass works.
