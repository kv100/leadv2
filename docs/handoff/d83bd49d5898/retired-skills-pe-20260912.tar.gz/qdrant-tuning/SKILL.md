---
name: qdrant-tuning
description: "Use when creating or modifying Qdrant collections, tuning HNSW parameters, designing payload indexes, or optimizing vector search recall/latency for the 1024-dim bge-large embeddings."
---

# Qdrant Collection Design & Tuning

This project uses FastEmbed `bge-large-en-v1.5` (1024 dimensions, cosine
distance) with Qdrant as the vector store. Collections hold RAG knowledge
chunks, target profiles, and scored content. This skill covers collection
creation, HNSW parameter selection, payload indexing, batch upsert sizing,
and query-time ef tuning for our scale.

## When to use
- Creating a new Qdrant collection
- Diagnosing slow search latency or recall degradation
- Adding payload fields that need filtering (not just storage)
- Batch-upserting embeddings from FastEmbed output
- Adjusting ef at query time for precision vs speed trade-off

## When NOT to use
- Choosing an embedding model — bge-large-en-v1.5 is fixed
- Pinecone, Weaviate, or Milvus — not in use here
- Exact-search over tiny sets (<5K vectors) — skip HNSW, use flat scan

## Core patterns

### Collection creation for 1024-dim bge-large

```python
from qdrant_client import QdrantClient
from qdrant_client.http import models

client = QdrantClient(url=QDRANT_URL, api_key=QDRANT_API_KEY)

client.create_collection(
    collection_name="knowledge_chunks",
    vectors_config=models.VectorParams(
        size=1024,                       # bge-large-en-v1.5
        distance=models.Distance.COSINE,
    ),
    hnsw_config=models.HnswConfigDiff(
        m=16,               # balanced: good recall, moderate memory
        ef_construct=128,   # higher = better graph, slower build
    ),
    optimizers_config=models.OptimizersConfigDiff(
        indexing_threshold=20_000,   # start HNSW after 20K vectors
        memmap_threshold=50_000,
    ),
)
```

### HNSW parameter guide

| Target | m | ef_construct | Notes |
|---|---|---|---|
| Fast build, modest recall | 8 | 64 | Dev/staging only |
| Balanced (default) | 16 | 128 | Production default |
| High recall | 32 | 256 | Knowledge RAG, scoring |
| Max recall | 48 | 256 | Use only if recall <0.95 |

Memory estimate for 1024-dim FP32: `N × (1024×4 + m×2×4)` bytes.
100K vectors with m=16: ≈ 420 MB.

### Payload index for filtered search

```python
# Index every field you filter on — unindexed payload forces a full scan.
client.create_payload_index(
    collection_name="knowledge_chunks",
    field_name="persona_id",
    field_schema=models.PayloadSchemaType.KEYWORD,
)
client.create_payload_index(
    collection_name="knowledge_chunks",
    field_name="created_at",
    field_schema=models.PayloadSchemaType.DATETIME,
)
```

Only index fields used in `must`/`should` filters. Indexing unused fields
wastes RAM and slows upserts.

### Batch upsert sizing

```python
from qdrant_client.http import models as qmodels

BATCH_SIZE = 256   # sweet spot for 1024-dim; adjust down if OOM

def upsert_in_batches(client, collection, points):
    for i in range(0, len(points), BATCH_SIZE):
        batch = points[i : i + BATCH_SIZE]
        client.upsert(
            collection_name=collection,
            points=batch,
            wait=True,   # confirm persistence before continuing
        )
```

Batches over 512 points at 1024 dims can hit Qdrant's default gRPC message
size limit. If you see gRPC `RESOURCE_EXHAUSTED`, halve `BATCH_SIZE`.

### Query-time ef (search precision)

```python
results = client.search(
    collection_name="knowledge_chunks",
    query_vector=embedding,
    limit=10,
    search_params=models.SearchParams(
        hnsw_ef=128,    # raise to 256 for max recall; lower for speed
        exact=False,
    ),
    query_filter=models.Filter(
        must=[models.FieldCondition(
            key="persona_id",
            match=models.MatchValue(value=persona_id),
        )]
    ),
)
```

`hnsw_ef` at query time overrides the collection default. Use 64–128 for
normal RAG lookups; 256 for quality-sensitive retrieval where latency budget
allows.

### Scalar quantization (INT8) to cut memory

```python
# Add to create_collection when memory is constrained.
# Recall drop is typically <2% with rescore=True.
quantization_config=models.ScalarQuantization(
    scalar=models.ScalarQuantizationConfig(
        type=models.ScalarType.INT8,
        quantile=0.99,
        always_ram=True,
    )
)
# At search time, rescore with full precision:
search_params=models.SearchParams(
    hnsw_ef=128,
    quantization=models.QuantizationSearchParams(
        rescore=True,
        oversampling=2.0,
    ),
)
```

## Common pitfalls (our codebase)

- **Filtering on unindexed payload.** Qdrant does a full segment scan if the
  field has no payload index. Always add `create_payload_index` for every
  field that appears in a filter.
- **Skipping `wait=True` on upsert.** Without it, a subsequent search may
  return stale results from the previous segment. Set `wait=True` in any
  write path that expects immediate readback.
- **Upsert batch too large.** 1024-dim FP32 vectors are 4 KB each. 512
  vectors = 2 MB payload per batch. Qdrant's default gRPC limit is 4 MB;
  stay under 256 points per batch unless you've raised the server limit.
- **`m` too low for recall.** m=8 produces a sparse graph; recall drops
  below 0.90 at 100K+ vectors. Use m=16 minimum for any production collection.
- **ef_construct too low relative to m.** ef_construct should be at least
  2×m. ef_construct=64 with m=32 degrades index quality significantly.
- **Not warming the index.** A cold Qdrant instance (just restarted) is slow
  for the first few queries — vectors are loaded from disk. Run a few warmup
  queries before benchmarking.

## Verification

- `client.get_collection(name)` → check `vectors_count`, `indexed_vectors_count`
  (should converge after `indexing_threshold` is passed).
- `client.get_collection_info(name).optimizer_status` → `"ok"` when indexing
  is complete; `"optimizing"` during background index builds.
- Compare `limit=10` search with `exact=True` vs `exact=False` on a sample
  query to measure recall loss from HNSW approximation.
- Monitor `payload_schema` in collection info to confirm indexes are registered.
