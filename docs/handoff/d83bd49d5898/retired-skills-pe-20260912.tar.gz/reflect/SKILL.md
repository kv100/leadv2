---
name: reflect
effort: medium
user-invocable: true
description: Session reflection. Git review, learnings queue, doc freshness audit.
---

# Reflect Skill

End-of-session wrap-up. Run: `/reflect`.

## Step 1: Session Review

```bash
git diff --stat HEAD~5..HEAD 2>/dev/null || git diff --stat
git log --oneline -10
```

Summarize: files changed, features/fixes, decisions, open questions.

## Step 2: Process Learnings Queue

```bash
cat ~/.claude/learnings-queue.json 2>/dev/null || echo '{"learnings": []}'
```

For each learning — decide: **update existing memory** or **skip** (if derivable from code/git).

Rules:
- NEVER create new memory files for project state (bugs fixed, features added) — that's git log
- NEVER create memory for code patterns — that's in the codebase graph
- Only create/update memory for: user feedback, process corrections, non-obvious constraints
- Max 60 lines in MEMORY.md. If over — prune stale entries first
- Prefer updating existing files over creating new ones

After processing:
```bash
echo '{"learnings": []}' > ~/.claude/learnings-queue.json
```

## Step 3: Doc Freshness

Find docs modified this session, update `<!-- updated: YYYY-MM-DD -->` headers:
```bash
git diff --name-only HEAD~5..HEAD 2>/dev/null | grep "\.md$" | grep -E "^docs/"
```

Report missing headers in `docs/specs/`.

## Step 4: Final Report

```
/reflect complete — {date}
Session: {N} files, {M} commits
Learnings: {N} processed, {N} skipped
Docs: {updated/missing headers}
Memory: {files modified/created or "no changes"}
```

## Skip Rules

- No git changes → skip Step 1
- Queue empty → skip Step 2
- No docs/ changes → skip Step 3
