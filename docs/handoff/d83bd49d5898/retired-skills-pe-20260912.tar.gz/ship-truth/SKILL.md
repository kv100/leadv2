---
name: ship-truth
description: Runs scripts/ship-truth.sh and reports the four work-loss ledger sections (BUILT-NOT-MERGED, MERGED-NOT-DEPLOYED, DEPLOYED-NOT-ENABLED, ENABLED-NOT-PROVEN), derived live from git + the VPS + the prod .env. Triggered by "/ship-truth", "что не задеплоено", "что потерялось", "ship truth", "покажи ledger".
---

# /ship-truth — work-loss ledger

Everything the session built, deployed, enabled, and proved — derived
machine-side from git + the live VPS + the live prod `.env`, **never** from a
hand-maintained doc. Answers: "what did we build this session that never
shipped, what shipped that never got turned on, and what's on that we never
proved works?"

## Run it

```bash
bash scripts/ship-truth.sh              # writes docs/systems-map/SHIP-TRUTH.md, prints summary
bash scripts/ship-truth.sh --json       # same, plus full JSON to stdout
bash scripts/ship-truth.sh --summary    # counts + headlines only (used by the session-start sensor)
```

One SSH round trip to the VPS (read-only: `git rev-parse HEAD` + `.env` `PE_*`
keys only — never a raw `.env` dump, never a secret value). Safe to re-run any
time; no writes anywhere.

## Reading the report

`docs/systems-map/SHIP-TRUTH.md` has four sections:

1. **BUILT, NOT MERGED** — local/remote branches not yet in `origin/main`.
2. **MERGED, NOT DEPLOYED** — `origin/main` commits not yet on the VPS.
3. **DEPLOYED, NOT ENABLED** — `PE_*` flags with an OFF default that are
   off/unset in prod today, bucketed via `docs/systems-map/flag-buckets.yaml`
   into TEST / KILLSWITCH / OPS / DORMANT-FEATURE / UNCLASSIFIED.
   **DORMANT-FEATURE is the money section** — real product features sitting
   dark.
4. **ENABLED, NOT PROVEN** — flags ON in prod with no `proof:` command
   recorded in `flag-buckets.yaml` (the anti-"lying green" section).

## Triaging DORMANT-FEATURE / UNCLASSIFIED flags

`docs/systems-map/flag-buckets.yaml` is hand-editable — that's the point (it's
the ONE piece of this system that's curated, everything else is derived).
When triaging an `UNCLASSIFIED` flag:

- Decide its bucket: `TEST` | `KILLSWITCH` | `OPS` | `DORMANT-FEATURE`.
- If it's `DORMANT-FEATURE` and worth flipping on, that's a founder decision
  — don't flip flags from inside this skill.
- If a flag IS on in prod, add a `proof:` key (a re-runnable probe command,
  e.g. an `ssh ... journalctl | grep <key>` line) so it drops out of Section 4.

## Staleness guard

`tests/unit/test_ship_truth_flag_buckets.py` fails CI if any `PE_*` flag with
an off-default in code is missing from `flag-buckets.yaml` — new flags can
never silently disappear from the ledger. Run it after adding a flag:

```bash
python3 -m pytest tests/unit/test_ship_truth_flag_buckets.py -v
```

## Session-start sensor (5th feature-liveness sensor)

`.claude/hooks/feature-liveness-session-inject.sh` runs
`scripts/ship-truth.sh --summary` (best-effort, 20s timeout, capped at 10
lines) on every session start and folds the four counts + DORMANT-FEATURE +
MERGED-NOT-DEPLOYED headlines into `additionalContext`, alongside the
existing 4 feature-liveness sensors. Never blocks session start; a ship-truth
failure/timeout is silently dropped.
