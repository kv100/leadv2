---
name: supabase-ops
description: "Use when writing supabase-py queries, debugging PostgREST errors (PGRST102, 42P01), setting up RLS policies, performing upserts or batch inserts, managing service-role vs anon key discipline, or running migrations in this project."
---

# Supabase Day-to-Day Ops

Practical patterns for working with Supabase in this codebase: `supabase-py` query patterns, RLS policy writing, upsert/batch gotchas, key discipline, and migrations. This project connects to **production Supabase** at all times — local `.env` points to the live database, not a local instance.

## When to use
- Writing or debugging `supabase-py` queries (`sb_get`, `sb_insert`, raw `execute`)
- Authoring or auditing RLS policies
- Batch upserts hitting PGRST102 or partial-index conflicts
- Deciding whether a call needs service-role vs anon key
- Running a schema migration (always via `/migrate` skill, not raw SQL)

## When NOT to use
- Frontend Supabase JS client (`@supabase/supabase-js`) — patterns differ slightly, but the key discipline and RLS rules still apply
- Supabase Edge Functions deployment — separate workflow
- Qdrant / vector operations — different client entirely

## Core patterns

### 1. supabase-py basics

```python
from supabase import create_client

# Service-role: bypasses RLS — use only in backend/agent code
supabase = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

# Anon key: subject to RLS — use for anything acting as a user
supabase_anon = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)

# SELECT with filter
rows = (
    supabase.table("actions")
    .select("id, status, created_at")
    .eq("persona_id", persona_id)
    .order("created_at", desc=True)
    .limit(20)
    .execute()
)
data = rows.data  # list of dicts; rows.count if you passed count= arg
```

Always check columns before writing: run `SUPABASE_GET_TABLE_SCHEMAS` or check `supabase/migrations/` before adding an INSERT — columns you assume exist may not.

### 2. RLS policy patterns

Policies use `auth.uid()` for authenticated users and `current_setting('request.jwt.claims', true)::json` for service-role checks.

```sql
-- Allow persona owner to read their own rows
CREATE POLICY "owner_read" ON actions
  FOR SELECT USING (
    persona_id IN (
      SELECT id FROM personas WHERE owner_id = auth.uid()
    )
  );

-- Service-role bypasses all RLS automatically — no policy needed for backend writes
-- Never create a policy that opens SELECT/INSERT to anon role without a predicate
```

Enable RLS on every new table immediately after creation:
```sql
ALTER TABLE new_table ENABLE ROW LEVEL SECURITY;
```

### 3. PostgREST upsert — PGRST102 and partial-index trap

**PGRST102** means the upsert conflict target could not be resolved. Two common causes:

**A. Partial unique index** — PostgREST cannot use a partial index (one with a `WHERE` clause) as the upsert target. Use a full unique index or unique constraint instead, or fall back to raw SQL `INSERT ... ON CONFLICT`.

```python
# FAILS if the unique index is partial (has WHERE clause)
supabase.table("snapshots").upsert({"persona_id": pid, "date": d, "value": v}).execute()

# WORKS — raw SQL can reference partial index predicate explicitly
supabase.rpc("upsert_snapshot", {"p_persona_id": pid, "p_date": d, "p_value": v}).execute()
```

**B. Batch upsert with inconsistent keys** — Every row in a batch upsert must have exactly the same set of keys. Mixed key sets trigger PGRST102.

```python
# WRONG — rows have different keys
rows = [{"id": 1, "value": "a"}, {"id": 2, "value": "b", "extra": "x"}]

# RIGHT — all rows identical structure; fill missing fields with None
rows = [{"id": 1, "value": "a", "extra": None}, {"id": 2, "value": "b", "extra": "x"}]
supabase.table("t").upsert(rows).execute()
```

### 4. Service-role vs anon key discipline

| Key | Bypasses RLS | When to use |
|---|---|---|
| `SUPABASE_SERVICE_ROLE_KEY` | Yes | Agent/backend writes, migrations, admin reads |
| `SUPABASE_ANON_KEY` | No | Dashboard API routes acting on behalf of a user |

Never use `SERVICE_ROLE_KEY` in browser-side or client-facing code. Never log either key — truncate to last 4 chars in log output.

The project's `sb_insert` / `sb_get` helpers (in `platform/`) inject `run_mode` silently and always use the service-role client. Do not call the raw Supabase client directly in platform code unless those helpers cannot express the query.

### 5. Migrations

All schema changes go through the `/migrate` skill, not raw SQL in the console or direct `psql`. This ensures changes are tracked in `supabase/migrations/` and applied consistently across environments.

```
# Correct workflow:
/migrate   ← invokes the skill, prompts for SQL, writes migration file, applies it

# Never do:
# - Paste DDL into Supabase Studio SQL editor without a migration file
# - Run supabase db push without a corresponding migration file committed to git
```

## Common pitfalls (our codebase)

- **Local `.env` writes to PROD** — There is no local Supabase instance. Every query you run locally hits the production database. Treat every Supabase call as production-grade.
- **PGRST102 on partial index** — The `snapshots` and several action tables use partial unique indexes. Upserts on these tables require either raw SQL or restructuring the index to be non-partial.
- **PGRST102 on batch upsert** — Mixed key sets in the batch array silently fail with this error. Normalize all rows to identical key sets before batching.
- **Assuming columns exist** — Check `supabase/migrations/` or introspect the table before adding INSERT/UPDATE statements. Schema drift from migrations-not-applied is a known source of `42703` (column not found) errors.
- **Anon key in backend** — Using `SUPABASE_ANON_KEY` in agent/platform code means RLS blocks the write silently (returns empty data, no error). Always verify which key the client was initialized with when debugging missing writes.

## Verification
- Migration file committed to `supabase/migrations/` before any DDL lands in production
- Every new table has `ENABLE ROW LEVEL SECURITY` in its migration
- Upsert batch rows have identical key sets (assert with `assert len({frozenset(r) for r in rows}) == 1`)
- Service-role key never appears in `web/` or any client-side code path
- `PGRST102` on upsert — check for partial index and batch key consistency before anything else
