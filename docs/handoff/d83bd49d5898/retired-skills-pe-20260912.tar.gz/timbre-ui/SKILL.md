---
name: timbre-ui
description: Timbre dashboard UI/UX design system. REQUIRED for any work in web/ — tokens, primitives, archetypes, copy conventions. Triggers on UI changes, page rebuilds, component creation, redesign, styling, theming, dashboard work. Prevents re-inventing primitives, hardcoding colors, using Lucide icons, showing UUIDs/raw JSON to customers.
---

# Timbre UI Skill

**This skill is mandatory for any work inside `web/`.** It loads the canonical design system and enforces it.

## Trigger keywords
Auto-invoke when the task mentions:
- Any path under `web/app/`, `web/components/`, `web/app/globals.css`
- "UI", "UX", "dashboard", "page", "component", "design", "theme", "primitive"
- "redesign", "polish", "style", "visual", "aesthetic"
- Specific page names (/health, /focus, /queue, /fleet, /stories, /safety, /analytics, /experiments, /growth, /efficiency, /notifications, /settings)
- Specific primitives (KpiCard, BreathingRing, ContextPanel, FleetCard, EmptyState, LifecycleTrack, ExplainPopover, TrustCard, ActionCard, ScoreWaveform, TeachRejectModal, PriorityRail, ThemeToggle, CommandPalette)

## How to apply this skill

### Step 1 — Read the canonical doc
**ALWAYS** read `docs/design-system.md` first. It has tokens, primitives, archetypes, forbidden list. Recent + authoritative.

### Step 2 — Check the research pack (if deep work)
Only when context is needed:
- `docs/redesign/10-design-v3.md` — full direction, execution plan, rationale
- `docs/redesign/07-multi-persona-ux.md` — multi-persona flows
- `docs/redesign/08-functionality-audit.md` — E2E wiring of controls
- `docs/redesign/09-references.md` — pattern library

### Step 3 — Enforce the 10 hard rules

1. **Tokens only** — `var(--surface-raised)`, never `bg-white` / hex / named Tailwind colors
2. **Phosphor only** — no Lucide in new code (`@phosphor-icons/react`)
3. **No emoji** in UI
4. **No UUIDs / raw JSON** visible to customer (always fallback to handle/name/slug; always narrate data)
5. **`tabular-nums`** on every digit
6. **Compose primitives** from `web/components/primitives/` — never reinvent
7. **Amber accent is precious** — only AI-active + primary CTA (never status, never categories)
8. **Every page = one archetype** — Overview / Timeline / Report / Configuration (see §3 of design-system.md)
9. **Customer language** — pillars → themes, T1 → Key, session → activity cycle, confirmed → published
10. **Both themes** — adaptive dark (espresso hero) + light must both look good

### Step 4 — Compose, don't invent

Available primitives (never reinvent):
- `<BreathingRing>` — agent runtime state (shape + color + motion)
- `<KpiCard>` — signal-bearing metric (value + delta + trend + rationale)
- `<ScoreWaveform>` — inline sparkline (inside KpiCard)
- `<ExplainPopover>` — short tooltip for "why"
- `<ContextPanel>` — right slide-over for deep drill-in
- `<LifecycleTrack>` — 6-dot pipeline progress
- `<EmptyState>` — 3 variants: not-configured | no-data-yet | filtered-zero
- `<FleetCard>` — persona at-a-glance (row | card variants)
- `<TeachRejectModal>` — rejection = teaching moment
- `<PriorityRail>` — shell trust surface (autonomy | crisis variants)
- `<CommandPalette>` — ⌘K global nav
- `<ThemeToggle>` — system/light/dark cycle

### Step 5 — Verify before commit

Run:
```bash
cd web && npx tsc --noEmit
```

Checklist:
- [ ] Zero hardcoded colors
- [ ] All primitives existing (no new invented)
- [ ] Phosphor only in new code
- [ ] No emoji, UUIDs, raw JSON
- [ ] Customer language
- [ ] `tabular-nums` on digits
- [ ] Focus-visible rings (`ring-2 ring-[var(--accent)] ring-offset-2`)
- [ ] Dark AND light modes tested
- [ ] TypeScript clean
- [ ] Fits an archetype

## Forbidden (see §8 of design-system.md)

Beyond the 10 hard rules above (Lucide icons, emoji, UUIDs/raw JSON, hardcoded
colors, competing accents — all covered there), also forbidden:

- ❌ `window.confirm` / `window.alert`
- ❌ `rounded-2xl` or larger on every card
- ❌ Heavy shadows (shadow-lg) except modals
- ❌ Rainbow per-category hues
- ❌ Spinners longer than 500ms (use skeleton)
- ❌ Hover-only controls on mobile
- ❌ Card-within-card-within-card

## Delegating to sub-agents

When spawning sub-agents for UI work, include in the prompt:

> **READ `docs/design-system.md` FIRST** before touching any UI file.
> Use primitives from `web/components/primitives/` — don't reinvent.
> Tokens only (`var(--...)` — no hardcoded colors).
> Phosphor icons only. No emoji. No UUIDs. No raw JSON.
> Customer language (pillars→themes, T1→Key, etc.).
> Both dark and light modes must look good.
> `pnpm typecheck` must pass.

## Copy conventions (§5 of design-system.md)

| Don't say | Do say |
|---|---|
| `pillars` | themes |
| `T1/T2/T3/T4` | Key / Growing / New / Watching |
| `operator_playbook` | direction / brief |
| `session` | activity cycle (usually hide) |
| `action_log` | activity |
| `tool calls: 31` | hide (engineering data) |
| `$0.059` | hide unless API-billing customer |
| `ci_lower: 22.69` | "Confident in this read" |
| `lift: 1.13` | "13% above baseline" |
| `pending_approval` | awaiting your review |
| `runtime state: acting` | Your agent is working |

**"So what?" rule**: every test result, every learning, every number needs a sentence explaining what it means for the customer: "→ Your agent will now favor questions over reframes in comments going forward."

**Plural/verb rule**: "20 adjustments" is meaningless. Write: "Your agent tuned its comment scoring 20 times today, refining what to reply to."

## If in doubt

**If you catch yourself inventing a primitive — STOP, compose existing.**
**If you catch yourself hardcoding a color — STOP, use a token.**
**If you catch yourself explaining agent internals — STOP, translate to customer language.**

Path cascade for reference:
1. `docs/design-system.md` — canonical, short, current
2. `docs/redesign/10-design-v3.md` — full v3 spec
3. `docs/redesign/06-09*.md` — research pack (aesthetic critique, UX, audit, references)
4. `.claude/rules/04-design-system.md` — orchestrator rule
