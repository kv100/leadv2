---
name: worktree-context-show
description: List all live git worktrees in this repo + their branches + commits-ahead-of-main. Run at start of any /leadv2 session in a multi-worktree environment to avoid subagents quoting file:line from another worktree. Triggered by "worktree show", "active worktrees", "что в worktree", session-startup auto-invoke.
---

# /worktree-context-show

Lists all live worktrees + branches + ahead-of-main count. Use at session start when parallel `/leadv2` sessions may be active — keeps subagent file:line quotes scoped to MY tree.

## Run

```bash
git worktree list --porcelain | awk '
  /^worktree /{wt=$2}
  /^branch /{br=$2}
  /^$/{ if (wt) {
    cmd="cd "wt" && git rev-list --count main..HEAD 2>/dev/null || echo 0"
    cmd | getline ahead; close(cmd)
    cmd="cd "wt" && git status --porcelain 2>/dev/null | wc -l"
    cmd | getline dirty; close(dirty)
    printf "%s\n  branch=%s ahead=%s dirty=%s\n", wt, br, ahead, dirty
    wt=""; br=""; ahead=""; dirty=""
  }}
'
```

## Output shape

```
/Users/kostiantyn.vlasenko/Projects/persona-engine
  branch=refs/heads/main ahead=0 dirty=0

/Users/kostiantyn.vlasenko/Projects/persona-engine/.claude/worktrees/BUG-X
  branch=refs/heads/worktree-BUG-X ahead=2 dirty=0

/Users/kostiantyn.vlasenko/Projects/persona-engine/.claude/worktrees/DASHBOARD-Y
  branch=refs/heads/worktree-DASHBOARD-Y ahead=5 dirty=3
```

## Subagent-scope rule

When a subagent quotes `file:line` for diagnosis or proposed fix, the path MUST start with **my** worktree root. If it starts with `worktrees/<other-task>/` — the subagent escaped scope; ignore the finding or mark it `(found in other worktree — not mine to fix)`.

This bit us 2026-05-27: Explore quoted `worktrees/DASHBOARD-AUDIT-PO-01/scripts/threads-login-flow.py:358-389` as the location of a Playwright auth-capture diagnostic emitter the founder asked me to delete. The file didn't exist in my branch (`ls` confirmed). I almost spent time hunting for the right file before realizing the cross-worktree leak.

## Auto-invoke recommendation
- Start of every `/leadv2 <task>` (Phase 0 INTAKE): run this skill, write output to `docs/leadv2/tasks/<id>/worktree-context.md`. Subsequent subagent missions get a copy of that file appended so they know the scope boundary.
- When founder asks "что у нас активно" / "что в worktree".
- After `EnterWorktree` succeeds.

## Mission-template patch
For any subagent mission referencing the codebase, add to constraints:
> File:line quotes MUST be in `<MY_WORKTREE_ROOT>`. Quotes from other worktrees fail the deliverable. If the right answer lives in another worktree, report that and STOP — don't fabricate by guessing.

Related: `feedback_no_nested_worktree.md`, `feedback_no_touch_parallel_sessions.md`.
