#!/usr/bin/env bash
# leadv2-status-collector-facts.sh — persona-engine repo-specific facts for
# leadv2-status-collector.sh (STATUS-COLLECTOR-01). Sourced, not executed;
# must define collect_repo_facts(), which prints ONE JSON object to stdout.
#
# STATUS-COLLECTOR-ENABLE-01 (2026-07-29): promoted here via `git mv` from the
# staged scripts/ location -- this is the one path leadv2-status-collector.sh
# actually checks (PROJECT_ROOT/.claude/leadv2-overrides/status-collector-facts.sh,
# hardcoded, no env-var fallback). The prior header claimed a
# STATUS_COLLECTOR_FACTS_HOOK env-var fallback; that was never implemented in
# collector.sh and is not real -- don't rely on it.
#
# Every fact below encodes a trap the mission named verbatim — see the
# comment on each function. Traps live HERE, in code, exactly once, instead
# of being re-typed into every status-agent prompt (the thing that kept
# producing wrong numbers: 892, 25.7%, 81%, a false "0 posts").
#
# Each fact function is independently guarded by _scf_run(); one bad fact
# never loses the others. Keep DB load small: every query is bounded
# (limit=, a time window) — this runs against a 2GB prod instance.

set -uo pipefail  # sourced into a `set -euo pipefail` subshell by the caller

_SCF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# NOT "${_SCF_DIR}/.." -- this file lives at .claude/leadv2-overrides/, two
# levels below repo root, not one. STATUS-COLLECTOR-ENABLE-01: the original
# staging location (scripts/, one level down) made "${_SCF_DIR}/.." resolve
# to repo root by coincidence; after the git mv promotion that guess silently
# resolved to .claude/ instead and .env never loaded (every DB-backed fact
# would report ok:false forever, indistinguishable at a glance from "measured
# and it's really down"). Prefer the caller's PROJECT_ROOT (collector.sh cds
# there and exports it before sourcing this file); fall back to walking up
# from _SCF_DIR only if PROJECT_ROOT is unset (e.g. this file sourced solo).
_SCF_ROOT="${PROJECT_ROOT:-$(cd "${_SCF_DIR}/../.." && pwd)}"

if [[ -f "${_SCF_ROOT}/.env" ]]; then
  set -a
  # shellcheck source=/dev/null
  source "${_SCF_ROOT}/.env"
  set +a
fi

# TRAP: action_log.persona_id / feed_posts.persona_id is the SLUG STRING
# ("respiro-brand"), never the personas.id UUID — a UUID silently returns
# zero rows (memory: feedback-verify-persona-tables-by-slug). Hardcode the
# slug here rather than accept an arbitrary override, so this file cannot
# be pointed at a UUID by a careless caller.
_SCF_PERSONA="respiro-brand"
_SCF_TENANT="respiro-brand"   # publish_slots.tenant_id — same value, different column name
_SCF_SSH_HOST="claudebot@204.168.169.186"
_SCF_SSH_REPO="/home/claudebot/persona-engine"
_SCF_SSH_SERVICE="persona-engine.service"
_SCF_SSH_OPTS=(-o BatchMode=yes -o StrictHostKeyChecking=accept-new -o ConnectTimeout=8 -o ServerAliveInterval=5 -o ServerAliveCountMax=2)
_SCF_SSH_TIMEOUT=15

_scf_fail() {
  # $1 = error message -> {"ok": false, "error": "..."} on stdout
  python3 -c "import json,sys; print(json.dumps({'ok': False, 'error': sys.argv[1]}))" "$1"
}

# Run a fact function; return its stdout as a bare JSON VALUE (no key
# wrapper). On non-zero exit or invalid JSON, substitute a well-formed
# {"ok":false,"error":...} instead of ever emitting garbage.
_scf_capture() {
  local fn="$1" out err
  out="$(mktemp)"; err="$(mktemp)"
  if "$fn" >"$out" 2>"$err" && python3 -c "import json,sys; json.load(open(sys.argv[1]))" "$out" >/dev/null 2>&1; then
    cat "$out"
  else
    _scf_fail "$(tail -c 300 "$err" | tr -d '\000' | tr '\n' ' ')"
  fi
  rm -f "$out" "$err"
}

# Run a fact function; print it as a `"key": <json>` pair. Thin wrapper over
# _scf_capture so the "published" fact (also needed raw, to derive the
# posts_today/comments_today/replies_today top-level keys) shares one path.
_scf_run() {
  local key="$1" fn="$2"
  printf '"%s":' "$key"
  _scf_capture "$fn"
}

# ── db: reachability + latency ───────────────────────────────────────────
_scf_fact_db() {
  [[ -n "${SUPABASE_URL:-}" && -n "${SUPABASE_SERVICE_ROLE_KEY:-}" ]] || {
    echo "SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY not set" >&2; return 1; }
  local t0 t1 code
  t0="$(python3 -c 'import time; print(time.time())')"
  code="$(curl -s -o /dev/null --max-time 5 -w '%{http_code}' --head \
    -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
    -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}" \
    "${SUPABASE_URL%/}/rest/v1/" 2>/dev/null)" || code="000"
  t1="$(python3 -c 'import time; print(time.time())')"
  python3 -c "
import json, sys
code, t0, t1 = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
print(json.dumps({'ok': True, 'reachable': code not in ('000',) and code.startswith(('2','3','4')),
                   'http_code': code, 'latency_ms': round((t1 - t0) * 1000, 1)}))
" "$code" "$t0" "$t1"
}

# ── postgres uptime / autovacuum recency ────────────────────────────────
# Deliberately NOT implemented against a new RPC: this collector does not
# ship an unreviewed Postgres migration to prod (a service_role RPC exists
# already for database_capacity_report(), added 2026-07-29, but nothing
# exposes pg_postmaster_start_time()/pg_stat_user_tables.last_autovacuum
# over PostgREST yet). Reports honestly as unmeasured rather than
# fabricating a number or silently omitting the key. Proposed follow-up
# migration is in developer.full.md.
_scf_fact_postgres() {
  echo "no RPC exposes pg_postmaster_start_time()/autovacuum stats yet — see developer.full.md for the proposed migration" >&2
  return 1
}

# ── db size (the ONE piece of postgres-health we CAN get: existing RPC) ──
_scf_fact_db_capacity() {
  [[ -n "${SUPABASE_URL:-}" && -n "${SUPABASE_SERVICE_ROLE_KEY:-}" ]] || {
    echo "SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY not set" >&2; return 1; }
  local out
  out="$(curl -s --max-time 8 -X POST \
    -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
    -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}" \
    -H "Content-Type: application/json" \
    "${SUPABASE_URL%/}/rest/v1/rpc/database_capacity_report" 2>/dev/null)" || { echo "rpc call failed" >&2; return 1; }
  python3 -c "
import json, sys
d = json.loads(sys.argv[1])
print(json.dumps({'ok': True, 'database_bytes': d.get('database_bytes'),
                   'database_mb': round((d.get('database_bytes') or 0) / 1e6, 1)}))
" "$out" 2>/dev/null || { echo "rpc response not valid JSON: $out" >&2; return 1; }
}

# ── engine health (journald) + deployed sha — one ssh round trip ────────
# TRAP guarded: journald is on the VPS only, never local; ssh is
# BatchMode+timeout-wrapped so a dead host degrades to ok:false, not a hang.
_scf_fact_engine() {
  local remote_out
  # macOS has no GNU `timeout`.  Python's stdlib gives the probe the same
  # bounded behaviour without adding a platform dependency.
  remote_out="$(python3 - "$_SCF_SSH_TIMEOUT" "$_SCF_SSH_HOST" "$_SCF_SSH_REPO" "$_SCF_SSH_SERVICE" "${_SCF_SSH_OPTS[@]}" <<'PY'
import subprocess, sys

timeout_s, host, repo, service, *ssh_options = sys.argv[1:]
command = (
    f"cd '{repo}' && echo SHA=$(git rev-parse --short HEAD) && "
    f"journalctl -u '{service}' -o cat --since '10 min ago' 2>/dev/null | "
    "grep -cE 'ERROR|Traceback' || true"
)
try:
    result = subprocess.run(
        ["ssh", "-n", *ssh_options, host, command],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=float(timeout_s),
    )
except subprocess.TimeoutExpired as exc:
    sys.stdout.write((exc.stdout or "") if isinstance(exc.stdout, str) else "")
    sys.stderr.write(f"ssh timed out after {timeout_s}s\\n")
    sys.exit(124)
sys.stdout.write(result.stdout or "")
sys.exit(result.returncode)
PY
  )" || { echo "ssh to $_SCF_SSH_HOST failed: $remote_out" >&2; return 1; }
  local sha errcount
  sha="$(printf '%s\n' "$remote_out" | grep -m1 '^SHA=' | sed 's/^SHA=//')"
  errcount="$(printf '%s\n' "$remote_out" | grep -v '^SHA=' | tail -1)"
  [[ "$errcount" =~ ^[0-9]+$ ]] || errcount=0
  python3 -c "
import json, sys
print(json.dumps({'ok': True, 'deployed_sha': sys.argv[1] or None,
                   'error_lines_last_10min': int(sys.argv[2])}))
" "$sha" "$errcount"
}

# ── published posts/comments: today vs yesterday, NY working day ────────
# TRAP guarded: 'today' = America/New_York calendar date, never UTC and
# never the machine's local date (a UTC-date bug produced a false "0 posts
# published" while 4 had shipped). Proof of publish = an id in context —
# posts: context.media_id, comments: context.own_comment_media_id — never a
# status column (status is intent, not proof). (published_text DOES exist in
# live context jsonb -- re-verified against prod 2026-08-24 -- but it is still
# not proof of publish; text-only fallback is context.text.)
#
# EGRESS-FAT-QUERIES-01 (2026-08-24): context is narrowed to a key projection
# (context->>key / context->key) instead of pulling the whole jsonb. The old
# full-context pull was ~194 KB per beat (62 rows, ~3.1 KB/row -- one fat row
# inflates every beat); the projection measured ~35 KB for the SAME 62 rows
# and identical derived values. Projection also removes the malformed-row
# trap: context->>key yields SQL NULL on a non-object context, where the old
# `.get` on a string raised AttributeError and lost the WHOLE fact.
_scf_fact_published() {
  [[ -n "${SUPABASE_URL:-}" && -n "${SUPABASE_SERVICE_ROLE_KEY:-}" ]] || {
    echo "SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY not set" >&2; return 1; }
  local since out
  since="$(python3 -c 'import datetime; print((datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(days=2)).strftime("%Y-%m-%dT%H:%M:%SZ"))')"
  out="$(curl -s --max-time 15 \
    -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
    -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}" \
    "${SUPABASE_URL%/}/rest/v1/action_log?select=action_type,confirmed_at,media_id:context->>media_id,own_comment_media_id:context->>own_comment_media_id,chain_post_ids:context->chain_post_ids,published_text:context->>published_text,ctext:context->>text,host_virality:context->host_virality,pr_host_virality:context->publish_result->host_virality&persona_id=eq.${_SCF_PERSONA}&run_mode=eq.prod&action_type=in.(post,image_post,comment,reply)&confirmed_at=gte.${since}&confirmed_at=not.is.null&limit=5000" \
    2>/dev/null)" || { echo "action_log query failed" >&2; return 1; }
  python3 -c "
import json, sys, datetime
try:
    from zoneinfo import ZoneInfo
    NY = ZoneInfo('America/New_York')
except Exception:
    NY = datetime.timezone(datetime.timedelta(hours=-4))
rows = json.loads(sys.argv[1])
now_ny = datetime.datetime.now(NY)
today = now_ny.strftime('%Y-%m-%d')
yesterday = (now_ny - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
buckets = {today: {'posts': 0, 'comments': 0, 'replies': 0}, yesterday: {'posts': 0, 'comments': 0, 'replies': 0}}
today_published = []
host_likes, host_replies, host_ages_seconds = [], [], []
for r in rows:
    ts = r.get('confirmed_at')
    if not ts:
        continue
    dt = datetime.datetime.fromisoformat(ts.replace('Z', '+00:00')).astimezone(NY)
    d = dt.strftime('%Y-%m-%d')
    if d not in buckets:
        continue
    at = r.get('action_type')
    media_id = r.get('media_id') if at in ('post', 'image_post') else r.get('own_comment_media_id')
    # POST-COUNTER-BLIND-TO-CHAINS-01: a published series post writes
    # context.chain_post_ids and never context.media_id -- media_id alone
    # undercounts every chain to zero. Mirrors web/lib/published-post.ts
    # isPublishedPostContext: published = media_id truthy OR chain_post_ids
    # a non-empty array. One qualifying row = ONE post (never
    # sum(chain_post_ids.length)); comments/replies are untouched, they
    # still key on own_comment_media_id only.
    chain_ids = r.get('chain_post_ids') if at in ('post', 'image_post') else None
    is_chain_published = isinstance(chain_ids, list) and len(chain_ids) > 0
    published = bool(media_id) or is_chain_published
    if at in ('post', 'image_post') and published:
        buckets[d]['posts'] += 1
    # PULSE-IN-SINGLE-LEAD-01 tail fact: founder tracks replies separately
    # from comments (comment != reply). Proof of success is still
    # context.own_comment_media_id for BOTH -- only the bucket differs.
    if at == 'comment' and media_id:
        buckets[d]['comments'] += 1
    if at == 'reply' and media_id:
        buckets[d]['replies'] += 1
    if d == today and published:
        today_published.append({
            'persona_slug': '${_SCF_PERSONA}',
            'action_type': at,
            'media_id': str(media_id) if media_id else ('chain:' + str(chain_ids[0])),
            'text': r.get('published_text') or r.get('ctext') or '',
        })
        hv = r.get('host_virality') or r.get('pr_host_virality') or {}
        if isinstance(hv, dict):
            for field, values in (('likes', host_likes), ('replies', host_replies)):
                try:
                    values.append(float(hv[field]))
                except (KeyError, TypeError, ValueError):
                    pass
            captured = hv.get('captured_at')
            if captured:
                try:
                    host_ages_seconds.append((now_ny - datetime.datetime.fromisoformat(captured.replace('Z', '+00:00')).astimezone(NY)).total_seconds())
                except (TypeError, ValueError):
                    pass
def median(values):
    if not values:
        return None
    values = sorted(values)
    mid = len(values) // 2
    return values[mid] if len(values) % 2 else (values[mid - 1] + values[mid]) / 2
print(json.dumps({'ok': True, 'ny_date_today': today, 'today': buckets[today],
                   'yesterday': buckets[yesterday],
                   'today_published_texts': today_published,
                   'host_virality_medians': {
                     'sample_size': max(len(host_likes), len(host_replies)),
                     'likes': median(host_likes), 'replies': median(host_replies),
                     'age_seconds': median(host_ages_seconds)}}))
" "$out" 2>/dev/null || { echo "action_log response not valid JSON: $(printf '%s' "$out" | head -c 200)" >&2; return 1; }
}

# ── newest post texts ────────────────────────────────────────────────────
# TRAP guarded: feed_posts has NO `text` column — the real column is
# `content`. Selecting `text` is a PostgREST 400, not a false zero.
_scf_fact_newest_posts() {
  [[ -n "${SUPABASE_URL:-}" && -n "${SUPABASE_SERVICE_ROLE_KEY:-}" ]] || {
    echo "SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY not set" >&2; return 1; }
  local out
  out="$(curl -s --max-time 10 \
    -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
    -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}" \
    "${SUPABASE_URL%/}/rest/v1/feed_posts?select=content,scanned_at&persona_id=eq.${_SCF_PERSONA}&order=scanned_at.desc&limit=3" \
    2>/dev/null)" || { echo "feed_posts query failed" >&2; return 1; }
  python3 -c "
import json, sys
rows = json.loads(sys.argv[1])
items = [{'content': (r.get('content') or '')[:140], 'scanned_at': r.get('scanned_at')} for r in rows]
print(json.dumps({'ok': True, 'items': items}))
" "$out" 2>/dev/null || { echo "feed_posts response not valid JSON" >&2; return 1; }
}

# ── slot states + hit-rate ────────────────────────────────────────────────
# TRAP guarded: publish_slots has `state`, NOT `status`, and no `slot_type`
# column — a wrong-column guess is a PostgREST 400 written into the prod log.
# hit_rate = published / (ALL states with scheduled_at <= now()), never
# omitting the time bound and never dividing by (ready+planned) alone —
# both wrong formulas produced bogus figures (892, 25.7%, 81%) before.
# PostgREST has no GROUP BY, so states are counted one Prefer: count=exact
# request per state (see EGRESS-FAT-QUERIES-01 note inside).
_scf_fact_slots() {
  [[ -n "${SUPABASE_URL:-}" && -n "${SUPABASE_SERVICE_ROLE_KEY:-}" ]] || {
    echo "SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY not set" >&2; return 1; }
  local now states counts_line s url hdr total
  now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  # EGRESS-FAT-QUERIES-01 (2026-08-24): the consumer only tallies, so rows are
  # never needed. Each count is one Prefer: count=exact + Range: 0-0 request
  # whose total arrives in the content-range HEADER (~21 B body) instead of a
  # row pull. This also fixes a silent truncation the row pull had: limit=
  # 10000 was never honoured -- PostgREST's db-max-rows capped the page at
  # 1000 rows and, with no order=, WHICH 1000 came back was not even stable.
  # Measured 2026-08-24: old code reported due_total=1000 / hit_rate=0.138
  # from the truncated page while the truth was 2734 / 0.2761. The reported
  # slot numbers therefore CHANGE with this edit, deliberately: correctness
  # beats byte-equality with a wrong number.
  # S4 guard: a 4xx PostgREST error body carries NO content-range header, so
  # a broken filter fails loudly here instead of degrading to a wrong count.
  # content-range "*/0" (empty set) parses as 0, never raises.
  states=("" planned ready due leased published late skipped publish_unknown)
  counts_line=""
  for s in "${states[@]}"; do
    url="${SUPABASE_URL%/}/rest/v1/publish_slots?select=state&tenant_id=eq.${_SCF_TENANT}&scheduled_at=lte.${now}"
    if [[ -n "$s" ]]; then
      url="${url}&state=eq.${s}"
    fi
    hdr="$(curl -s --max-time 15 -o /dev/null -D - \
      -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
      -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}" \
      -H "Prefer: count=exact" \
      -H "Range: 0-0" \
      "$url" | tr -d '\r' | awk 'tolower($1)=="content-range:"{print $2; exit}')" \
      || { echo "publish_slots count query failed (state=${s:-<all>})" >&2; return 1; }
    total="${hdr##*/}"
    # Strict format check (codex review M2): accept only "<range>/<total>" or
    # "*/<total>" -- reject garbage like "garbage/2735" that happens to end in
    # digits. With Range: 0-0 + count=exact the real shapes are "0-0/N" and
    # the empty-set "*/0".
    if [[ ! "$hdr" =~ ^([0-9]+(-[0-9]+)?|\*)/[0-9]+$ ]]; then
      echo "publish_slots count query returned no parseable content-range (state=${s:-<all>}, header='${hdr:-ABSENT}')" >&2
      return 1
    fi
    counts_line+="${s:-_total}=${total} "
  done
  python3 -c "
import json, sys
counts = dict(kv.split('=', 1) for kv in sys.argv[1].split())
due_total = int(counts.pop('_total'))
by_state = {k: int(v) for k, v in counts.items() if int(v) > 0}
# Unknown-state guard: if a future migration adds a 9th state to the CHECK
# constraint, the eight per-state counts fall short of the unfiltered total.
# Surface the remainder under 'other' and keep due_total from the unfiltered
# count, so hit_rate's denominator never quietly shrinks.
# A NEGATIVE remainder (codex review H1) means the nine requests raced a
# concurrent slot transition -- internally contradictory tallies -- so fail
# loudly (ok:false) rather than emit numbers that cannot all be true.
other = due_total - sum(by_state.values())
if other < 0:
    sys.exit('publish_slots per-state counts exceed unfiltered total '
             f'({sum(by_state.values())} > {due_total}) -- raced a concurrent transition')
if other > 0:
    by_state['other'] = other
published = int(counts.get('published', 0))
hit_rate = (published / due_total) if due_total > 0 else None
print(json.dumps({'ok': True, 'due_total': due_total, 'published': published,
                   'hit_rate': (round(hit_rate, 4) if hit_rate is not None else None),
                   'by_state': by_state}))
" "$counts_line" || { echo "publish_slots counts could not be tallied" >&2; return 1; }
}

# ── targets: throughput target + position in the NY working window ──────
# SUPERVISOR-STATUS-TABLE-IN-PLUGIN-01 tail fact: comments_per_day / posts_
# per_day are the founder-set daily targets (memory:
# project_respiro_working_hours -- 07:00-23:00 NY, a 16h window). "position"
# is elapsed-hours / 16 clamped to [0,1] so the status tail can say e.g.
# "6.5 of 16h elapsed" without the composer inventing the arithmetic.
_scf_fact_targets() {
  python3 -c "
import json, datetime
try:
    from zoneinfo import ZoneInfo
    NY = ZoneInfo('America/New_York')
except Exception:
    NY = datetime.timezone(datetime.timedelta(hours=-4))
now_ny = datetime.datetime.now(NY)
window_start_h, window_end_h = 7, 23
window_hours = window_end_h - window_start_h
today_start = now_ny.replace(hour=window_start_h, minute=0, second=0, microsecond=0)
today_end = now_ny.replace(hour=window_end_h, minute=0, second=0, microsecond=0)
if now_ny < today_start:
    elapsed_h, in_window = 0.0, False
elif now_ny > today_end:
    elapsed_h, in_window = float(window_hours), False
else:
    elapsed_h, in_window = (now_ny - today_start).total_seconds() / 3600.0, True
print(json.dumps({
    'ok': True,
    'comments_per_day': 60,
    'posts_per_day_min': 4,
    'posts_per_day_max': 6,
    'ny_window': '07:00-23:00',
    'window_hours': window_hours,
    'elapsed_hours': round(elapsed_h, 2),
    'elapsed_fraction': round(elapsed_h / window_hours, 4),
    'in_window': in_window,
}))
"
}

# ── virality: median + count clearing the is_viral flag ─────────────────
# feed_posts has no numeric virality score column (is_viral is a boolean
# set at scan time from likes >= avg_likes * viral_multiplier); reported as
# median `likes` among the last 24h of scanned candidates plus the count
# flagged is_viral=true. Never fabricate a 'target_virality' column that
# does not exist.
_scf_fact_virality() {
  [[ -n "${SUPABASE_URL:-}" && -n "${SUPABASE_SERVICE_ROLE_KEY:-}" ]] || {
    echo "SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY not set" >&2; return 1; }
  local since out
  since="$(python3 -c 'import datetime; print((datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ"))')"
  out="$(curl -s --max-time 15 \
    -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
    -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}" \
    "${SUPABASE_URL%/}/rest/v1/feed_posts?select=likes,is_viral&persona_id=eq.${_SCF_PERSONA}&scanned_at=gte.${since}&limit=5000" \
    2>/dev/null)" || { echo "feed_posts virality query failed" >&2; return 1; }
  python3 -c "
import json, sys, statistics
rows = json.loads(sys.argv[1])
likes = [r.get('likes') or 0 for r in rows]
viral_count = sum(1 for r in rows if r.get('is_viral'))
median = statistics.median(likes) if likes else None
print(json.dumps({'ok': True, 'sample_size': len(rows), 'median_likes': median,
                   'viral_count': viral_count}))
" "$out" 2>/dev/null || { echo "feed_posts virality response not valid JSON" >&2; return 1; }
}

collect_repo_facts() {
  local published_json body
  # Captured once, reused for both the "published" key AND the top-level
  # posts_today/comments_today/replies_today keys the founder pulse's line-1
  # renderer reads (leadv2-broad-status.sh _metric()) -- one query, two views.
  published_json="$(_scf_capture _scf_fact_published)"

  body="$(
    _scf_run "db" _scf_fact_db
    echo ","
    _scf_run "postgres" _scf_fact_postgres
    echo ","
    _scf_run "db_capacity" _scf_fact_db_capacity
    echo ","
    _scf_run "engine" _scf_fact_engine
    echo ","
    printf '"published":%s' "$published_json"
    echo ","
    _scf_run "newest_posts" _scf_fact_newest_posts
    echo ","
    _scf_run "slots" _scf_fact_slots
    echo ","
    _scf_run "targets" _scf_fact_targets
    echo ","
    _scf_run "virality" _scf_fact_virality
  )"
  echo "{${body}}" | python3 -c "
import json, sys
d = json.load(sys.stdin)

# PULSE-IN-SINGLE-LEAD-01 tail fact: the founder pulse's line-1 renderer
# (leadv2-broad-status.sh _metric()) reads posts_today/comments_today/
# replies_today TOP-LEVEL in repo_facts, not nested under 'published'. Only
# emit them when the published fact actually succeeded -- never fabricate 0
# for an unreadable metric (memory: feedback_flag_on_but_artifact_missing /
# 'a zero is probably a broken query'). Omitting the key is what makes the
# renderer print 'н/д' instead of a false zero.
pub = d.get('published') or {}
if pub.get('ok'):
    today = pub.get('today') or {}
    for metric, key in (('posts', 'posts_today'), ('comments', 'comments_today'), ('replies', 'replies_today')):
        v = today.get(metric)
        if isinstance(v, (int, float)):
            d[key] = v

# Founder throughput floor per NY working day (founder decision 2026-08-14,
# memory: project_throughput_floor_per_working_day): 6 posts / 60 comments /
# 10 replies. No config source states these (checked timing-config.json,
# safety-overrides.json) -- static constants are the founder's own numbers,
# not a query result, so they are always emitted (never gated on 'ok').
d['posts_floor'] = 6
d['comments_floor'] = 60
d['replies_floor'] = 10

# working_window: reuse the existing ny_window reader in _scf_fact_targets
# (memory: project_respiro_working_hours -- 07:00-23:00 NY) rather than a
# second source of truth. The renderer already falls back to ny_window if
# this key is absent, but set it explicitly for clarity.
targets = d.get('targets') or {}
window = targets.get('ny_window')
if window:
    d['working_window'] = window

print(json.dumps(d))
"
}
