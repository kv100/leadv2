#!/usr/bin/env bash
# tests/unit/test-anti-silence-pulse.sh — coverage for
#   scripts/anti-silence-pulse.sh (ANTI-SILENCE-HEARTBEAT-01)
#
# Drives the script's `--once --now=<epoch>` deterministic mode against a
# fixture active.yaml + fixture journal.md files, never against the real
# repo state. Exercises: live counting, the >30min ghost bucket (excluded
# from the live count, aggregated once), the probe verdicts (SWEEPER-FALSE-
# LIFE, 2026-09-09: a True verdict is LIVE «процесс» evidence rendering a •
# row; every other verdict collapses to not-alive and the ghost count
# stands alone), and the empty-board `live=0 — тишина` line verbatim.
# A journal mtime ALONE never renders live here either (same mission): it
# is a stamped ○ row, uncounted, named honestly.
#
# Declared negative control (E2E-KILLRATE-01): journal_candidates() in
# lib/leadv2-journal-address.py (MONITORS-ARE-THE-SECOND-CONSUMER-OF-THE-
# ADDRESS-RESOLVER-01 -- extracted out of this script into the shared module
# every lane-journal consumer now imports) resolves a session's journal in
# four ordered tiers -- (1) own root + founder task_id, (2) own root +
# dispatch key from sess.log_path, (3) foreign worktree root (sess.worktree)
# + founder task_id, (4) foreign worktree root + dispatch key. The control
# below applies, per tier, a mutation that deletes that tier's `_add(...)`
# call strictly INSIDE journal_candidates()'s body (never a top-level
# insert) to a COPY of the module (never the real file), then points the
# UNMODIFIED pulse script at that mutant copy via LEADV2_JOURNAL_ADDRESS_LIB:
# tiers 1 and 3 delete the `_add` line outright; tiers 2 and 4 replace the
# `_add` call with `pass` at the same indent -- they are the sole statement
# of their `if dispatch_key:` block, so deleting the line bare would turn
# the control red via a Python IndentationError (red for the wrong reason);
# the call itself is gone either way and the tier resolves nothing. Under
# each mutation the tier's probe must flip from `<task_id>=5m` to
# `<task_id>=нет-журнала` (pre_rc=1), and the clean module must still
# resolve it (post_rc=0). If a mutation stops breaking its probe (mutant
# survived) or the clean module stops resolving (regression), this suite
# goes red. The one-off 2026-09-04 out-of-band run of the same four
# mutations against the real file is archived as leadv2-mutation-control.sh
# artifacts under docs/handoff/dispatch-e9272511/mutation-control/.
set -euo pipefail

_TEST_DIR="$(cd "$(dirname "$0")" && pwd)"
_ROOT="$(cd "${_TEST_DIR}/../.." && pwd)"
# shellcheck source=/dev/null
source "${_TEST_DIR}/../harness.sh"

_PULSE_SH="${_ROOT}/scripts/anti-silence-pulse.sh"
_JA_LIB="${_ROOT}/.claude/leadv2/scripts/lib/leadv2-journal-address.py"

_TMP="$(mktemp -d)"
trap 'rm -rf "${_TMP}"' EXIT

_ACTIVE_YAML="${_TMP}/active.yaml"
_TASKS_DIR="${_TMP}/tasks"
_LOG_FILE="${_TMP}/anti-silence-pulse.log"
_PID_FILE="${_TMP}/anti-silence-pulse.pid"
_PROBE_SH="${_TMP}/leadv2-lane-liveness.sh"
mkdir -p "${_TASKS_DIR}"
cat >"${_PROBE_SH}" <<'PROBE'
#!/usr/bin/env bash
printf '%s\n' "${PULSE_TEST_PROBE_JSON:-[]}"
PROBE
chmod +x "${_PROBE_SH}"

# Fixed "now" for the whole suite — epoch arithmetic stays exact and
# independent of wall-clock time.
_NOW=1735500000

_run() {
  ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
    PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" \
    LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" \
    bash "${_PULSE_SH}" --once "--now=${_NOW}"
}

# Sets a journal.md's mtime to exactly ($_NOW - age_seconds), independent
# of the real wall clock (portable — os.utime, no GNU/BSD touch -d/-r
# dialect split).
_set_journal_age() {
  local task_id="$1" age_s="$2"
  local dir="${_TASKS_DIR}/${task_id}"
  mkdir -p "$dir"
  local journal="${dir}/journal.md"
  [[ -f "$journal" ]] || printf -- '- event\n' >"$journal"
  python3 -c "
import os
target = $((_NOW - age_s))
os.utime('${journal}', (target, target))
"
}

describe "anti-silence-pulse.sh: empty board"

it "prints live=0 — тишина verbatim when active.yaml has no sessions"
cat >"${_ACTIVE_YAML}" <<'YAML'
meta:
  hard_limit: 5
sessions: []
YAML
out=$(_run)
assert_contains "$out" "live=0 — тишина"
assert_contains "$(tail -n 1 "${_LOG_FILE}")" "live=0 — тишина"

describe "anti-silence-pulse.sh: single lane, live / ghost negative control"

cat >"${_ACTIVE_YAML}" <<'YAML'
sessions:
- task_id: dispatch-aaaa1111
YAML

it "10min-old journal alone -> stamped ○ row, never live (SWEEPER-FALSE-LIFE)"
_set_journal_age "dispatch-aaaa1111" 600
out=$(_run)
assert_contains "$out" "live=0"
assert_contains "$out" "○ aaaa1111 — живость не доказана: отметка в журнале 10м назад, процесса и коммитов нет"
assert_not_contains "$out" "активность не видна"
assert_not_contains "$out" "тишина"

# ADDENDUM-2 collapse (founder 2026-09-08): a ghost lane gets ONE aggregate
# line, and the probe verdict is folded to three values — alive (LIVE
# «процесс» evidence, a • row — SWEEPER-FALSE-LIFE promoted it from a ghost
# footnote), not-alive (the count stands alone), no-probe (liveness rests on
# the other worker evidence). The old per-row ПРИЗРАК?(liveness-probe: …)
# renderings for starting/silent/child/null are deliberately gone: their
# only consumer was the per-row rendering.
it "real-shape dead verdict -> bare ghost count, no suffix at all"
_set_journal_age "dispatch-aaaa1111" 3660
export PULSE_TEST_PROBE_JSON='{"lanes":[{"lane":"dispatch-aaaa1111","verdict":"dead:abandoned","pid_alive":null}]}'
out=$(_run)
assert_contains "$out" "live=0"
assert_contains "$out" "призраки: 1"
assert_not_contains "$out" "probe считает живыми"
assert_not_contains "$out" "живость не проверена"

it "real-shape live verdict -> LIVE процесс evidence, a • row (SWEEPER-FALSE-LIFE)"
_set_journal_age "dispatch-aaaa1111" 3660
export PULSE_TEST_PROBE_JSON='{"lanes":[{"lane":"dispatch-aaaa1111","verdict":"live","pid_alive":true}]}'
out=$(_run)
# The old ghost-footnote clause is gone by construction: a True verdict is
# worker evidence, so the lane leaves the ghost bucket entirely.
assert_contains "$out" "live=1"
assert_contains "$out" "• aaaa1111 — в работе (0м, процесс)"
assert_not_contains "$out" "призраки"
assert_not_contains "$out" "probe считает живыми"

it "current real-probe alive verdict -> the same live • row"
export PULSE_TEST_PROBE_JSON='{"lanes":[{"lane":"dispatch-aaaa1111","verdict":"alive","pid_alive":true}]}'
out=$(_run)
assert_contains "$out" "live=1"
assert_contains "$out" "• aaaa1111 — в работе (0м, процесс)"
assert_not_contains "$out" "призраки"

it "starting verdict collapses to not-alive -- count stands alone"
export PULSE_TEST_PROBE_JSON='{"lanes":[{"lane":"dispatch-aaaa1111","verdict":"starting:7","pid_alive":null}]}'
out=$(_run)
assert_contains "$out" "призраки: 1"
assert_not_contains "$out" "probe считает живыми"
assert_not_contains "$out" "живость не проверена"

it "missing or malformed verdict collapses to not-alive, never dead-named"
export PULSE_TEST_PROBE_JSON='{"lanes":[{"lane":"another-lane","verdict":"dead:abandoned"},{"lane":"dispatch-aaaa1111"}]}'
out=$(_run)
assert_contains "$out" "призраки: 1"
assert_not_contains "$out" "probe считает живыми"

it "H2: silent:<n> verdict collapses to not-alive (no per-row rendering left to distinguish it)"
export PULSE_TEST_PROBE_JSON='{"lanes":[{"lane":"dispatch-aaaa1111","verdict":"silent:2200"}]}'
out=$(_run)
assert_contains "$out" "призраки: 1"
assert_not_contains "$out" "probe считает живыми"
assert_not_contains "$out" "живость не проверена"

it "H2: dead:silent_..._abandoned still counts as not-alive (dead: prefix agrees with ghostness)"
export PULSE_TEST_PROBE_JSON='{"lanes":[{"lane":"dispatch-aaaa1111","verdict":"dead:silent_2200s_abandoned"}]}'
out=$(_run)
assert_contains "$out" "призраки: 1"
assert_not_contains "$out" "probe считает живыми"

it "H2: child verdict collapses to not-alive"
export PULSE_TEST_PROBE_JSON='{"lanes":[{"lane":"dispatch-aaaa1111","verdict":"child","child_of":"dispatch-parent0001"}]}'
out=$(_run)
assert_contains "$out" "призраки: 1"
assert_not_contains "$out" "probe считает живыми"

it "H2: an explicit null verdict is not-alive -- the probe still ran, so never живость-не-проверена"
export PULSE_TEST_PROBE_JSON='{"lanes":[{"lane":"dispatch-aaaa1111","verdict":null}]}'
out=$(_run)
assert_contains "$out" "призраки: 1"
assert_not_contains "$out" "probe считает живыми"
assert_not_contains "$out" "живость не проверена"
export PULSE_TEST_PROBE_JSON='{"lanes":[]}'

it "31min-old journal -> ghost, excluded from live count"
_set_journal_age "dispatch-aaaa1111" 1860
out=$(_run)
assert_contains "$out" "live=0"
assert_contains "$out" "призраки: 1"
assert_not_contains "$out" "STALL"

it "touched back to fresh -> leaves the ghost bucket as a stamped ○ row (reverse direction)"
_set_journal_age "dispatch-aaaa1111" 60
out=$(_run)
assert_contains "$out" "live=0"
assert_contains "$out" "○ aaaa1111 — живость не доказана: отметка в журнале 1м назад, процесса и коммитов нет"
assert_not_contains "$out" "призраки"

describe "anti-silence-pulse.sh: ПРИЗРАК classification"

it "61min-old journal -> ghost, excluded from live count"
_set_journal_age "dispatch-aaaa1111" 3660
out=$(_run)
assert_contains "$out" "live=0"
assert_contains "$out" "призраки: 1"
assert_not_contains "$out" "STALL"

describe "anti-silence-pulse.sh: H3 heartbeat stamping"

it "--once stamps the heartbeat file with the beat's own now"
_HEARTBEAT_FILE="${_TMP}/anti-silence-pulse.heartbeat"
rm -f "${_HEARTBEAT_FILE}"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions: []
YAML
ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
  PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" \
  PULSE_HEARTBEAT_FILE="${_HEARTBEAT_FILE}" \
  LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" \
  bash "${_PULSE_SH}" --once "--now=${_NOW}" >/dev/null
assert_eq "1" "$(test -f "${_HEARTBEAT_FILE}" && echo 1 || echo 0)"
_heartbeat_line="$(cat "${_HEARTBEAT_FILE}")"
stamp="${_heartbeat_line%% *}"
interval="${_heartbeat_line#* }"
if [[ "$stamp" =~ ^[0-9]+$ ]]; then _is_epoch=true; else _is_epoch=false; fi
assert_true "$_is_epoch"
# H3 (round 5): the interval the loop was armed with rides alongside the
# stamp, so a reader in a different process never has to guess it.
assert_eq "1800" "$interval"

describe "anti-silence-pulse.sh: collection failure never crashes the pulse"

it "malformed active.yaml (sessions is a string, not a list) -> сбор не удался, exit 0"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions: "not-a-list"
YAML
out=$(_run)
assert_contains "$out" "сбор не удался"

describe "anti-silence-pulse.sh: concurrent arm"

it "a genuine concurrent arm is refused while the first owns the arm lock"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions: []
YAML
PULSE_TEST_ARM_HOLD_S=1 PULSE_LOCK_WAIT_ATTEMPTS=2 LEADV2_ANTI_SILENCE_INTERVAL_S=1 ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
  PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" \
  LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" bash "${_PULSE_SH}" >/dev/null 2>"${_TMP}/first.err" &
first_pid=$!
for _i in {1..100}; do
  [[ -s "${_PID_FILE}.lock/owner.pid" ]] && break
  sleep 0.01
done
set +e
second_out=$(PULSE_LOCK_WAIT_ATTEMPTS=2 LEADV2_ANTI_SILENCE_INTERVAL_S=1 ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
  PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" \
  LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" bash "${_PULSE_SH}" 2>"${_TMP}/second.err")
second_rc=$?
set -e
assert_eq "" "$second_out"
assert_exit_code 1 "$second_rc"
kill "$first_pid" 2>/dev/null || true
wait "$first_pid" 2>/dev/null || true
for _i in {1..100}; do
  [[ ! -e "${_PID_FILE}.lock" ]] && break
  sleep 0.01
done
assert_false "$(test -e "${_PID_FILE}.lock"; echo $?)"

it "a killed mid-arm owner leaves a stale lock which the next arm reclaims"
PULSE_TEST_ARM_HOLD_S=30 PULSE_LOCK_WAIT_ATTEMPTS=2 LEADV2_ANTI_SILENCE_INTERVAL_S=1 ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
  PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" \
  LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" bash "${_PULSE_SH}" >/dev/null 2>"${_TMP}/killed.err" &
killed_pid=$!
for _i in {1..100}; do
  [[ -s "${_PID_FILE}.lock/owner.pid" ]] && break
  sleep 0.01
done
assert_eq "$killed_pid" "$(cat "${_PID_FILE}.lock/owner.pid")"
kill -KILL "$killed_pid" 2>/dev/null || true
wait "$killed_pid" 2>/dev/null || true
PULSE_LOCK_WAIT_ATTEMPTS=2 LEADV2_ANTI_SILENCE_INTERVAL_S=1 ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
  PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" \
  LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" bash "${_PULSE_SH}" >/dev/null 2>"${_TMP}/rearm.err" &
rearm_pid=$!
for _i in {1..200}; do
  [[ -s "${_PID_FILE}" ]] && break
  sleep 0.01
done
assert_eq "$rearm_pid" "$(cat "${_PID_FILE}")"
for _i in {1..100}; do
  [[ ! -e "${_PID_FILE}.lock" ]] && break
  sleep 0.01
done
assert_false "$(test -e "${_PID_FILE}.lock"; echo $?)"
kill "$rearm_pid" 2>/dev/null || true
wait "$rearm_pid" 2>/dev/null || true

describe "anti-silence-pulse.sh: stale-owner takeover (H2, round 5)"

_HB_FILE="${_TMP}/anti-silence-pulse.heartbeat"
_POINTER_FILE="${_PID_FILE%.pid}.current"

it "wedged owner (live PID, stale heartbeat, NO birth recorded -> unverified) -> takeover WITHOUT signal: old PID left running, a NEW INSTANCE KEY arms so the zombie can't mask it (H1, round 8)"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions: []
YAML
rm -f "${_LOG_FILE}" "${_PID_FILE}.birth" "${_POINTER_FILE}"
sleep 30 &
wedged_pid=$!
printf '%s\n' "$wedged_pid" >"${_PID_FILE}"
printf '%s %s\n' "$(( $(date +%s) - 5000 ))" "1" >"${_HB_FILE}"
LEADV2_ANTI_SILENCE_INTERVAL_S=1 ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
  PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" PULSE_HEARTBEAT_FILE="${_HB_FILE}" \
  LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" bash "${_PULSE_SH}" >/dev/null 2>"${_TMP}/takeover.err" &
new_pid=$!
for _i in {1..200}; do
  [[ -s "${_POINTER_FILE}" ]] && break
  sleep 0.01
done
# C1 (round 7): identity is unverified (no birth sidecar) -- that is absence of
# evidence, not proof, so the takeover must NOT signal a pid it cannot identify.
# The old, unidentifiable process is left running untouched.
assert_true "$(kill -0 "$wedged_pid" 2>/dev/null && echo true || echo false)"
# H1 (round 8): the takeover must NOT reuse the base PID/heartbeat files the
# zombie still owns -- it mints a distinct instance key so the zombie's
# continued stamping (it is, after all, still alive and possibly still
# looping) cannot be mistaken for this new loop's own stamp.
_key="$(cat "${_POINTER_FILE}")"
assert_true "$([[ -n "$_key" ]] && echo true || echo false)"
_new_pid_file="${_PID_FILE%.pid}.${_key}.pid"
_new_hb_file="${_HB_FILE%.heartbeat}.${_key}.heartbeat"
for _i in {1..200}; do
  [[ -s "${_new_pid_file}" ]] && break
  sleep 0.01
done
assert_eq "$new_pid" "$(cat "${_new_pid_file}")"
assert_true "$(kill -0 "$new_pid" 2>/dev/null && echo true || echo false)"
# base PID_FILE is UNCHANGED -- still names the zombie, exactly as H1 requires.
assert_eq "$wedged_pid" "$(cat "${_PID_FILE}")"
for _i in {1..200}; do
  [[ -s "${_new_hb_file}" ]] && break
  sleep 0.01
done
assert_true "$(test -f "${_new_hb_file}" && echo true || echo false)"
assert_contains "$(cat "${_LOG_FILE}")" "takeover WITHOUT SIGNAL"
assert_contains "$(cat "${_LOG_FILE}")" "$wedged_pid"
assert_contains "$(cat "${_LOG_FILE}")" "new instance armed under key ${_key}"
kill "$new_pid" 2>/dev/null || true
wait "$new_pid" 2>/dev/null || true
kill "$wedged_pid" 2>/dev/null || true
wait "$wedged_pid" 2>/dev/null || true
rm -f "${_POINTER_FILE}" "${_new_pid_file}" "${_new_hb_file}" "${_new_pid_file}.birth"

it "healthy owner (live PID, fresh heartbeat) -> arm still refused, PID_FILE untouched"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions: []
YAML
rm -f "${_LOG_FILE}" "${_POINTER_FILE}"
sleep 30 &
healthy_pid=$!
printf '%s\n' "$healthy_pid" >"${_PID_FILE}"
printf '%s %s\n' "$(date +%s)" "1800" >"${_HB_FILE}"
out=$(LEADV2_ANTI_SILENCE_INTERVAL_S=1 ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
  PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" PULSE_HEARTBEAT_FILE="${_HB_FILE}" \
  LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" bash "${_PULSE_SH}")
assert_eq "" "$out"
assert_eq "$healthy_pid" "$(cat "${_PID_FILE}")"
assert_true "$(kill -0 "$healthy_pid" 2>/dev/null && echo true || echo false)"
kill "$healthy_pid" 2>/dev/null || true
wait "$healthy_pid" 2>/dev/null || true

it "rollout gap: live PID with NO heartbeat file at all is treated as stale, not healthy -- takeover fires WITHOUT signal under a new instance key (identity unverified, C1 round 7 / H1 round 8)"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions: []
YAML
rm -f "${_LOG_FILE}" "${_HB_FILE}" "${_PID_FILE}.birth" "${_POINTER_FILE}"
sleep 30 &
pre_upgrade_pid=$!
printf '%s\n' "$pre_upgrade_pid" >"${_PID_FILE}"
LEADV2_ANTI_SILENCE_INTERVAL_S=1 ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
  PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" PULSE_HEARTBEAT_FILE="${_HB_FILE}" \
  LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" bash "${_PULSE_SH}" >/dev/null 2>"${_TMP}/rollout.err" &
rollout_new_pid=$!
for _i in {1..200}; do
  [[ -s "${_POINTER_FILE}" ]] && break
  sleep 0.01
done
_key="$(cat "${_POINTER_FILE}")"
_new_pid_file="${_PID_FILE%.pid}.${_key}.pid"
for _i in {1..200}; do
  [[ -s "${_new_pid_file}" ]] && break
  sleep 0.01
done
# C1 (round 7): a pre-H1 pid file has no birth sidecar -- unverified, not
# proof of identity -- so the rollout-gap takeover no longer signals it.
assert_true "$(kill -0 "$pre_upgrade_pid" 2>/dev/null && echo true || echo false)"
assert_eq "$rollout_new_pid" "$(cat "${_new_pid_file}")"
assert_eq "$pre_upgrade_pid" "$(cat "${_PID_FILE}")"
assert_contains "$(cat "${_LOG_FILE}")" "takeover WITHOUT SIGNAL"
assert_contains "$(cat "${_LOG_FILE}")" "$pre_upgrade_pid"
kill "$rollout_new_pid" 2>/dev/null || true
wait "$rollout_new_pid" 2>/dev/null || true
kill "$pre_upgrade_pid" 2>/dev/null || true
wait "$pre_upgrade_pid" 2>/dev/null || true
rm -f "${_POINTER_FILE}" "${_new_pid_file}" "${_new_pid_file}.birth" "${_HB_FILE%.heartbeat}.${_key}.heartbeat"

describe "anti-silence-pulse.sh: takeover identity verification (H1, round 6)"

it "identity-verified takeover succeeds: recorded birth matches the live process, old PID dies, a new owner arms"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions: []
YAML
rm -f "${_LOG_FILE}" "${_PID_FILE}.birth" "${_POINTER_FILE}"
sleep 30 &
wedged_pid=$!
printf '%s\n' "$wedged_pid" >"${_PID_FILE}"
printf '%s %s\n' "$(( $(date +%s) - 5000 ))" "1" >"${_HB_FILE}"
ps -o lstart= -p "$wedged_pid" | tr -s '[:space:]' ' ' | sed -e 's/^ //' -e 's/ $//' >"${_PID_FILE}.birth"
LEADV2_ANTI_SILENCE_INTERVAL_S=1 ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
  PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" PULSE_HEARTBEAT_FILE="${_HB_FILE}" \
  LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" bash "${_PULSE_SH}" >/dev/null 2>"${_TMP}/verified.err" &
new_pid=$!
for _i in {1..200}; do
  [[ -s "${_PID_FILE}" ]] && [[ "$(cat "${_PID_FILE}")" != "$wedged_pid" ]] && break
  sleep 0.01
done
assert_false "$(kill -0 "$wedged_pid" 2>/dev/null; echo $?)"
assert_eq "$new_pid" "$(cat "${_PID_FILE}")"
assert_contains "$(cat "${_LOG_FILE}")" "identity=verified"
assert_contains "$(cat "${_LOG_FILE}")" "stale-owner takeover"
kill "$new_pid" 2>/dev/null || true
set +e
wait "$new_pid" 2>/dev/null
new_rc=$?
set -e
printf 'identity-verified new-owner exit code after SIGTERM (trap): %s (expect 143)\n' "$new_rc" >&2
assert_eq 143 "$new_rc"
wait "$wedged_pid" 2>/dev/null || true

it "identity-mismatch marker is DISCARDED and the pulse arms fresh, no signal, no brick (H2, round 8 -- supersedes round-7 exit-1 refusal)"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions: []
YAML
rm -f "${_LOG_FILE}" "${_PID_FILE}.birth" "${_POINTER_FILE}"
sleep 30 &
recycled_pid=$!
printf '%s\n' "$recycled_pid" >"${_PID_FILE}"
printf '%s %s\n' "$(( $(date +%s) - 5000 ))" "1" >"${_HB_FILE}"
# A well-formed but WRONG birth string -- a different real process's lstart,
# never the recycled pid's own -- is what a recycled pid looks like: the
# number in the pid file is alive, but it is not the process that armed it.
ps -o lstart= -p "$$" | tr -s '[:space:]' ' ' | sed -e 's/^ //' -e 's/ $//' >"${_PID_FILE}.birth"
# H2 (round 8): a mismatch is PROOF the pid was recycled -- refusing forever
# (the round-7/round-6 behaviour, exit 1) bricks the whole mechanism on a
# stale marker. The correct response is to discard the marker and arm
# fresh, same file names (there is no zombie of OURS to protect against --
# the pid at that path was never our pulse), never signalling the unrelated
# live process.
LEADV2_ANTI_SILENCE_INTERVAL_S=1 ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
  PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" PULSE_HEARTBEAT_FILE="${_HB_FILE}" \
  LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" bash "${_PULSE_SH}" >/dev/null 2>"${_TMP}/mismatch.err" &
fresh_pid=$!
for _i in {1..200}; do
  [[ -s "${_PID_FILE}" ]] && [[ "$(cat "${_PID_FILE}")" != "$recycled_pid" ]] && break
  sleep 0.01
done
assert_true "$(kill -0 "$recycled_pid" 2>/dev/null && echo true || echo false)"
assert_eq "$fresh_pid" "$(cat "${_PID_FILE}")"
assert_true "$(kill -0 "$fresh_pid" 2>/dev/null && echo true || echo false)"
assert_contains "$(cat "${_LOG_FILE}")" "stale marker DISCARDED"
assert_contains "$(cat "${_LOG_FILE}")" "identity mismatch"
kill "$fresh_pid" 2>/dev/null || true
wait "$fresh_pid" 2>/dev/null || true
kill "$recycled_pid" 2>/dev/null || true
wait "$recycled_pid" 2>/dev/null || true
rm -f "${_PID_FILE}.birth" "${_POINTER_FILE}"

describe "anti-silence-pulse.sh: cross-root journal resolution (LIVE-LANES-RUN-WITHOUT-A-JOURNAL-01)"

# CLAUDE_PROJECT_DIR is exported here so TASKS_DIR is a genuine subpath of
# PROJECT_ROOT (_TASKS_DIR_REL resolves to "tasks"). Every OTHER test in
# this file leaves CLAUDE_PROJECT_DIR unset, so PROJECT_ROOT is empty and
# the foreign-root fallback never activates for them -- confirmed by the
# full suite staying green with this fix in place before these cases were
# added (no regression).
_run_cross_root() {
  CLAUDE_PROJECT_DIR="${_TMP}" \
    ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
    PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" \
    LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" \
    bash "${_PULSE_SH}" --once "--now=${_NOW}"
}

it "(void control) worktree/log_path present but no journal planted anywhere -- lane renders NOTHING"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions:
- task_id: found-void
  worktree: /tmp/leadv2-cross-root-void-does-not-exist
  log_path: docs/handoff/dispatch-void0000/developer.stream.jsonl
YAML
rm -rf "${_TASKS_DIR}/found-void" "${_TASKS_DIR}/dispatch-void0000"
out=$(_run_cross_root)
# ADDENDUM 2: a lane with no evidence anywhere does not get a row at all.
# Invisibility IS the control here: had any tier found a journal, the lane
# would render as a live bullet.
assert_not_contains "$out" "found-void"
assert_contains "$out" "live=0 — тишина"

it "same-root dispatch-key journal (nothing under the founder task_id) resolves via log_path's dispatch key"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions:
- task_id: found-name-b
  worktree: /tmp/leadv2-cross-root-b-not-used
  log_path: docs/handoff/dispatch-cccc3333/developer.stream.jsonl
YAML
rm -rf "${_TASKS_DIR}/found-name-b"
_set_journal_age "dispatch-cccc3333" 300
out=$(_run_cross_root)
assert_not_contains "$out" "нет журнала"
assert_contains "$out" "○ found-name-b — живость не доказана: отметка в журнале 5м назад, процесса и коммитов нет"

it "foreign-worktree-root journal under the founder task_id resolves via sess.worktree"
_FOREIGN="${_TMP}/foreign-worktree"
mkdir -p "${_FOREIGN}/tasks/found-name-c"
cat >"${_ACTIVE_YAML}" <<YAML
sessions:
- task_id: found-name-c
  worktree: ${_FOREIGN}
  log_path: docs/handoff/dispatch-eeee5555/developer.stream.jsonl
YAML
rm -rf "${_TASKS_DIR}/found-name-c"
printf -- '- event\n' >"${_FOREIGN}/tasks/found-name-c/journal.md"
python3 -c "
import os
target = ${_NOW} - 300
os.utime('${_FOREIGN}/tasks/found-name-c/journal.md', (target, target))
"
out=$(_run_cross_root)
assert_not_contains "$out" "нет журнала"
assert_contains "$out" "○ found-name-c — живость не доказана: отметка в журнале 5м назад, процесса и коммитов нет"

it "foreign-worktree-root AND dispatch-key both mismatched (the real observed defect shape) still resolves"
_FOREIGN2="${_TMP}/foreign-worktree-2"
mkdir -p "${_FOREIGN2}/tasks/dispatch-dddd4444"
cat >"${_ACTIVE_YAML}" <<YAML
sessions:
- task_id: found-name-d
  worktree: ${_FOREIGN2}
  log_path: docs/handoff/dispatch-dddd4444/developer.stream.jsonl
YAML
rm -rf "${_TASKS_DIR}/found-name-d" "${_TASKS_DIR}/dispatch-dddd4444"
printf -- '- event\n' >"${_FOREIGN2}/tasks/dispatch-dddd4444/journal.md"
python3 -c "
import os
target = ${_NOW} - 300
os.utime('${_FOREIGN2}/tasks/dispatch-dddd4444/journal.md', (target, target))
"
out=$(_run_cross_root)
assert_not_contains "$out" "нет журнала"
assert_contains "$out" "○ found-name-d — живость не доказана: отметка в журнале 5м назад, процесса и коммитов нет"

describe "anti-silence-pulse.sh: journal-tier negative controls (RED-then-GREEN)"

# Runs one beat of the pulse script at <path> against the CURRENT
# _ACTIVE_YAML fixture. rc 0 = the task's journal resolved fresh (rendered
# as its ADDENDUM-2 bullet); rc 1 = anything else (no evidence, crash,
# empty). CLAUDE_PROJECT_DIR is set so the foreign-root tiers activate
# whenever the fixture names a worktree -- same shape as _run_cross_root
# above.
# <ja-lib-path> is optional: real module when omitted, a mutant copy under
# test otherwise, wired in via LEADV2_JOURNAL_ADDRESS_LIB -- the pulse
# script itself (`$sh`) is NEVER mutated any more, only the module it imports.
_journal_probe() { # <pulse-sh> <task-id> [ja-lib-path]
  local sh="$1" tid="$2" ja_lib="${3:-${_JA_LIB}}" out
  out="$(CLAUDE_PROJECT_DIR="${_TMP}" ACTIVE_YAML="${_ACTIVE_YAML}" TASKS_DIR="${_TASKS_DIR}" \
    PULSE_LOG_FILE="${_LOG_FILE}" PULSE_PID_FILE="${_PID_FILE}" \
    PULSE_HEARTBEAT_FILE="${_TMP}/negctl-probe.heartbeat" \
    LEADV2_LANE_LIVENESS_SCRIPT="${_PROBE_SH}" \
    LEADV2_JOURNAL_ADDRESS_LIB="${ja_lib}" \
    bash "$sh" --once "--now=${_NOW}")"
  # SWEEPER-FALSE-LIFE: a journal-only lane renders as a stamped ○ row
  # (uncounted, named) — resolution still proves itself by that row.
  [[ "$out" == *"○ ${tid} — живость не доказана: отметка в журнале 5м назад"* ]]
}

# Applies the tier's mutation (see the declared negative control in the
# header) to a copy of the REAL journal-address module, then requires:
# mutant module fails to resolve (pre_rc=1), clean module still resolves
# (post_rc=0), against the SAME unmodified pulse script both times. A
# vacuous mutation (anchor line absent -> copy identical) fails the suite
# instead of passing silently.
_negctl_tier() { # <sed-expr> <task-id> <label>
  local expr="$1" tid="$2" label="$3"
  local mutant="${_TMP}/negctl-${label}.py" pre_rc post_rc
  sed -e "${expr}" "${_JA_LIB}" >"${mutant}"
  if cmp -s "${_JA_LIB}" "${mutant}"; then
    _test_fail "negative control ${label}: mutation is a no-op (anchor not found inside journal_candidates())"
    return 0
  fi
  set +e
  _journal_probe "${_PULSE_SH}" "${tid}" "${mutant}"
  pre_rc=$?
  _journal_probe "${_PULSE_SH}" "${tid}"
  post_rc=$?
  set -e
  assert_eq 1 "${pre_rc}"
  assert_eq 0 "${post_rc}"
  echo "RED-then-GREEN: journal-address ${label} (pre_rc=${pre_rc} -> post_rc=${post_rc})"
}

# Same shape as _negctl_tier but takes N sed -e expressions (array) instead
# of one. Needed once a second safety net exists (the recent-glob fallback,
# B0-READER-HALF-01) alongside the exact-candidate tiers: killing ONLY a
# tier's _add() call no longer proves that tier matters, because the
# fallback can resolve the same fixture through the foreign worktree glob.
# Isolating a tier's necessity now requires killing the fallback too.
_negctl_tier_multi() { # <label> <task-id> <sed-expr>...
  local label="$1" tid="$2"
  shift 2
  local mutant="${_TMP}/negctl-${label}.py" pre_rc post_rc
  local sed_args=()
  local e
  for e in "$@"; do sed_args+=(-e "$e"); done
  sed "${sed_args[@]}" "${_JA_LIB}" >"${mutant}"
  if cmp -s "${_JA_LIB}" "${mutant}"; then
    _test_fail "negative control ${label}: mutation is a no-op (anchor(s) not found)"
    return 0
  fi
  set +e
  _journal_probe "${_PULSE_SH}" "${tid}" "${mutant}"
  pre_rc=$?
  _journal_probe "${_PULSE_SH}" "${tid}"
  post_rc=$?
  set -e
  assert_eq 1 "${pre_rc}"
  assert_eq 0 "${post_rc}"
  echo "RED-then-GREEN: journal-address ${label} (pre_rc=${pre_rc} -> post_rc=${post_rc})"
}

# Kills ONLY recent_glob_fallback (returns [] immediately after computing
# foreign_tasks_dir), leaving every exact-candidate tier untouched. Single
# line, portable sed (no BSD/GNU 'a' divergence): a trailing `; return []`
# on the foreign_tasks_dir assignment is valid Python and unique to this
# function -- journal_candidates never assigns that name.
_KILL_FALLBACK_EXPR='s/^    foreign_tasks_dir = os\.path\.join(foreign_root, rel)$/    foreign_tasks_dir = os.path.join(foreign_root, rel); return []/'

it "tier 1 (own root + founder key): deleting the tier-1 _add() call inside _journal_candidates() breaks resolution"
rm -rf "${_TASKS_DIR}/negctl-t1"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions:
- task_id: negctl-t1
YAML
_set_journal_age "negctl-t1" 300
_negctl_tier '/^    _add(os\.path\.join(tasks_dir, task_id, "journal\.md"))$/d' \
  "negctl-t1" "tier1-own-root-founder-key"
rm -rf "${_TASKS_DIR}/negctl-t1"

it "tier 2 (own root + dispatch key): _add() replaced by pass inside _journal_candidates() breaks resolution"
rm -rf "${_TASKS_DIR}/negctl-t2" "${_TASKS_DIR}/dispatch-ab0de12"
cat >"${_ACTIVE_YAML}" <<'YAML'
sessions:
- task_id: negctl-t2
  worktree: /tmp/leadv2-negctl-absent-worktree
  log_path: docs/handoff/dispatch-ab0de12/developer.stream.jsonl
YAML
_set_journal_age "dispatch-ab0de12" 300
_negctl_tier 's/^        _add(os\.path\.join(tasks_dir, dispatch_key, "journal\.md"))$/        pass/' \
  "negctl-t2" "tier2-own-root-dispatch-key"
rm -rf "${_TASKS_DIR}/negctl-t2" "${_TASKS_DIR}/dispatch-ab0de12"

it "tier 3 (foreign root + founder key): deleting the tier-3 _add() call inside _journal_candidates() breaks resolution"
_FOREIGN3="${_TMP}/negctl-foreign-worktree"
rm -rf "${_FOREIGN3}" "${_TASKS_DIR}/negctl-t3"
mkdir -p "${_FOREIGN3}/tasks/negctl-t3"
cat >"${_ACTIVE_YAML}" <<YAML
sessions:
- task_id: negctl-t3
  worktree: ${_FOREIGN3}
  log_path: docs/handoff/not-a-dispatch-key/developer.stream.jsonl
YAML
printf -- '- event\n' >"${_FOREIGN3}/tasks/negctl-t3/journal.md"
python3 -c "
import os
target = ${_NOW} - 300
os.utime('${_FOREIGN3}/tasks/negctl-t3/journal.md', (target, target))
"
_negctl_tier_multi "tier3-foreign-root-founder-key" "negctl-t3" \
  '/^            _add(os\.path\.join(foreign_root, tasks_dir_rel, task_id, "journal\.md"))$/d' \
  "${_KILL_FALLBACK_EXPR}"
rm -rf "${_FOREIGN3}" "${_TASKS_DIR}/negctl-t3"

it "tier 4 (foreign root + dispatch key): _add() replaced by pass inside _journal_candidates() breaks resolution"
_FOREIGN4="${_TMP}/negctl-foreign-worktree-4"
rm -rf "${_FOREIGN4}" "${_TASKS_DIR}/negctl-t4" "${_TASKS_DIR}/dispatch-c0ffee12"
mkdir -p "${_FOREIGN4}/tasks/dispatch-c0ffee12"
cat >"${_ACTIVE_YAML}" <<YAML
sessions:
- task_id: negctl-t4
  worktree: ${_FOREIGN4}
  log_path: docs/handoff/dispatch-c0ffee12/developer.stream.jsonl
YAML
printf -- '- event\n' >"${_FOREIGN4}/tasks/dispatch-c0ffee12/journal.md"
python3 -c "
import os
target = ${_NOW} - 300
os.utime('${_FOREIGN4}/tasks/dispatch-c0ffee12/journal.md', (target, target))
"
_negctl_tier_multi "tier4-foreign-root-dispatch-key" "negctl-t4" \
  's/^                _add(os\.path\.join(foreign_root, tasks_dir_rel, dispatch_key, "journal\.md"))$/                pass/' \
  "${_KILL_FALLBACK_EXPR}"
rm -rf "${_FOREIGN4}" "${_TASKS_DIR}/negctl-t4" "${_TASKS_DIR}/dispatch-c0ffee12"

it "tier 5 (recent-glob fallback): journal under neither the founder key nor the log_path dispatch key still resolves (the DOD-GATE-CHARGES-LANES-FOR-HARNESS-WRITES-01 shape -- a lane's active sub-dispatch id changed after active.yaml's log_path was last written)"
_FOREIGN5="${_TMP}/negctl-foreign-worktree-5"
rm -rf "${_FOREIGN5}" "${_TASKS_DIR}/negctl-t5"
mkdir -p "${_FOREIGN5}/tasks/dispatch-unrelated99"
cat >"${_ACTIVE_YAML}" <<YAML
sessions:
- task_id: negctl-t5
  worktree: ${_FOREIGN5}
  log_path: docs/handoff/not-a-dispatch-key/developer.stream.jsonl
YAML
printf -- '- event\n' >"${_FOREIGN5}/tasks/dispatch-unrelated99/journal.md"
python3 -c "
import os
target = ${_NOW} - 300
os.utime('${_FOREIGN5}/tasks/dispatch-unrelated99/journal.md', (target, target))
"
_negctl_tier "${_KILL_FALLBACK_EXPR}" "negctl-t5" "tier5-recent-glob-fallback"
rm -rf "${_FOREIGN5}" "${_TASKS_DIR}/negctl-t5"

pe_test_summary
