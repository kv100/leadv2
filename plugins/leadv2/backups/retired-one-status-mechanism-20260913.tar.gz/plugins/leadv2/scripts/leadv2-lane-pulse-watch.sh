#!/usr/bin/env bash
# scripts/leadv2-lane-pulse-watch.sh — MON-PULSE-01 part 1: dispatcher-owned lane watch.
#
# Started DETACHED (nohup, never a Claude Monitor) by leadv2-dispatch-code.sh at
# worker_spawned. Founder order 2026-08-28 (3rd occurrence of
# PULSE-IN-SINGLE-LEAD-01): lane tracking must work IN THE PLUGIN — a Monitor
# armed ad hoc by the lead with `tail -n 0` missed a dispatch_terminal written
# 25s post-spawn and the founder saw nothing until he asked.
#
# Replay-safe: the line offset starts at 0, so the FIRST pass reads the journal
# from line 1 (tail -n +1) — terminal lines written between spawn and watcher
# start are still reported. Exit-triggering states are ONLY
#   dispatch_terminal | dispatch_refused
# and only for THIS watcher's own task sig (a foreign sig's line never pulses).
# Worker death is NOT a separate journal token: grep of the emitters (fix-round
# M3) shows the only worker_died string ever journaled is the cause= value of a
# dispatch_terminal row (dispatch-ledger.sh:1009 writes
# `dispatch_terminal task=X terminal=dead cause=worker_died`); a bare
# `worker_died` event is emitted nowhere. Such rows pulse under kind
# `worker_died` so the founder sees a death, not a landing.
# review_gate is a BEAT, never a terminal (fix-round C1): leadv2-review-run.sh
# emits it repeatedly mid-flight (status=ran, round0_skip, dedup,
# arm_infra_died action=retry), so it is pulsed but the watch keeps running
# until a true terminal. A per-sig seen ledger (fix-round H2) survives watcher
# exit, so a re-arm never re-pulses lines a previous watcher already pulsed.
# Each matched line appends exactly one pulse line via the EXISTING
# leadv2-pulse.sh (task_id, phase, <=80 bytes — reused, not reimplemented;
# LEADV2_PULSE_MODE=0 is honored inside leadv2-pulse.sh itself).
#
# Exits after the first pass that matched a terminal line, or after --timeout.
# The DEFAULT timeout is DERIVED from the dispatcher's own worker-timeout envs
# (GLM/FREEPOOL/KIMI/CODEX_TIMEOUT — the values the coder launchers
# themselves honor): 4x the largest + 300s grace, never a constant (fix-round
# H1). The lane outlives its worker — spawn->dispatch_terminal spans review
# rounds, e2e and merge, and the old 3900s constant silently abandoned 12/107
# (11%) of this repo's own historical lanes, observed max 13415s (~3.7x the
# 3600s worker backstop); 4*3600+300=14700 outlives the real distribution. On
# timeout the watcher writes a FINAL `watch_timeout` pulse instead of dying
# silently (H1), so the founder sees the abandonment instead of a void.
# Never two watchers per lane: pidfile guard keyed by sig.
#
# Usage:
#   leadv2-lane-pulse-watch.sh --sig <sig8> [--root DIR] [--journal FILE]
#     [--interval S=15] [--timeout S=<derived>] [--state-dir DIR]
#   leadv2-lane-pulse-watch.sh --print-timeout   # print the derived cap, exit
#
# Hermetic seams (tests): --root/--journal/--state-dir args,
# LEADV2_LANE_PULSE_BIN (pulse writer), LEADV2_PROJECT_ROOT (root fallback),
# --print-timeout (locks the derivation itself). Lifecycle seams
# (WATCHER-LIFECYCLE-LEAK-01): LEADV2_WATCH_LIFECYCLE_LOG (event log path),
# LEADV2_WATCHER_OWNER_PID (optional explicit owner — unset in production,
# see the loop body).
# Read-only w.r.t. the journal; writes only its pidfile + the pulse file.

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# BEAT-LOOP-ORPHANS-01: a headless worker session (glm-coder/freepool-coder/
# kimi-coder/claude-subsession) inherits this process's env exactly like a
# lead does when it dispatches its own nested worker, and its plugin hooks
# fire the same arming path -- but a worker session outlives nothing; when it
# exits this watch has no owner left to disarm it. Fix-round 2: `worker`
# refuses to arm and `unknown` FAILS CLOSED too (no env pin + no worker signal
# in the transcript = no arm; journal one session_kind=unknown line). Only
# `lead` arms.
_lv2_lpw_journal="${LEADV2_PROJECT_ROOT:-$PWD}/docs/leadv2/loop-arm-journal.log"
mkdir -p "$(dirname "$_lv2_lpw_journal")" 2>/dev/null || true
_LV2_HOOK_KIND_LIB="${LEADV2_SESSION_KIND_LIB:-${SCRIPT_DIR}/../hooks/lib/leadv2-hook-session-kind.sh}"
if [[ -f "$_LV2_HOOK_KIND_LIB" ]]; then
  # shellcheck source=/dev/null
  source "$_LV2_HOOK_KIND_LIB"
  # Direct call (no $()): keeps LEADV2_SESSION_KIND_OUT/_REASON in THIS shell
  leadv2_hook_session_kind "${LEADV2_LOOP_OWNER_TRANSCRIPT:-}" >/dev/null 2>&1 || true
  _lv2_loop_kind="${LEADV2_SESSION_KIND_OUT:-unknown}"
  # SESSION-KIND-UNKNOWN-REFUSES-CLOSED-01 stage 1: the classifier can now answer
  # `lead`, but arming four background loops on the live path after months of
  # silence is a separate change with its own observation. Hold until then.
  # STAGE 2 (SD-LOOPS-ARM-ON-LEAD-STAGE2-01): this is the ONE loop released.
  # Its own switch defaults to 1; every other loop stays at 0 so their traces
  # never interleave. Rollback is a single flag: LEADV2_ARM_LANE_PULSE_WATCH=0,
  # and the lead signal keeps answering regardless.
  if [[ "$_lv2_loop_kind" != "lead" ]] \
     || { [[ "${LEADV2_LOOPS_ARM_ON_LEAD:-0}" != "1" ]] \
          && [[ "${LEADV2_ARM_LANE_PULSE_WATCH:-1}" != "1" ]]; }; then
    _lv2_lpw_outcome=refused
    [[ "$_lv2_loop_kind" == "lead" ]] && _lv2_lpw_outcome=refused_stage1_hold
    leadv2_loop_arm_journal "$_lv2_lpw_journal" "lane-pulse-watch" "$_lv2_loop_kind" "$_lv2_lpw_outcome" 2>/dev/null || true
    exit 0
  fi
else
  printf '%s event=owner_check_unavailable loop=lane-pulse-watch reason=classifier_lib_missing\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo '?')" >> "$_lv2_lpw_journal" 2>/dev/null || true
fi

# WATCHER-LIFECYCLE-LEAK-01: shared watcher lifecycle (race-safe singleton
# claim, self-reap, event log). Guarded + canonical-fallback source, same
# shape dispatch-ledger uses for its libs; the stubs reproduce the PRE-fix
# behavior so a missing lib can never stop the watch.
_WL_LIB="${SCRIPT_DIR}/lib/leadv2-watch-lifecycle.sh"
[[ -f "${_WL_LIB}" ]] || _WL_LIB="${LEADV2_CANONICAL_ROOT:-${HOME}/Projects/leadv2}/plugins/leadv2/scripts/lib/leadv2-watch-lifecycle.sh"
if [[ -f "${_WL_LIB}" ]]; then
  # shellcheck source=lib/leadv2-watch-lifecycle.sh
  source "${_WL_LIB}"
else
  wl_event() { :; }
  wl_owner_gone() { return 1; }
  wl_singleton_claim() {  # pre-leak-fix fallback: kill -0 guard + blind write
    local _p
    if [[ -f "$1" ]]; then
      _p="$(cat "$1" 2>/dev/null | tr -d ' ')"
      [[ "${_p}" =~ ^[0-9]+$ ]] && kill -0 "${_p}" 2>/dev/null && return 3
    fi
    mkdir -p "$(dirname "$1")" 2>/dev/null || true
    printf '%s\n' "$$" > "${1}.tmp.$$" 2>/dev/null \
      && mv -f "${1}.tmp.$$" "$1" 2>/dev/null || true
    return 0
  }
fi

SIG=""
ROOT=""
JOURNAL=""
INTERVAL="${LEADV2_LANE_PULSE_WATCH_INTERVAL:-15}"
TIMEOUT="${LEADV2_LANE_PULSE_WATCH_TIMEOUT:-}"
STATE_DIR=""
PRINT_TIMEOUT=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --sig)          SIG="${2:-}"; shift 2 ;;
    --root)         ROOT="${2:-}"; shift 2 ;;
    --journal)      JOURNAL="${2:-}"; shift 2 ;;
    --interval)     INTERVAL="${2:-}"; shift 2 ;;
    --timeout)      TIMEOUT="${2:-}"; shift 2 ;;
    --state-dir)    STATE_DIR="${2:-}"; shift 2 ;;
    --print-timeout) PRINT_TIMEOUT=1; shift ;;
    -h|--help)
      sed -n '2,30p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1}//'
      exit 0 ;;
    *) printf '[lane-pulse-watch] unknown arg: %s\n' "$1" >&2; exit 1 ;;
  esac
done
[[ -n "$SIG" || "$PRINT_TIMEOUT" == "1" ]] || { printf '[lane-pulse-watch] --sig required\n' >&2; exit 1; }
[[ "$INTERVAL" =~ ^[0-9]+$ ]] || { printf '[lane-pulse-watch] bad --interval: %s\n' "$INTERVAL" >&2; exit 1; }

# H1: derive the default cap from the dispatcher's own worker-timeout envs,
# never a constant. The lane's journal keeps moving (review rounds, e2e,
# merge) long after the worker process exits, so the worker backstop alone
# under-watches: 12/107 (11%) historical lanes ran spawn->terminal past the
# old 3900s constant, max 13415s. 4x the largest honored backstop + 300s
# grace covers that distribution with margin (4*3600+300=14700).
_derive_timeout() {
  local v best=3600
  for v in "${GLM_TIMEOUT:-}" "${FREEPOOL_TIMEOUT:-}" "${KIMI_TIMEOUT:-}" "${CODEX_TIMEOUT:-}"; do
    [[ "$v" =~ ^[0-9]+$ ]] && (( v > best )) && best="$v"
  done
  printf '%s' "$(( best * 4 + 300 ))"
}
if [[ -z "$TIMEOUT" ]]; then
  TIMEOUT="$(_derive_timeout)"
fi
[[ "$TIMEOUT"  =~ ^[0-9]+$ ]] || { printf '[lane-pulse-watch] bad --timeout: %s\n'  "$TIMEOUT"  >&2; exit 1; }
if [[ "$PRINT_TIMEOUT" == "1" ]]; then
  printf '%s\n' "$TIMEOUT"
  exit 0
fi

# ── root + journal path (same resolution order leadv2-journal.sh uses) ──────
if [[ -z "$ROOT" ]]; then
  ROOT="${LEADV2_PROJECT_ROOT:-$(git -C "$PWD" rev-parse --show-toplevel 2>/dev/null || true)}"
fi
[[ -n "$ROOT" ]] || { printf '[lane-pulse-watch] no project root\n' >&2; exit 1; }
if [[ -z "$JOURNAL" ]]; then
  _lv2_dir="$(grep -E "^[[:space:]]*leadv2_dir[[:space:]]*:" "${ROOT}/.claude/leadv2-overrides/state-paths.yaml" 2>/dev/null \
    | head -1 | sed -E "s/^[[:space:]]*leadv2_dir[[:space:]]*:[[:space:]]*//" | sed -E "s/^['\"]//; s/['\"][[:space:]]*$//" | tr -d '\r' || true)"
  [[ -z "${_lv2_dir}" || "${_lv2_dir}" == "null" || "${_lv2_dir}" == "~" ]] && _lv2_dir="docs/leadv2"
  JOURNAL="${ROOT}/${_lv2_dir}/tasks/dispatch-${SIG}/journal.md"
fi
TASK_ID="dispatch-${SIG}"
[[ -n "${_lv2_dir:-}" ]] || _lv2_dir="docs/leadv2"
TASKS_DIR_FOR_LANE="${ROOT}/${_lv2_dir}/tasks"

# ── LANE-PULSE-WATCH-SIG-KEY-STALE-ON-PHASE-CHANGE-01 ───────────────────────
# --sig fixes JOURNAL once, at spawn. A multi-phase lane mints a NEW dispatch
# sig per phase (plan -> build -> review -> ...), so this journal can stop
# growing forever while the lane is still very much alive under a different
# dispatch dir -- the watcher then sits until the derived TIMEOUT (up to
# ~4h) doing nothing useful, while nobody watches the phase actually running.
# Option B (chosen over re-resolving every poll): re-resolve ONLY when this
# journal has gone quiet for STALE_MAX seconds, via the canonical resolver
# (lib/leadv2-journal-address.py, MONITORS-ARE-THE-SECOND-CONSUMER-OF-THE-
# ADDRESS-RESOLVER-01) keyed on the founder task_id read from THIS sig's own
# admission-receipt.yaml (EXACT-ATTRIBUTION: a named field, never a glob or a
# grep of file bodies). Cost was the deciding factor: a python3 child every
# --interval (default 15s) per watched lane is not free on a machine already
# running dispatch-code.sh's own stale-sweeper/worktree-cleanup/lane-liveness
# chain at 16/26/12 concurrent processes (measured 2026-09-06) -- re-checking
# only once per STALE_MAX keeps the added cost proportional to actual staleness
# instead of to wall-clock time.
STALE_MAX="${LEADV2_LANE_PULSE_WATCH_STALE_MAX_S:-900}"
[[ "$STALE_MAX" =~ ^[0-9]+$ ]] || STALE_MAX=900
JOURNAL_ADDRESS_LIB="${SCRIPT_DIR}/lib/leadv2-journal-address.py"
[[ -f "$JOURNAL_ADDRESS_LIB" ]] || JOURNAL_ADDRESS_LIB="${LEADV2_CANONICAL_ROOT:-${HOME}/Projects/leadv2}/plugins/leadv2/scripts/lib/leadv2-journal-address.py"
FOUNDER_TASK_ID=""
_receipt="${ROOT}/docs/handoff/dispatch-${SIG}/admission-receipt.yaml"
[[ -f "$_receipt" ]] && FOUNDER_TASK_ID="$(sed -n 's/^task_id:[[:space:]]*//p' "$_receipt" | head -1 | tr -d '"' | tr -d '\r')"

# MATCH_TOKEN gates which journal lines belong to THIS lane (grep task=...
# below) -- initially the dispatch sig, but a re-resolved journal's own
# lines are tagged with whatever key its directory is named after (a
# founder task_id dir, not necessarily dispatch-<SIG> any more), so it must
# move together with JOURNAL or every line in the new file is filtered out
# as "foreign" and the switch is a no-op in practice.
MATCH_TOKEN="$SIG"

# Attempts one re-resolve via the founder task_id; on a genuinely NEW journal
# path (not this one), switches JOURNAL, MATCH_TOKEN and resets SEEN
# (replay-safe: this watcher has never read that file). No-op (returns 1) if
# there is no founder_task_id to key on, the lib is missing, or resolution
# finds nothing new -- the watcher keeps polling the original path either way.
_try_reresolve_stale_journal() {
  [[ -n "$FOUNDER_TASK_ID" && -f "$JOURNAL_ADDRESS_LIB" ]] || return 1
  local _new _new_dirname
  _new="$(python3 "$JOURNAL_ADDRESS_LIB" resolve --root "$ROOT" --tasks-dir "$TASKS_DIR_FOR_LANE" \
    --task-id "$FOUNDER_TASK_ID" --now "$(date +%s)" 2>/dev/null || true)"
  [[ -n "$_new" && "$_new" != "$JOURNAL" ]] || return 1
  _new_dirname="$(basename "$(dirname "$_new")")"
  printf '[lane-pulse-watch] %s journal stale >%ss, re-resolved via founder task_id %s: %s -> %s (match token %s -> %s)\n' \
    "$SIG" "$STALE_MAX" "$FOUNDER_TASK_ID" "$JOURNAL" "$_new" "$MATCH_TOKEN" "${_new_dirname#dispatch-}" >&2
  JOURNAL="$_new"
  MATCH_TOKEN="${_new_dirname#dispatch-}"
  SEEN=0
  _ledger_save 0
  return 0
}

# ── FORK-STORM-KILLS-HOOKS-01: orphan self-termination ──────────────────────
# Decision (recorded in report.md): the watcher CANNOT be owned by something
# that dies with the dispatch — it is nohup'd+disowned from a command-
# substitution subshell precisely so the launcher never hangs on it — so it
# must self-terminate when its lane's worker is gone. Observable proxy: the
# active.yaml row that pins MY pid with role=watcher stops advancing
# updated_at (a genuinely running lane bumps its row on every phase
# transition; a lane whose dispatch died leaves it frozen). A watcher-only
# row frozen for ORPHAN_MAX seconds means no worker exists — exit with a
# watcher_orphan pulse instead of lingering to the full TIMEOUT. 0 disables.
ORPHAN_MAX="${LEADV2_LANE_PULSE_WATCH_ORPHAN_MAX_S:-1800}"
[[ "$ORPHAN_MAX" =~ ^[0-9]+$ ]] || ORPHAN_MAX=1800
ACTIVE_YAML="$(PROJECT_ROOT="$ROOT" bash "${SCRIPT_DIR}/leadv2-state-path.sh" active.yaml 2>/dev/null || true)"
[[ -n "$ACTIVE_YAML" ]] || ACTIVE_YAML="${ROOT}/docs/leadv2/active.yaml"
# <self-pid> <active.yaml> <max-age-s> -> prints "orphan" iff a row pins this
# pid as a watcher AND its updated_at is older than max-age. Fail-open: any
# parse error, missing PyYAML, or missing row prints nothing (keep watching).
_orphan_check() {
  python3 - "$1" "$2" "$3" <<'PY' 2>/dev/null || true
import sys, time, datetime
try:
    import yaml
except ImportError:
    sys.exit(0)
self_pid, path, max_s = int(sys.argv[1]), sys.argv[2], int(sys.argv[3])
try:
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
except Exception:
    sys.exit(0)
for s in (data.get("sessions") or []):
    try:
        if int(s.get("worker_pid") or 0) != self_pid:
            continue
    except (TypeError, ValueError):
        continue
    if s.get("worker_pid_role") != "watcher" and s.get("pid_role") != "watcher":
        continue
    ts = str(s.get("updated_at") or "")
    try:
        t = datetime.datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S")
        age = time.time() - t.replace(tzinfo=datetime.timezone.utc).timestamp()
    except ValueError:
        sys.exit(0)
    if age >= max_s:
        print("orphan")
    sys.exit(0)
PY
}

# ── pidfile guard: never two watchers per lane (keyed by sig) ───────────────
if [[ -z "$STATE_DIR" ]]; then
  STATE_DIR="$(PROJECT_ROOT="$ROOT" bash "${SCRIPT_DIR}/leadv2-state-path.sh" --no-link lane-pulse-watch 2>/dev/null || true)"
fi
[[ -n "$STATE_DIR" ]] || STATE_DIR="${TMPDIR:-/tmp}/leadv2-lane-pulse-watch"
PID_DIR="${STATE_DIR}/lane-pulse-watch"
mkdir -p "$PID_DIR" 2>/dev/null || true
PID_FILE="${PID_DIR}/${SIG}.pid"
SEEN_FILE="${PID_DIR}/${SIG}.seen"   # fix-round H2: pulsed-line ledger, survives exit
# WATCHER-LIFECYCLE-LEAK-01: the old guard was check-then-write with no
# cmdline validation — racing arms both passed it, and the pidfile loser
# watched on invisibly to its full derived timeout. wl_singleton_claim makes
# check+write atomic (mkdir lockdir), refuses only a LIVE process whose
# command line still contains this script's basename, replaces a dead or
# recycled-foreign pidfile, and fails OPEN on an unwritable dir (spawn —
# the pre-fix behavior, mission fail-open constraint).
WL_LOG_FILE="${LEADV2_WATCH_LIFECYCLE_LOG:-${PID_DIR}/watch-lifecycle.log}"
LEADV2_WATCH_LIFECYCLE_LOG="$WL_LOG_FILE"
# WATCHER-LIFECYCLE-LEAK-01: traps are armed BEFORE the claim — a TERM
# landing inside the claim's settle window used to hit the default death
# action and leak the pidfile. Cleanup removes the pidfile ONLY when it
# still names THIS pid, so it is safe at any point of the claim: a
# dedup-refused copy (pidfile names the winner) can never delete the
# winner's claim, and a TERM between our noclobber-create and the loop
# proper still cleans up.
_cleanup_pid() {
  local _p
  _p="$(cat "$PID_FILE" 2>/dev/null | tr -d '[:space:]')"
  if [[ "$_p" == "$$" ]]; then
    rm -f "$PID_FILE" "${PID_FILE}.owner" 2>/dev/null || true
    wl_event "lane-pulse-watch" "$TASK_ID" "$$" "self_reap"
  fi
  return 0
}
# A trapped TERM/INT runs the handler and then RESUMES the script — the
# watcher survived its own kill with the pidfile already removed, so every
# later arm spawned a fresh duplicate. The signal handler must EXIT; the
# EXIT trap is disarmed first so self_reap logs exactly once.
# Fix-r1: on macOS bash 3.2 a trapped TERM also DEFERS behind a foreground
# child for that child's full runtime (measured on a 30s sleep: handler at
# 29.5s; the wait-builtin form fires in 0.015s) — the interval sleep below
# is therefore a background child under wait, and the handler kills it.
WL_CHILD=""
_on_term() {
  trap - EXIT
  [[ -n "$WL_CHILD" ]] && kill "$WL_CHILD" 2>/dev/null || true
  _cleanup_pid
  exit 0
}
trap _cleanup_pid EXIT
trap _on_term INT TERM
wl_singleton_claim "$PID_FILE"
case $? in
  3)
    printf '[lane-pulse-watch] %s already watched by pid %s, no-op\n' "$SIG" "$(cat "$PID_FILE" 2>/dev/null | tr -d ' ')" >&2
    wl_event "lane-pulse-watch" "$TASK_ID" "$$" "dedup_refused"
    exit 0
    ;;
esac
wl_event "lane-pulse-watch" "$TASK_ID" "$$" "spawn"

# BEAT-LOOP-ORPHANS-01 mechanism 2: record the arming session's liveness
# tokens once (owner pid + transcript), then exit when the owner is gone —
# a watcher whose lane outlives its dispatcher must not outlive its OWNER.
# Env inputs from the armer (LEADV2_LOOP_OWNER_PID/_SID/_TRANSCRIPT) win;
# fallback is the nearest claude-harness ancestor of this process.
OWNER_FILE="${PID_FILE}.owner"
if command -v leadv2_loop_owner_record >/dev/null 2>&1; then
  leadv2_loop_owner_record "$OWNER_FILE" "${LEADV2_LOOP_OWNER_TRANSCRIPT:-}"
fi

PULSE_BIN="${LEADV2_LANE_PULSE_BIN:-${SCRIPT_DIR}/leadv2-pulse.sh}"
export LEADV2_PROJECT_ROOT="$ROOT"

# BEATS pulse but never end the watch (fix-round C1): review_gate is emitted
# repeatedly mid-flight by leadv2-review-run.sh, long before the lane ends.
PULSE_PAT='review_gate'
# Exit-triggering states ONLY, for this watcher's sig. `dispatch_terminal` is
# boundary-guarded so dispatch_terminal_dedup noise rows (a duplicate-suppression
# receipt, reason=terminal_already_recorded — not a state transition) never
# terminate the watch (fix-round H1; same guard leadv2-lane-watch.sh:135
# documents with its trailing-space EMIT_PAT). M3: a bare `worker_died` token
# is emitted nowhere (codex-task.sh writes worker_died_stale, codex-guard.sh
# worker_died_silent — neither is a journal event); worker death reaches the
# journal only as cause=worker_died INSIDE a dispatch_terminal row, which the
# pattern below already matches (and the pulse loop re-kinds below).
EXIT_PAT='dispatch_terminal([^_]|$)|dispatch_refused([^_]|$)'
KIND_PAT='dispatch_terminal|dispatch_refused'

_pulse() {  # <kind> <text> — one line via the existing pulse writer, soft-fail
  [[ -f "$PULSE_BIN" ]] || return 0
  bash "$PULSE_BIN" "$TASK_ID" "$1" "$2" >/dev/null 2>&1 || true
}

_seen_init() {  # <journal> -> initial line offset
  local n
  n="$(wc -l < "$1" 2>/dev/null | tr -d ' ')"
  [[ "$n" =~ ^[0-9]+$ ]] || n=0
  # REPLAY-SAFE (MON-PULSE-01): seen starts at 0 so the first pass reads the
  # journal from line 1 (tail -n +1). Today's incident was exactly this bug in
  # Monitor form: `tail -n 0` skipped lines written before the watcher armed.
  # The negative control in test-lane-pulse-watch.sh reverts this return value
  # to the pre-existing line count (tail -n 0 semantics) and MUST go red.
  printf '0'
}

# fix-round H2: the ledger records how many lines a previous watcher for this
# sig already pulsed; it wins over the replay-from-line-1 default so a re-arm
# (fix round, arm advance, retry — all re-enter _spawn_worker_body) cannot
# duplicate stale pulses. Journal rotation is detected in the loop (n < SEEN)
# and resets both SEEN and the ledger.
_ledger_save() {  # <n> — atomic write, soft-fail
  printf '%s\n' "$1" > "${SEEN_FILE}.tmp.$$" 2>/dev/null \
    && mv -f "${SEEN_FILE}.tmp.$$" "$SEEN_FILE" 2>/dev/null || true
}
SEEN="$(_seen_init "$JOURNAL")"
_ledger="$(cat "$SEEN_FILE" 2>/dev/null | tr -d ' ' || true)"
if [[ "$_ledger" =~ ^[0-9]+$ ]] && (( _ledger > SEEN )); then
  SEEN="$_ledger"
fi
_started="$(date +%s)"
# Liveness: the journal ALWAYS exists at arm time (worker_spawned was just
# journaled), so a journal that stays missing means the lane tree was wiped
# (test fixture cleanup, worktree sweep). Never linger for the full timeout on
# a dead root: exit when the root is gone or the journal has been missing for
# GRACE_S consecutive seconds. Defensive bound, not an observation (fix-round
# H4): no live orphan count was ever taken — tune via
# LEADV2_LANE_PULSE_WATCH_GRACE_S if real telemetry ever demands it.
GRACE_S="${LEADV2_LANE_PULSE_WATCH_GRACE_S:-300}"
[[ "$GRACE_S" =~ ^[0-9]+$ ]] || GRACE_S=300
_missing_since=0
_last_growth="$_started"
_last_stale_attempt=0

while :; do
  if [[ ! -d "$ROOT" ]]; then
    printf '[lane-pulse-watch] %s root gone (%s), exiting\n' "$SIG" "$ROOT" >&2
    exit 0
  fi
  # BEAT-LOOP-ORPHANS-01: checked before the journal read so a watcher whose
  # lane journal is (or looks) busy can never mask an owner that is gone.
  if command -v leadv2_loop_owner_check >/dev/null 2>&1; then
    leadv2_loop_owner_check "$OWNER_FILE" "lane-pulse-watch" || exit 0
  fi
  # WATCHER-LIFECYCLE-LEAK-01 #2: owner-bound self-reap, checked every
  # iteration so the exit lands within one interval. The DURABLE owner of
  # this watch is the lane's journal (terminal / derived timeout below) —
  # neither the dispatcher pid (dead seconds after arming) nor the worker
  # pid (H1: the lane outlives its worker through review/e2e/merge) is a
  # safe owner. The explicit pid seam exists for ops/tests that arm with a
  # concrete owner process; unset (production default) changes nothing.
  if wl_owner_gone; then
    printf '[lane-pulse-watch] %s owner pid %s gone, self-reaping\n' "$SIG" "${LEADV2_WATCHER_OWNER_PID}" >&2
    exit 0
  fi
  # FORK-STORM-KILLS-HOOKS-01: worker gone (registry row still pins me as a
  # watcher and has frozen) — stop watching, the loop breaker's hygiene half.
  if (( ORPHAN_MAX > 0 )); then
    _orphan="$( _orphan_check "$$" "$ACTIVE_YAML" "$ORPHAN_MAX" )"
    if [[ "$_orphan" == "orphan" ]]; then
      printf '[lane-pulse-watch] %s orphaned: row pins my pid as watcher, frozen >%ss — exiting\n' "$SIG" "$ORPHAN_MAX" >&2
      # SET-U-ABORTS-THE-FAILURE-PATH-01: `$ORPHAN_MAXs` reads as a whole
      # variable name (bash has no way to tell `$ORPHAN_MAX` + literal "s"
      # apart from a variable literally named `ORPHAN_MAXs` without braces),
      # which this script never assigns. Under `set -u`, the orphan-cleanup
      # path itself aborted with "unbound variable" instead of exiting 0 --
      # a watcher detecting its own orphan condition crashed rather than
      # cleanly self-reaping. ShellCheck SC2154; confirmed live 2026-09-06.
      _pulse "watcher_orphan" "row_frozen>${ORPHAN_MAX}s"
      exit 0
    fi
  fi
  if [[ -f "$JOURNAL" ]]; then
    _missing_since=0
    n="$(wc -l < "$JOURNAL" | tr -d ' ')"
    [[ "$n" =~ ^[0-9]+$ ]] || n=0
    if (( n > SEEN )); then
      # atomic-replace-safe: line-count offsets, never inode following
      own="$(tail -n +"$((SEEN + 1))" "$JOURNAL" \
        | grep -E "task=${MATCH_TOKEN}([^0-9A-Za-z]|$)" || true)"
      # beats first (fix-round C1): review_gate transitions pulse but NEVER
      # end the watch — they are mid-flight signal, not lane termination.
      beats="$(printf '%s' "$own" | grep -E "$PULSE_PAT" || true)"
      if [[ -n "$beats" ]]; then
        while IFS= read -r l; do
          detail="$(printf '%s' "$l" | sed -E 's/^.*\[[a-z]+\] //' | cut -c1-60)"
          _pulse "review_gate" "$detail"
        done <<< "$beats"
      fi
      SEEN="$n"
      _ledger_save "$SEEN"
      _last_growth="$(date +%s)"
      # exit ONLY on a true terminal for this sig (fix-round C1/H1): dedup
      # rows and review_gate lines are already excluded by EXIT_PAT.
      term="$(printf '%s' "$own" | grep -E "$EXIT_PAT" || true)"
      if [[ -n "$term" ]]; then
        while IFS= read -r l; do
          kind="$(printf '%s' "$l" | grep -oE "$KIND_PAT" | head -n1)"
          # M3: terminal=dead cause=worker_died rows are deaths, not landings
          if printf '%s' "$l" | grep -q 'cause=worker_died'; then
            kind="worker_died"
          fi
          detail="$(printf '%s' "$l" | sed -E 's/^.*\[[a-z]+\] //' | cut -c1-60)"
          _pulse "${kind:-dispatch_terminal}" "$detail"
        done <<< "$term"
        printf '[lane-pulse-watch] %s terminal, exiting\n' "$SIG" >&2
        exit 0
      fi
    elif (( n < SEEN )); then
      # rotation/truncate — restart from line 1 (replay-safe again)
      printf '[lane-pulse-watch] %s rotated (lines %s < seen %s), re-reading\n' "$SIG" "$n" "$SEEN" >&2
      SEEN=0
      _ledger_save 0
      _last_growth="$(date +%s)"
    fi
    # LANE-PULSE-WATCH-SIG-KEY-STALE-ON-PHASE-CHANGE-01: no growth for
    # STALE_MAX -- try ONE re-resolve, then wait another STALE_MAX before
    # trying again (never every poll: that is the cost the pulse's own
    # per-session resolve would have paid, rejected above for exactly this
    # watcher's polling cadence).
    _now="$(date +%s)"
    if (( _now - _last_growth >= STALE_MAX && _now - _last_stale_attempt >= STALE_MAX )); then
      _last_stale_attempt="$_now"
      if _try_reresolve_stale_journal; then
        _last_growth="$_now"
      fi
    fi
  else
    _now="$(date +%s)"
    if (( _missing_since == 0 )); then
      _missing_since="$_now"
    elif (( _now - _missing_since >= GRACE_S )); then
      printf '[lane-pulse-watch] %s journal missing %ss, exiting\n' "$SIG" "$GRACE_S" >&2
      exit 0
    fi
  fi
  _now="$(date +%s)"
  if (( _now - _started >= TIMEOUT )); then
    printf '[lane-pulse-watch] %s timeout after %ss, exiting\n' "$SIG" "$TIMEOUT" >&2
    # H1: never die silently — a final watch_timeout pulse tells the founder
    # the lane was abandoned UNTERMINATED (a re-arm at the next spawn will
    # pick the journal up again; the seen ledger prevents re-pulsing).
    _pulse "watch_timeout" "no_terminal in ${TIMEOUT}s journal_lines=${SEEN}"
    exit 0
  fi
  sleep "$INTERVAL" &
  WL_CHILD=$!
  wait "$WL_CHILD" 2>/dev/null || true
  WL_CHILD=""
done
